"use client";

import { useEffect, useRef } from "react";
import { RISK_META } from "@/lib/phishguard/format";
import type { RiskLevel } from "@/lib/phishguard/types";
import { cn } from "@/lib/utils";

/* ── Circular risk-score gauge ──────────────────────────────────────────── */

export function RiskGauge({
  score,
  classification,
  size = 200,
  animate = true,
}: {
  score: number;
  classification: RiskLevel;
  size?: number;
  animate?: boolean;
}) {
  const stroke = 11;
  const r = (size - stroke * 2 - 8) / 2;
  const c = 2 * Math.PI * r;
  const pct = Math.max(0, Math.min(100, score)) / 100;
  const color =
    classification === "HIGH_RISK" ? "#FF304F" : classification === "MEDIUM_RISK" ? "#FFB020" : "#39FF14";
  const glowId = `pg-gauge-${classification}-${score}`;

  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90" role="img" aria-label={`Risk score ${score} of 100`}>
        <defs>
          <linearGradient id={glowId} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.85" />
            <stop offset="100%" stopColor={color} />
          </linearGradient>
        </defs>
        {/* track */}
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(232,245,236,0.07)" strokeWidth={stroke} />
        {/* tick ring */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r - stroke - 3}
          fill="none"
          stroke="rgba(232,245,236,0.05)"
          strokeWidth={1}
          strokeDasharray="2 6"
        />
        {/* progress */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={`url(#${glowId})`}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={animate ? undefined : c * (1 - pct)}
          style={{
            strokeDashoffset: animate ? c * (1 - pct) : undefined,
            transition: "stroke-dashoffset 1.1s cubic-bezier(0.22, 0.61, 0.36, 1)",
            filter: `drop-shadow(0 0 6px ${color}66)`,
          }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <div
          className="font-display text-[44px] font-bold leading-none tracking-tight"
          style={{ color, textShadow: `0 0 18px ${color}55` }}
        >
          {score}
        </div>
        <div className="mt-1 font-mono text-[9.5px] tracking-[0.3em] text-fg-dim">RISK / 100</div>
        <div className="mt-2 font-mono text-[10.5px] font-semibold tracking-[0.18em]" style={{ color }}>
          {RISK_META[classification].label}
        </div>
      </div>
    </div>
  );
}

/* ── Threat detection radar ─────────────────────────────────────────────── */

const RADAR_BLIPS = [
  { x: 30, y: 34, size: 5, tone: "#FF304F", delay: "0s" },
  { x: 68, y: 26, size: 4, tone: "#FFB020", delay: "0.6s" },
  { x: 58, y: 66, size: 4, tone: "#00E5FF", delay: "1.2s" },
  { x: 22, y: 62, size: 3, tone: "#39FF14", delay: "1.8s" },
  { x: 74, y: 52, size: 3, tone: "#FF304F", delay: "0.9s" },
];

export function ThreatRadar({ size = 230, className }: { size?: number; className?: string }) {
  return (
    <div
      className={cn("relative select-none", className)}
      style={{ width: size, height: size }}
      role="img"
      aria-label="Threat detection radar visualisation"
    >
      {/* rings */}
      {[100, 75, 50, 25].map((pct) => (
        <div
          key={pct}
          className="absolute rounded-full border border-[#1B6B42]/50"
          style={{
            inset: `${(100 - pct) / 2}%`,
            boxShadow: pct === 100 ? "inset 0 0 40px rgba(57,255,20,0.05)" : undefined,
          }}
        />
      ))}
      {/* cross */}
      <div className="absolute left-1/2 top-0 h-full w-px bg-[#1B6B42]/40" />
      <div className="absolute top-1/2 left-0 h-px w-full bg-[#1B6B42]/40" />
      {/* diagonal ticks */}
      <div className="absolute inset-0 rounded-full overflow-hidden">
        <div className="absolute left-1/2 top-1/2 h-[141%] w-px -translate-x-1/2 -translate-y-1/2 rotate-45 bg-[#1B6B42]/25" />
        <div className="absolute left-1/2 top-1/2 h-[141%] w-px -translate-x-1/2 -translate-y-1/2 -rotate-45 bg-[#1B6B42]/25" />
      </div>
      {/* sweep */}
      <div className="absolute inset-0 overflow-hidden rounded-full">
        <div
          className="animate-radar absolute inset-0"
          style={{
            background:
              "conic-gradient(from 0deg, rgba(57,255,20,0.35), rgba(57,255,20,0.12) 18%, transparent 26%, transparent 100%)",
          }}
        />
      </div>
      {/* blips */}
      {RADAR_BLIPS.map((b, i) => (
        <div
          key={i}
          className="absolute"
          style={{ left: `${b.x}%`, top: `${b.y}%`, transform: "translate(-50%, -50%)" }}
        >
          <span className="relative flex" style={{ width: b.size, height: b.size }}>
            <span
              className="animate-ping-dot absolute inline-flex h-full w-full rounded-full opacity-70"
              style={{ background: b.tone, animationDelay: b.delay }}
            />
            <span className="relative inline-flex h-full w-full rounded-full" style={{ background: b.tone }} />
          </span>
        </div>
      ))}
      {/* center */}
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
        <div className="h-2.5 w-2.5 rounded-full border-2 border-neon bg-ink" />
      </div>
      {/* rim */}
      <div className="absolute inset-0 rounded-full border border-neon/25" />
    </div>
  );
}

/* ── Holographic scanning rings (used during scan sequence) ─────────────── */

export function ScanRings({ size = 320, className }: { size?: number; className?: string }) {
  return (
    <div className={cn("pointer-events-none absolute", className)} style={{ width: size, height: size }} aria-hidden="true">
      <svg viewBox="0 0 200 200" width={size} height={size} className="animate-spin-slow opacity-60">
        <circle cx="100" cy="100" r="92" fill="none" stroke="#39FF14" strokeOpacity="0.5" strokeWidth="0.8" strokeDasharray="10 14" />
        <circle cx="100" cy="100" r="76" fill="none" stroke="#00E5FF" strokeOpacity="0.4" strokeWidth="0.7" strokeDasharray="3 9" />
      </svg>
      <svg viewBox="0 0 200 200" width={size} height={size} className="animate-spin-slower-rev absolute inset-0 opacity-50">
        <circle cx="100" cy="100" r="84" fill="none" stroke="#39FF14" strokeOpacity="0.35" strokeWidth="0.8" strokeDasharray="60 40 8 40" />
        <circle cx="100" cy="100" r="60" fill="none" stroke="#00E5FF" strokeOpacity="0.3" strokeWidth="0.7" strokeDasharray="20 80" />
      </svg>
    </div>
  );
}

/* ── Terminal activity feed ─────────────────────────────────────────────── */

export type TerminalLine = {
  text: string;
  tone?: "dim" | "neon" | "cyber" | "danger" | "amber" | "fg";
};

const TONE_CLASS: Record<NonNullable<TerminalLine["tone"]>, string> = {
  dim: "text-fg-dim/80",
  neon: "text-[#7CFF5E]",
  cyber: "text-[#5CE4F7]",
  danger: "text-[#FF5E74]",
  amber: "text-[#FFC24E]",
  fg: "text-fg",
};

export function TerminalFeed({
  lines,
  className,
  height = 240,
  follow = true,
  showCaret = true,
  ariaLabel = "Terminal activity feed",
}: {
  lines: TerminalLine[];
  className?: string;
  height?: number;
  follow?: boolean;
  showCaret?: boolean;
  ariaLabel?: string;
}) {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (follow && scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [lines, follow]);

  return (
    <div
      ref={scrollRef}
      role="log"
      aria-label={ariaLabel}
      className={cn("pg-grid-bg overflow-y-auto bg-black/35 px-3.5 py-3 font-mono text-[11px] leading-[1.75]", className)}
      style={{ height }}
    >
      {lines.map((l, i) => (
        <div key={i} className={cn("whitespace-pre-wrap break-all", TONE_CLASS[l.tone ?? "dim"])}>
          {l.text}
        </div>
      ))}
      {showCaret && (
        <div className="text-neon">
          <span className="animate-caret">▊</span>
        </div>
      )}
    </div>
  );
}
