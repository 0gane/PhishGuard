"use client";

import { Menu, Radio, ShieldCheck, UserRound } from "lucide-react";
import { MetaPill, StatusDot } from "@/components/phishguard/primitives";
import { useUiStore } from "@/lib/phishguard/store";
import { currentApiSource } from "@/lib/phishguard/api";
import { formatClock } from "@/lib/phishguard/format";
import { useClock, useMounted } from "@/hooks/phishguard/use-phishguard";
import { PAGE_META } from "@/components/phishguard/nav-config";
import type { PageId } from "@/lib/phishguard/types";

export function Topbar({ page }: { page: PageId }) {
  const setMobileNavOpen = useUiStore((s) => s.setMobileNavOpen);
  const operator = useUiStore((s) => s.settings.operatorName);
  const now = useClock();
  const mounted = useMounted();
  /* API source depends on localStorage — render "MOCK" until mounted to keep SSR stable. */
  const apiMode = mounted ? currentApiSource() : "MOCK";

  return (
    <header className="sticky top-0 z-40 border-b border-border/70 bg-ink/85 backdrop-blur-md">
      <div className="flex h-14 items-center gap-3 px-4 sm:px-6">
        {/* Mobile menu */}
        <button
          type="button"
          onClick={() => setMobileNavOpen(true)}
          aria-label="Open navigation"
          className="rounded-md border border-border p-2 text-fg-dim transition-colors hover:bg-white/[0.05] hover:text-fg lg:hidden"
        >
          <Menu className="h-4 w-4" strokeWidth={2} />
        </button>

        {/* Section title (desktop) */}
        <div className="hidden min-w-0 items-center gap-2 font-mono text-[11px] tracking-[0.22em] text-fg-dim sm:flex">
          <ShieldCheck className="h-3.5 w-3.5 text-neon" strokeWidth={2} />
          <span className="truncate">SOC CONSOLE / {PAGE_META[page].title.toUpperCase()}</span>
        </div>
        <div className="min-w-0 truncate font-display text-[13px] font-semibold tracking-wide text-fg sm:hidden">
          {PAGE_META[page].title}
        </div>

        <div className="ml-auto flex items-center gap-2.5 sm:gap-4">
          {/* API source pill */}
          <MetaPill tone={apiMode === "LIVE" ? "ok" : "demo"} className="hidden md:inline-flex">
            <Radio className="h-3 w-3" strokeWidth={2.2} />
            API: {apiMode}
          </MetaPill>

          {/* Demo mode */}
          <MetaPill tone="warn">
            <span className="animate-pulse">●</span>
            DEMO MODE
          </MetaPill>

          {/* Clock */}
          <div
            className="hidden items-center gap-2 rounded-md border border-border bg-black/30 px-2.5 py-1.5 font-mono text-[11px] tracking-[0.14em] text-fg md:flex"
            aria-label="Current UTC time"
          >
            <span className="h-1.5 w-1.5 rounded-full bg-neon" />
            {now ? formatClock(now) : "--:--:-- UTC"}
          </div>

          {/* Operator */}
          <div
            className="flex items-center gap-2 rounded-md border border-border bg-black/30 py-1 pl-1.5 pr-2.5"
            title={`Operator: ${operator}`}
          >
            <span className="flex h-6 w-6 items-center justify-center rounded bg-neon/15 text-neon">
              <UserRound className="h-3.5 w-3.5" strokeWidth={2} />
            </span>
            <span className="hidden font-mono text-[11px] text-fg-dim sm:inline">{operator}</span>
          </div>
        </div>
      </div>

      {/* Status hairline */}
      <div className="flex items-center gap-3 border-t border-border/50 px-4 py-1.5 sm:px-6">
        <StatusDot tone="demo" label="RULE ENGINE · DEMO RULESET ACTIVE" pulse={false} />
        <span className="hidden text-border sm:inline">|</span>
        <StatusDot tone="down" label="ML ENGINE · NOT CONNECTED" pulse={false} className="hidden sm:inline-flex" />
        <span className="ml-auto hidden font-mono text-[9.5px] tracking-[0.2em] text-fg-dim/70 lg:inline">
          PHISHGUARD v1.0.0-demo · BUILD 2025.12 · LOCAL INSTANCE
        </span>
      </div>
    </header>
  );
}
