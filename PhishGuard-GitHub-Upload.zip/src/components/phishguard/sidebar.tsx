"use client";

import { PANEL_NAV, type NavItem } from "@/components/phishguard/nav-config";
import { PhishGuardLogo, PhishGuardMark } from "@/components/phishguard/logo";
import { StatusDot } from "@/components/phishguard/primitives";
import { useUiStore } from "@/lib/phishguard/store";
import type { PageId } from "@/lib/phishguard/types";
import { PanelLeftClose, PanelLeftOpen, ShieldHalf, X } from "lucide-react";
import { cn } from "@/lib/utils";

function NavLink({
  item,
  active,
  collapsed,
  onSelect,
}: {
  item: NavItem;
  active: boolean;
  collapsed: boolean;
  onSelect: () => void;
}) {
  const Icon = item.icon;
  return (
    <button
      type="button"
      onClick={onSelect}
      aria-current={active ? "page" : undefined}
      title={collapsed ? item.label : undefined}
      className={cn(
        "group relative flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left transition-all duration-200",
        "focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-neon/60",
        active
          ? "bg-neon/[0.09] text-neon"
          : "text-fg-dim hover:bg-white/[0.045] hover:text-fg"
      )}
    >
      {/* glowing active indicator */}
      <span
        className={cn(
          "absolute left-0 top-1/2 h-6 w-[3px] -translate-y-1/2 rounded-full transition-all duration-250",
          active
            ? "bg-neon shadow-[0_0_10px_rgba(57,255,20,0.8)]"
            : "bg-transparent group-hover:bg-fg-dim/40"
        )}
      />
      <Icon
        className={cn(
          "h-[17px] w-[17px] shrink-0 transition-transform duration-200 group-hover:scale-105",
          active ? "text-neon" : "text-fg-dim group-hover:text-fg"
        )}
        strokeWidth={active ? 2.2 : 1.9}
      />
      {!collapsed && (
        <span className={cn("truncate text-[13px] font-medium tracking-wide", active && "text-glow-neon")}>
          {item.label}
        </span>
      )}
      {!collapsed && item.tag && (
        <span className="ml-auto rounded border border-[#00E5FF]/30 bg-[#00E5FF]/10 px-1.5 py-px font-mono text-[8.5px] tracking-[0.14em] text-[#5CE4F7]">
          {item.tag}
        </span>
      )}
    </button>
  );
}

function SidebarBody({
  page,
  collapsed,
  onNavigate,
  onCloseMobile,
}: {
  page: PageId;
  collapsed: boolean;
  onNavigate: (p: PageId) => void;
  onCloseMobile?: () => void;
}) {
  return (
    <div className="flex h-full flex-col">
      {/* Brand */}
      <div className={cn("flex items-center justify-between border-b border-border/70 px-4 py-4", collapsed && "px-3")}>
        {collapsed ? (
          <PhishGuardMark size={34} className="mx-auto" />
        ) : (
          <PhishGuardLogo size={36} />
        )}
        {onCloseMobile && (
          <button
            type="button"
            onClick={onCloseMobile}
            aria-label="Close navigation"
            className="rounded-md p-1.5 text-fg-dim transition-colors hover:bg-white/[0.05] hover:text-fg lg:hidden"
          >
            <X className="h-5 w-5" strokeWidth={2} />
          </button>
        )}
      </div>

      {/* Nav sections */}
      <nav aria-label="Primary" className="flex-1 overflow-y-auto px-2.5 py-4">
        {PANEL_NAV.map((section) => (
          <div key={section.section} className="mb-5 last:mb-0">
            {!collapsed && (
              <div className="mb-2 px-3 font-mono text-[9px] font-medium tracking-[0.32em] text-fg-dim/70">
                {section.section}
              </div>
            )}
            {collapsed && <div className="mx-auto mb-2 h-px w-8 bg-border" />}
            <ul className="space-y-1">
              {section.items.map((item) => (
                <li key={item.id}>
                  <NavLink
                    item={item}
                    active={page === item.id}
                    collapsed={collapsed}
                    onSelect={() => onNavigate(item.id)}
                  />
                </li>
              ))}
            </ul>
          </div>
        ))}
      </nav>

      {/* Engine status widget */}
      <div className={cn("border-t border-border/70 px-3.5 py-3.5", collapsed && "px-2")}>
        {collapsed ? (
          <div className="flex flex-col items-center gap-3 py-1">
            <StatusDot tone="demo" pulse />
            <StatusDot tone="warn" pulse={false} />
          </div>
        ) : (
          <div className="rounded-lg border border-border/80 bg-black/25 p-3">
            <div className="mb-2.5 flex items-center gap-2 font-mono text-[9px] tracking-[0.26em] text-fg-dim">
              <ShieldHalf className="h-3 w-3 text-neon" />
              ENGINE STATUS
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] text-fg-dim">Rule Engine</span>
                <StatusDot tone="demo" label="DEMO" pulse={false} />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[11px] text-fg-dim">ML Classifier</span>
                <StatusDot tone="down" label="OFFLINE" pulse={false} />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[11px] text-fg-dim">Threat Feeds</span>
                <StatusDot tone="demo" label="DEMO" pulse />
              </div>
            </div>
            <div className="mt-3 border-t border-border/60 pt-2.5 font-mono text-[9px] leading-relaxed tracking-[0.08em] text-fg-dim/70">
              DEMO MODE — no live threat data. Connect the FastAPI backend to go live.
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export function Sidebar({ page, onNavigate }: { page: PageId; onNavigate: (p: PageId) => void }) {
  const { sidebarCollapsed, toggleSidebar, mobileNavOpen, setMobileNavOpen } = useUiStore();

  return (
    <>
      {/* Desktop sidebar */}
      <aside
        className={cn(
          "sticky top-0 hidden h-screen shrink-0 border-r border-border/70 bg-sidebar transition-[width] duration-300 ease-in-out lg:block",
          sidebarCollapsed ? "w-[74px]" : "w-[248px]"
        )}
        aria-label="Sidebar"
      >
        <SidebarBody page={page} collapsed={sidebarCollapsed} onNavigate={onNavigate} />
        <button
          type="button"
          onClick={toggleSidebar}
          aria-label={sidebarCollapsed ? "Expand sidebar" : "Collapse sidebar"}
          className="absolute -right-3.5 top-20 z-20 flex h-7 w-7 items-center justify-center rounded-full border border-neon/30 bg-panel text-neon shadow-[0_0_12px_rgba(57,255,20,0.25)] transition-transform hover:scale-105"
        >
          {sidebarCollapsed ? (
            <PanelLeftOpen className="h-3.5 w-3.5" strokeWidth={2} />
          ) : (
            <PanelLeftClose className="h-3.5 w-3.5" strokeWidth={2} />
          )}
        </button>
      </aside>

      {/* Mobile off-canvas */}
      {mobileNavOpen && (
        <div className="fixed inset-0 z-50 lg:hidden" role="dialog" aria-modal="true" aria-label="Navigation menu">
          <div
            className="absolute inset-0 bg-black/70 backdrop-blur-sm"
            onClick={() => setMobileNavOpen(false)}
          />
          <div className="absolute inset-y-0 left-0 w-[272px] border-r border-border bg-sidebar shadow-2xl">
            <SidebarBody
              page={page}
              collapsed={false}
              onNavigate={onNavigate}
              onCloseMobile={() => setMobileNavOpen(false)}
            />
          </div>
        </div>
      )}
    </>
  );
}
