"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  AlarmClock,
  Braces,
  ChevronRight,
  Clipboard,
  Cpu,
  Eraser,
  Globe,
  ListChecks,
  Play,
  Radar,
  ScanLine,
  ShieldCheck,
  ShieldX,
  Split,
  TriangleAlert,
} from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import {
  CardHeader,
  DemoBadge,
  MetaPill,
  PageHeader,
  PgCard,
  RiskBadge,
} from "@/components/phishguard/primitives";
import { RiskGauge, ScanRings, TerminalFeed, type TerminalLine } from "@/components/phishguard/visuals";
import { RISK_META, formatDateTime, relativeTime, truncateMiddle } from "@/lib/phishguard/format";
import { InvalidUrlError, normalizeUrl } from "@/lib/phishguard/scanner-engine";
import { api } from "@/lib/phishguard/api";
import { useScanStore, useUiStore } from "@/lib/phishguard/store";
import type { ScanResult } from "@/lib/phishguard/types";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

const SCAN_STEPS = [
  { id: "init", label: "INITIALIZING SCAN", icon: Cpu },
  { id: "parse", label: "ANALYSING URL", icon: Split },
  { id: "features", label: "EXTRACTING FEATURES", icon: ListChecks },
  { id: "intel", label: "CHECKING AVAILABLE INTELLIGENCE", icon: Radar },
  { id: "verdict", label: "GENERATING VERDICT", icon: ShieldCheck },
] as const;

const EXAMPLES = [
  { label: "Legitimate", url: "https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS" },
  { label: "Suspicious", url: "https://secure-login.portal-user5821.com/auth" },
  { label: "Phishing", url: "http://paypal-verify-account.tk/webscr?cmd=_login-run" },
];

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export function ScannerPage() {
  const [url, setUrl] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [scanning, setScanning] = useState(false);
  const [activeStep, setActiveStep] = useState(-1);
  const [lines, setLines] = useState<TerminalLine[]>([]);
  const [result, setResult] = useState<ScanResult | null>(null);
  const [recent, setRecent] = useState<ScanResult[]>([]);
  const scans = useScanStore((s) => s.scans);
  const addScan = useScanStore((s) => s.addScan);
  const pendingScanUrl = useUiStore((s) => s.pendingScanUrl);
  const setPendingScanUrl = useUiStore((s) => s.setPendingScanUrl);
  const { toast } = useToast();
  const inputRef = useRef<HTMLInputElement>(null);
  const runIdRef = useRef(0);

  useEffect(() => {
    setRecent(scans.slice(0, 6));
  }, [scans]);

  /* Consume a URL stashed by Scan History → "Re-scan". */
  useEffect(() => {
    if (pendingScanUrl) {
      setUrl(pendingScanUrl);
      setError(null);
      setPendingScanUrl(null);
      inputRef.current?.focus();
    }
  }, [pendingScanUrl, setPendingScanUrl]);

  /* Focus the URL field on arrival when the operator enables it in Settings. */
  const autoClipboard = useUiStore((s) => s.settings.autoClipboard);
  useEffect(() => {
    if (autoClipboard) inputRef.current?.focus();
  }, [autoClipboard]);

  const pushLine = useCallback((line: TerminalLine) => {
    setLines((prev) => [...prev.slice(-40), line]);
  }, []);

  const runScan = useCallback(async () => {
    if (scanning) return;
    setError(null);
    let normalized: string;
    try {
      normalized = normalizeUrl(url);
    } catch (err) {
      setError(err instanceof InvalidUrlError ? err.message : "Invalid URL.");
      return;
    }

    const runId = ++runIdRef.current;
    setScanning(true);
    setResult(null);
    setLines([
      { text: "$ phishguard scan --url " + normalized, tone: "neon" },
      { text: "engine: pg-heuristic-rules v1.2.0 (DEMO — local ruleset, no ML / no external feeds)", tone: "dim" },
    ]);

    const t0 = performance.now();
    const mark = () => `[${((performance.now() - t0) / 1000).toFixed(3)}s]`;

    try {
      // Compute the verdict up front (mock adapter also persists it).
      const scanPromise = api.createScan(normalized, "MANUAL");
      const precomputed = await scanPromise;

      for (let i = 0; i < SCAN_STEPS.length; i++) {
        if (runIdRef.current !== runId) return;
        setActiveStep(i);
        const step = SCAN_STEPS[i];
        pushLine({ text: `${mark()} ${step.label.toLowerCase()} …`, tone: "cyber" });
        if (step.id === "parse") {
          pushLine({ text: `${mark()} host=${precomputed.structure.host} proto=${precomputed.structure.protocol} port=${precomputed.structure.port ?? "-"}`, tone: "dim" });
        }
        if (step.id === "features") {
          pushLine({ text: `${mark()} ${precomputed.reasons.length} rule signals evaluated (demo ruleset)`, tone: "dim" });
        }
        if (step.id === "intel") {
          pushLine({ text: `${mark()} external feeds: NOT CONNECTED — using local demo data only`, tone: "amber" });
        }
        await sleep(520 + Math.random() * 380);
      }
      if (runIdRef.current !== runId) return;

      setActiveStep(SCAN_STEPS.length);
      const tone = precomputed.classification === "HIGH_RISK" ? "danger" : precomputed.classification === "MEDIUM_RISK" ? "amber" : "neon";
      pushLine({ text: `${mark()} verdict: ${precomputed.classification} (score ${precomputed.riskScore}/100)`, tone });
      pushLine({ text: `${mark()} scan ${precomputed.id} completed in ${precomputed.durationMs}ms`, tone: "dim" });

      setResult(precomputed);
      addScan(precomputed);
      toast({
        title:
          precomputed.classification === "HIGH_RISK"
            ? "High-risk URL detected"
            : precomputed.classification === "MEDIUM_RISK"
              ? "Suspicious URL flagged"
              : "Scan complete — low risk",
        description: `${truncateMiddle(precomputed.host, 40)} scored ${precomputed.riskScore}/100 (demo verdict).`,
        variant: precomputed.classification === "HIGH_RISK" ? "destructive" : "default",
      });
    } catch (err) {
      pushLine({ text: `${mark()} scan failed: ${err instanceof Error ? err.message : "unknown error"}`, tone: "danger" });
      setError(err instanceof Error ? err.message : "Scan failed.");
    } finally {
      if (runIdRef.current === runId) {
        setScanning(false);
        setActiveStep(-1);
      }
    }
  }, [url, scanning, pushLine, addScan, toast]);

  const handlePaste = useCallback(async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text.trim()) {
        setUrl(text.trim());
        setError(null);
        inputRef.current?.focus();
      } else {
        setError("Clipboard is empty.");
      }
    } catch {
      setError("Clipboard access was blocked by the browser — paste manually with Ctrl/Cmd+V.");
    }
  }, []);

  const stepState = (index: number): "done" | "active" | "pending" => {
    if (activeStep < 0) return "pending";
    if (index < activeStep) return "done";
    if (index === activeStep) return "active";
    return "pending";
  };

  const tone = result ? RISK_META[result.classification] : null;

  return (
    <div className="space-y-6">
      <PageHeader
        page="scanner"
        title="Live URL Scanner"
        description="Submit a URL for structural analysis by the demo heuristic engine. Verdicts are computed locally in your browser."
        right={<DemoBadge />}
      />

      {/* ── Input console ─────────────────────────────────────────── */}
      <PgCard scanline={scanning}>
        <CardHeader
          title="Scan Target"
          subtitle="URL is analysed locally — nothing leaves your browser"
          icon={ScanLine}
          right={<MetaPill tone="demo">ENGINE: PG-HEURISTIC-RULES · DEMO</MetaPill>}
        />
        <div className="p-4 sm:p-6">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              runScan();
            }}
            className="space-y-4"
          >
            <label htmlFor="scan-url" className="sr-only">
              URL to scan
            </label>
            <div
              className={cn(
                "flex items-center gap-2.5 rounded-xl border bg-black/40 px-4 py-3 transition-all duration-300",
                error
                  ? "border-danger/60 shadow-[0_0_18px_rgba(255,48,79,0.15)]"
                  : "border-neon/30 focus-within:border-neon/70 focus-within:shadow-[0_0_24px_rgba(57,255,20,0.16)]"
              )}
            >
              <ChevronRight className="h-4 w-4 shrink-0 text-neon" strokeWidth={2.4} />
              <input
                id="scan-url"
                ref={inputRef}
                value={url}
                onChange={(e) => {
                  setUrl(e.target.value);
                  setError(null);
                }}
                placeholder="https://suspicious-link.example/login…"
                spellCheck={false}
                autoComplete="off"
                inputMode="url"
                className="min-w-0 flex-1 bg-transparent font-mono text-[13.5px] text-fg placeholder:text-fg-dim/50 focus:outline-none"
              />
              <button
                type="button"
                onClick={handlePaste}
                className="hidden shrink-0 items-center gap-1.5 rounded-md border border-border px-2.5 py-1.5 font-mono text-[10.5px] tracking-[0.12em] text-fg-dim transition-colors hover:border-cyber/50 hover:text-[#5CE4F7] sm:inline-flex"
              >
                <Clipboard className="h-3 w-3" /> PASTE
              </button>
              <button
                type="button"
                onClick={() => {
                  setUrl("");
                  setError(null);
                }}
                aria-label="Clear input"
                className="inline-flex shrink-0 items-center gap-1.5 rounded-md border border-border px-2.5 py-1.5 font-mono text-[10.5px] tracking-[0.12em] text-fg-dim transition-colors hover:border-border hover:bg-white/[0.04] hover:text-fg"
              >
                <Eraser className="h-3 w-3" /> CLEAR
              </button>
            </div>

            {error && (
              <p role="alert" className="flex items-center gap-2 font-mono text-[11.5px] text-[#FF5E74]">
                <TriangleAlert className="h-3.5 w-3.5" /> {error}
              </p>
            )}

            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-mono text-[10px] tracking-[0.2em] text-fg-dim">TRY:</span>
                {EXAMPLES.map((ex) => (
                  <button
                    key={ex.label}
                    type="button"
                    onClick={() => {
                      setUrl(ex.url);
                      setError(null);
                    }}
                    className={cn(
                      "rounded-full border px-2.5 py-1 font-mono text-[10px] tracking-[0.08em] transition-colors",
                      ex.label === "Phishing"
                        ? "border-danger/40 bg-danger/10 text-[#FF5E74] hover:bg-danger/20"
                        : ex.label === "Suspicious"
                          ? "border-[#FFB020]/40 bg-[#FFB020]/10 text-[#FFC24E] hover:bg-[#FFB020]/20"
                          : "border-neon/35 bg-neon/10 text-neon hover:bg-neon/20"
                    )}
                  >
                    {ex.label.toUpperCase()}
                  </button>
                ))}
                <button
                  type="button"
                  onClick={handlePaste}
                  className="rounded-full border border-border px-2.5 py-1 font-mono text-[10px] tracking-[0.08em] text-fg-dim transition-colors hover:text-fg sm:hidden"
                >
                  PASTE CLIPBOARD
                </button>
              </div>

              <button
                type="submit"
                disabled={scanning}
                className={cn(
                  "pg-btn-sweep inline-flex h-11 items-center justify-center gap-2.5 rounded-lg px-7 font-mono text-[12.5px] font-bold tracking-[0.22em] transition-all",
                  scanning
                    ? "cursor-wait bg-neon/15 text-neon/70"
                    : "glow-neon-soft bg-neon text-[#04130A] hover:shadow-[0_0_30px_rgba(57,255,20,0.45)]"
                )}
              >
                {scanning ? (
                  <>
                    <Globe className="h-4 w-4 animate-spin" />
                    SCANNING…
                  </>
                ) : (
                  <>
                    <Play className="h-4 w-4" strokeWidth={2.6} />
                    INITIATE SCAN
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </PgCard>

      {/* ── Scanning sequence ─────────────────────────────────────── */}
      <AnimatePresence>
        {scanning && (
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
          >
            <PgCard>
              <CardHeader title="Scan In Progress" subtitle="Demo pipeline — staged sequence" icon={Globe} />
              <div className="relative grid grid-cols-1 gap-0 lg:grid-cols-[300px_1fr]">
                <div className="relative flex flex-col items-center justify-center gap-6 border-b border-border/60 py-8 lg:border-b-0 lg:border-r">
                  <ScanRings size={280} className="left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2" />
                  <motion.div
                    animate={{ scale: [1, 1.06, 1] }}
                    transition={{ duration: 1.6, repeat: Infinity, ease: "easeInOut" }}
                    className="relative z-10 flex h-24 w-24 items-center justify-center rounded-2xl border border-neon/40 bg-neon/10"
                  >
                    <ScanLine className="h-10 w-10 text-neon" strokeWidth={1.8} />
                  </motion.div>
                  <div className="z-10 w-full max-w-[240px]">
                    <div className="h-1.5 overflow-hidden rounded-full bg-white/[0.06]">
                      <motion.div
                        className="h-full rounded-full bg-gradient-to-r from-neon via-[#7CFF5E] to-cyber"
                        initial={{ width: "0%" }}
                        animate={{ width: `${Math.min(100, (Math.max(activeStep, 0) / SCAN_STEPS.length) * 100 + 8)}%` }}
                        transition={{ duration: 0.5 }}
                      />
                    </div>
                    <div className="mt-2 text-center font-mono text-[9.5px] tracking-[0.3em] text-fg-dim">
                      {Math.round((Math.max(activeStep, 0) / SCAN_STEPS.length) * 100 + 8)}% · PIPELINE
                    </div>
                  </div>
                </div>

                <div className="flex flex-col">
                  <ol className="space-y-1 p-4 sm:p-5" aria-label="Scan pipeline steps">
                    {SCAN_STEPS.map((step, i) => {
                      const state = stepState(i);
                      const Icon = step.icon;
                      return (
                        <li
                          key={step.id}
                          className={cn(
                            "flex items-center gap-3 rounded-lg px-3 py-2.5 transition-all duration-300",
                            state === "active" && "bg-neon/[0.07]",
                            state === "done" && "opacity-80",
                            state === "pending" && "opacity-40"
                          )}
                        >
                          <span
                            className={cn(
                              "flex h-7 w-7 items-center justify-center rounded-md border",
                              state === "done"
                                ? "border-neon/50 bg-neon/15 text-neon"
                                : state === "active"
                                  ? "border-cyber/50 bg-cyber/10 text-[#5CE4F7]"
                                  : "border-border text-fg-dim"
                            )}
                          >
                            {state === "done" ? (
                              <ShieldCheck className="h-3.5 w-3.5" />
                            ) : (
                              <Icon className={cn("h-3.5 w-3.5", state === "active" && "animate-pulse")} />
                            )}
                          </span>
                          <span
                            className={cn(
                              "font-mono text-[11px] tracking-[0.18em]",
                              state === "active" ? "text-[#5CE4F7]" : state === "done" ? "text-neon" : "text-fg-dim"
                            )}
                          >
                            {step.label}
                          </span>
                          <span className="ml-auto font-mono text-[9px] tracking-[0.2em] text-fg-dim/60">
                            {state === "done" ? "OK" : state === "active" ? "RUNNING…" : "QUEUED"}
                          </span>
                        </li>
                      );
                    })}
                  </ol>
                  <TerminalFeed lines={lines} height={180} className="mx-4 mb-4 rounded-lg border border-border/70 sm:mx-5" />
                </div>
              </div>
            </PgCard>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Verdict ───────────────────────────────────────────────── */}
      <AnimatePresence>
        {result && !scanning && (
          <motion.div
            key={result.id}
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.35, ease: [0.21, 0.6, 0.35, 1] }}
            className="space-y-4"
          >
            <div className="grid grid-cols-1 gap-4 xl:grid-cols-[380px_1fr]">
              {/* Gauge + action */}
              <PgCard className="flex flex-col items-center p-5 sm:p-6">
                <RiskGauge score={result.riskScore} classification={result.classification} size={216} />
                <div className="mt-4 w-full rounded-lg border p-3.5 text-center"
                  style={{ borderColor: `${tone?.dot}55`, background: `${tone?.dot}12` }}
                >
                  <div className="font-mono text-[9.5px] tracking-[0.3em]" style={{ color: tone?.dot }}>
                    RECOMMENDED ACTION
                  </div>
                  <p className="mt-1.5 text-[13px] leading-relaxed text-fg">{result.recommendedAction}</p>
                </div>
                <dl className="mt-4 w-full space-y-2 font-mono text-[10.5px]">
                  {[
                    ["SCAN ID", result.id],
                    ["ENGINE", result.engine],
                    ["ANALYSIS TIME", `${result.durationMs} ms`],
                    ["SCANNED AT", formatDateTime(result.scannedAt)],
                  ].map(([k, v]) => (
                    <div key={k} className="flex items-center justify-between gap-3 border-b border-border/40 pb-1.5">
                      <dt className="tracking-[0.14em] text-fg-dim">{k}</dt>
                      <dd className="truncate text-fg">{v}</dd>
                    </div>
                  ))}
                </dl>
                <div className="mt-4">
                  <MetaPill tone="warn">DEMO VERDICT — LOCAL HEURISTICS ONLY</MetaPill>
                </div>
              </PgCard>

              {/* Structure + reasons */}
              <div className="space-y-4">
                <PgCard>
                  <CardHeader title="URL Structure Analysis" subtitle="Parsed components of the submitted target" icon={Split} />
                  <div className="p-4 sm:p-5">
                    <div className="mb-4 overflow-x-auto rounded-lg border border-border/70 bg-black/35 px-3.5 py-3 font-mono text-[12px]">
                      <span className="text-[#5CE4F7]">{result.structure.protocol}://</span>
                      {result.structure.subdomain && <span className="text-[#FFC24E]">{result.structure.subdomain}.</span>}
                      <span className="text-fg">{result.structure.domain}</span>
                      {result.structure.tld && <span className="text-[#FF5E74]">.{result.structure.tld}</span>}
                      {result.structure.port && result.structure.port !== "80" && result.structure.port !== "443" && (
                        <span className="text-[#FF5E74]">:{result.structure.port}</span>
                      )}
                      {result.structure.path && <span className="text-fg/80">{result.structure.path}</span>}
                      {result.structure.query && <span className="text-[#7CFF5E]">?{result.structure.query}</span>}
                      {result.structure.fragment && <span className="text-fg-dim">#{result.structure.fragment}</span>}
                    </div>
                    <dl className="grid grid-cols-2 gap-x-4 gap-y-2.5 font-mono text-[10.5px] sm:grid-cols-3">
                      {[
                        ["PROTOCOL", result.structure.protocol.toUpperCase()],
                        ["TLS", result.structure.secure ? "ENCRYPTED" : "NOT ENCRYPTED"],
                        ["HOST", result.structure.host],
                        ["IP HOST", result.structure.isIp ? "YES" : "NO"],
                        ["REGISTERED DOMAIN", result.structure.domain ?? "—"],
                        ["TLD", result.structure.tld ? `.${result.structure.tld}` : "—"],
                        ["PORT", result.structure.port ?? "—"],
                        ["PATH DEPTH", String(result.structure.pathDepth)],
                        ["URL LENGTH", `${result.structure.length} chars`],
                      ].map(([k, v]) => (
                        <div key={k} className="rounded-md border border-border/60 bg-white/[0.02] px-2.5 py-2">
                          <dt className="text-[8.5px] tracking-[0.22em] text-fg-dim">{k}</dt>
                          <dd className="mt-1 truncate text-fg" title={v}>{v}</dd>
                        </div>
                      ))}
                    </dl>
                  </div>
                </PgCard>

                <PgCard>
                  <CardHeader
                    title="Detection Reasons"
                    subtitle={`${result.reasons.filter((r) => r.weight > 0).length} risk signals · ${result.reasons.filter((r) => r.weight <= 0).length} mitigations`}
                    icon={Braces}
                    right={<RiskBadge level={result.classification} score={result.riskScore} />}
                  />
                  <ul className="max-h-[380px] divide-y divide-border/50 overflow-y-auto">
                    {result.reasons.map((r) => (
                      <li key={r.code} className="flex items-start gap-3 px-4 py-3 sm:px-5">
                        <span
                          className={cn(
                            "mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-md border font-mono text-[9px] font-bold",
                            r.weight > 0
                              ? r.severity === "CRITICAL" || r.severity === "HIGH"
                                ? "border-danger/40 bg-danger/10 text-[#FF5E74]"
                                : "border-[#FFB020]/40 bg-[#FFB020]/10 text-[#FFC24E]"
                              : "border-neon/35 bg-neon/10 text-neon"
                          )}
                        >
                          {r.weight > 0 ? `+${r.weight}` : r.weight}
                        </span>
                        <div className="min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="text-[13px] font-medium text-fg">{r.label}</span>
                            <span className="rounded border border-border px-1.5 py-px font-mono text-[8.5px] tracking-[0.12em] text-fg-dim">
                              {r.code}
                            </span>
                          </div>
                          <p className="mt-1 text-[12.5px] leading-relaxed text-fg-dim">{r.detail}</p>
                        </div>
                      </li>
                    ))}
                    {result.reasons.length === 0 && (
                      <li className="px-5 py-6 text-center font-mono text-[11px] text-fg-dim">
                        No rule signals triggered — URL appears structurally clean.
                      </li>
                    )}
                  </ul>
                </PgCard>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Recent scans ──────────────────────────────────────────── */}
      {recent.length > 0 && (
        <PgCard>
          <CardHeader title="Recent Scans" subtitle="Latest verdicts from this browser session" icon={AlarmClock} />
          <ul className="divide-y divide-border/50">
            {recent.map((s) => (
              <li key={s.id} className="flex flex-wrap items-center gap-x-4 gap-y-2 px-4 py-3 transition-colors hover:bg-white/[0.02] sm:px-5">
                <RiskBadge level={s.classification} score={s.riskScore} />
                <span className="min-w-0 flex-1 truncate font-mono text-[12px] text-fg/90" title={s.url}>
                  {truncateMiddle(s.url, 72)}
                </span>
                <span className="font-mono text-[10px] text-fg-dim">{s.id}</span>
                <span className="font-mono text-[10px] text-fg-dim/70">{relativeTime(s.scannedAt)}</span>
              </li>
            ))}
          </ul>
        </PgCard>
      )}

      {/* Engine disclaimer */}
      <div className="flex items-start gap-3 rounded-lg border border-[#FFB020]/30 bg-[#FFB020]/[0.06] p-4">
        <ShieldX className="mt-0.5 h-4 w-4 shrink-0 text-[#FFC24E]" />
        <p className="text-[12px] leading-relaxed text-[#FFC24E]">
          <strong className="font-semibold">Demo engine disclosure:</strong> verdicts are produced by a transparent,
          local rule-based analyser (demo ruleset v1.2.0). No machine-learning model and no external threat-intelligence
          API is connected. The same URL always yields the same deterministic result.
        </p>
      </div>
    </div>
  );
}
