"use client";

import { useMemo, useState } from "react";
import { Activity, Download, Search, X } from "lucide-react";
import {
  CardHeader,
  DemoBadge,
  EmptyState,
  ErrorState,
  LoadingState,
  MetaPill,
  PageHeader,
  PgCard,
  SeverityBadge,
} from "@/components/phishguard/primitives";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useEventStore } from "@/lib/phishguard/store";
import { downloadCsv, formatDateTime, relativeTime } from "@/lib/phishguard/format";
import type { EventSeverity } from "@/lib/phishguard/types";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

const SEVERITIES: ("ALL" | EventSeverity)[] = ["ALL", "CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"];

export function EventsPage() {
  const { events, status, error, loadEvents } = useEventStore();
  const [severity, setSeverity] = useState<(typeof SEVERITIES)[number]>("ALL");
  const [query, setQuery] = useState("");
  const { toast } = useToast();

  const counts = useMemo(() => {
    const c: Record<string, number> = { ALL: events.length };
    for (const e of events) c[e.severity] = (c[e.severity] ?? 0) + 1;
    return c;
  }, [events]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    let rows = events;
    if (severity !== "ALL") rows = rows.filter((e) => e.severity === severity);
    if (q) {
      rows = rows.filter(
        (e) =>
          e.id.toLowerCase().includes(q) ||
          e.category.toLowerCase().includes(q) ||
          e.source.toLowerCase().includes(q) ||
          e.description.toLowerCase().includes(q)
      );
    }
    return rows;
  }, [events, severity, query]);

  const exportCsv = () => {
    if (filtered.length === 0) {
      toast({ title: "Nothing to export", description: "No events match the current filters." });
      return;
    }
    const rows: (string | number | null)[][] = [
      ["Event ID", "Timestamp", "Severity", "Category", "Source", "Description"],
      ...filtered.map((e) => [e.id, e.timestamp, e.severity, e.category, e.source, e.description]),
    ];
    downloadCsv(`phishguard-events-${new Date().toISOString().slice(0, 10)}.csv`, rows);
    toast({ title: "CSV exported", description: `${filtered.length} event records written to CSV.` });
  };

  return (
    <div className="space-y-6">
      <PageHeader
        page="events"
        title="Security Events"
        description="SIEM-style event stream produced by the demo engine — detections, system activity and provider diagnostics."
        right={
          <>
            <DemoBadge />
            <Button
              onClick={exportCsv}
              variant="outline"
              size="sm"
              className="border-cyber/40 bg-cyber/10 font-mono text-[11px] tracking-[0.14em] text-[#5CE4F7] hover:bg-cyber/20 hover:text-[#5CE4F7]"
            >
              <Download className="mr-1.5 h-3.5 w-3.5" />
              EXPORT CSV
            </Button>
          </>
        }
      />

      {/* Filters */}
      <PgCard>
        <div className="flex flex-col gap-3 p-4 lg:flex-row lg:items-center">
          <div className="flex min-w-0 flex-1 items-center gap-2.5 rounded-lg border border-border bg-black/35 px-3.5 py-2.5 focus-within:border-cyber/50">
            <Search className="h-4 w-4 shrink-0 text-fg-dim" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search events by ID, category, source or description…"
              className="h-auto border-0 bg-transparent p-0 font-mono text-[12.5px] shadow-none focus-visible:ring-0"
              aria-label="Search security events"
            />
            {query && (
              <button type="button" onClick={() => setQuery("")} aria-label="Clear search" className="text-fg-dim hover:text-fg">
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
          <div className="flex flex-wrap items-center gap-2" role="group" aria-label="Severity filter">
            {SEVERITIES.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setSeverity(s)}
                className={cn(
                  "rounded-md border px-2.5 py-1.5 font-mono text-[10px] tracking-[0.12em] transition-colors",
                  severity === s
                    ? "border-neon/60 bg-neon/15 text-neon"
                    : "border-border text-fg-dim hover:bg-white/[0.04] hover:text-fg"
                )}
              >
                {s} {counts[s] !== undefined && <span className="opacity-60">({counts[s]})</span>}
              </button>
            ))}
          </div>
        </div>
      </PgCard>

      {/* Event table */}
      <PgCard>
        <CardHeader
          title="Event Stream"
          subtitle={`${filtered.length} of ${events.length} events · newest first`}
          icon={Activity}
          right={<MetaPill tone={status === "error" ? "down" : "demo"}>{status === "error" ? "STORE ERROR" : "SNAPSHOT · DEMO"}</MetaPill>}
        />
        {status === "loading" ? (
          <LoadingState rows={7} label="LOADING EVENT STREAM" />
        ) : status === "error" ? (
          <ErrorState message={error ?? "Failed to load events."} onRetry={loadEvents} />
        ) : filtered.length === 0 ? (
          <EmptyState
            icon={Activity}
            title={events.length === 0 ? "No events recorded" : "No matching events"}
            message={
              events.length === 0
                ? "Events appear here as scans and system activity are processed."
                : "Try a different severity filter or search term."
            }
          />
        ) : (
          <div className="max-h-[620px] overflow-auto">
            <table className="w-full min-w-[880px] border-collapse text-left">
              <thead className="sticky top-0 z-10 bg-[#0B130E]">
                <tr className="border-b border-border/80">
                  {["EVENT ID", "TIMESTAMP", "SEVERITY", "CATEGORY", "SOURCE", "DESCRIPTION"].map((h) => (
                    <th key={h} scope="col" className="px-4 py-3 font-mono text-[9px] font-medium tracking-[0.24em] text-fg-dim">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((e) => (
                  <tr key={e.id} className="border-b border-border/40 align-top transition-colors hover:bg-white/[0.02]">
                    <td className="whitespace-nowrap px-4 py-3 font-mono text-[10.5px] text-fg-dim">{e.id}</td>
                    <td className="whitespace-nowrap px-4 py-3 font-mono text-[10.5px] text-fg-dim">
                      {formatDateTime(e.timestamp)}
                      <div className="text-[9px] text-fg-dim/60">{relativeTime(e.timestamp)}</div>
                    </td>
                    <td className="px-4 py-3">
                      <SeverityBadge severity={e.severity} />
                    </td>
                    <td className="whitespace-nowrap px-4 py-3 font-mono text-[10.5px] text-fg/85">{e.category}</td>
                    <td className="whitespace-nowrap px-4 py-3 font-mono text-[10.5px] text-[#5CE4F7]">{e.source}</td>
                    <td className="px-4 py-3 text-[12.5px] leading-relaxed text-fg/90">{e.description}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </PgCard>
    </div>
  );
}
