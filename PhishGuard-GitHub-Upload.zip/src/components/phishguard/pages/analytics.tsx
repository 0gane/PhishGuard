"use client";

import { useCallback, useEffect, useState } from "react";
import {
  BarChart3,
  BrainCircuit,
  Grid3X3,
  LineChart as LineChartIcon,
  PieChart,
  RefreshCw,
  Sigma,
} from "lucide-react";
import {
  CardHeader,
  DemoBadge,
  ErrorState,
  FadeIn,
  LoadingState,
  MetaPill,
  PageHeader,
  PgCard,
  StatCard,
} from "@/components/phishguard/primitives";
import { PhishingLegitChart, RiskDonut, ScanActivityChart, ThreatActivityChart } from "@/components/phishguard/charts";
import { api } from "@/lib/phishguard/api";
import type { DashboardAnalytics } from "@/lib/phishguard/types";

const METRIC_CARDS = [
  { id: "precision", label: "PRECISION", formula: "TP / (TP + FP)", desc: "Share of flagged URLs that were truly phishing." },
  { id: "recall", label: "RECALL", formula: "TP / (TP + FN)", desc: "Share of true phishing URLs successfully caught." },
  { id: "f1", label: "F1 SCORE", formula: "2 · (P · R) / (P + R)", desc: "Harmonic mean balancing precision and recall." },
];

function ConfusionMatrix() {
  const cells = [
    { label: "True Positive", abbr: "TP", value: "—", tone: "text-[#FF5E74]" },
    { label: "False Positive", abbr: "FP", value: "—", tone: "text-[#FFC24E]" },
    { label: "False Negative", abbr: "FN", value: "—", tone: "text-[#5CE4F7]" },
    { label: "True Negative", abbr: "TN", value: "—", tone: "text-neon" },
  ];
  return (
    <div className="grid grid-cols-2 gap-3 p-4 sm:p-5">
      {cells.map((c) => (
        <div
          key={c.abbr}
          className="flex min-h-[104px] flex-col items-center justify-center rounded-lg border border-dashed border-border/80 bg-black/20 p-4 text-center"
        >
          <div className="font-mono text-[9px] tracking-[0.26em] text-fg-dim">{c.abbr}</div>
          <div className={cnMetric(c.tone, "mt-1.5 font-display text-3xl font-bold")}>{c.value}</div>
          <div className="mt-1.5 text-[11px] text-fg-dim">{c.label}</div>
        </div>
      ))}
    </div>
  );
}

function cnMetric(...cls: string[]) {
  return cls.join(" ");
}

export function AnalyticsPage() {
  const [analytics, setAnalytics] = useState<DashboardAnalytics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setAnalytics(await api.getDashboardAnalytics());
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load analytics.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const totals = analytics
    ? {
        scans: analytics.riskDistribution.reduce((a, d) => a + d.value, 0),
        phishing: analytics.riskDistribution.find((d) => d.name === "High risk")?.value ?? 0,
      }
    : null;
  const avgScore = analytics
    ? Math.round(
        (totals!.phishing / Math.max(1, totals!.scans)) * 100
      )
    : 0;

  if (loading && !analytics) {
    return (
      <div className="space-y-6">
        <PageHeader page="analytics" title="Detection Analytics" description="Loading demo analytics…" />
        <PgCard>
          <LoadingState rows={6} label="AGGREGATING SCAN CORPUS" />
        </PgCard>
      </div>
    );
  }

  if (error && !analytics) {
    return (
      <div className="space-y-6">
        <PageHeader page="analytics" title="Detection Analytics" description="Analytics could not be loaded." />
        <PgCard>
          <ErrorState message={error} onRetry={load} />
        </PgCard>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader
        page="analytics"
        title="Detection Analytics"
        description="Trend analysis over the demo scan corpus. Model-quality metrics remain UNAVAILABLE until a real evaluated model is connected — none are invented here."
        right={
          <>
            <DemoBadge />
            <button
              type="button"
              onClick={load}
              className="inline-flex items-center gap-2 rounded-md border border-neon/40 bg-neon/10 px-3.5 py-2 font-mono text-[11px] tracking-[0.16em] text-neon transition-all hover:bg-neon/20"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${loading ? "animate-spin" : ""}`} strokeWidth={2.2} />
              REFRESH
            </button>
          </>
        }
      />

      {/* Summary KPIs */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard index={0} label="Scans in Corpus" value={totals?.scans ?? 0} icon={BarChart3} tone="cyber" hint="Demo dataset persisted locally" />
        <StatCard index={1} label="High-Risk Verdicts" value={totals?.phishing ?? 0} icon={Sigma} tone="danger" hint="Classified by demo rule engine" />
        <StatCard index={2} label="High-Risk Ratio" value={avgScore} suffix="%" icon={PieChart} tone="amber" hint="High-risk share of all scans" />
        <StatCard index={3} label="Model Metrics" value={0} icon={BrainCircuit} tone="neutral" hint="UNAVAILABLE — no evaluated model connected" />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
        <FadeIn>
          <PgCard className="h-full">
            <CardHeader title="Phishing vs Legitimate" subtitle="Daily verdicts · last 14 days" icon={BarChart3} right={<MetaPill tone="warn">DEMO DATA</MetaPill>} />
            <div className="p-3 sm:p-4">{analytics && <PhishingLegitChart data={analytics.phishingVsLegit} />}</div>
          </PgCard>
        </FadeIn>

        <FadeIn delay={0.06}>
          <PgCard className="h-full">
            <CardHeader title="Scan Activity" subtitle="Total scans vs flagged · last 14 days" icon={LineChartIcon} right={<MetaPill tone="warn">DEMO DATA</MetaPill>} />
            <div className="p-3 sm:p-4">{analytics && <ScanActivityChart data={analytics.scanActivity} />}</div>
          </PgCard>
        </FadeIn>

        <FadeIn delay={0.1}>
          <PgCard className="h-full">
            <CardHeader title="Risk Distribution" subtitle="All-time classification spread" icon={PieChart} right={<MetaPill tone="warn">DEMO DATA</MetaPill>} />
            <div className="p-3 sm:p-4">{analytics && <RiskDonut data={analytics.riskDistribution} height={260} centerLabel="TOTAL SCANS" />}</div>
          </PgCard>
        </FadeIn>

        <FadeIn delay={0.14}>
          <PgCard className="h-full">
            <CardHeader title="Threat Activity — 24h" subtitle="Hourly scans vs threats" icon={LineChartIcon} right={<MetaPill tone="warn">DEMO DATA</MetaPill>} />
            <div className="p-3 sm:p-4">{analytics && <ThreatActivityChart data={analytics.activity24h} height={260} />}</div>
          </PgCard>
        </FadeIn>
      </div>

      {/* Model quality — honestly unavailable */}
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
        <PgCard className="flex flex-col">
          <CardHeader
            title="Model Evaluation Metrics"
            subtitle="Precision · Recall · F1"
            icon={BrainCircuit}
            right={<MetaPill tone="down">UNAVAILABLE</MetaPill>}
          />
          <div className="grid flex-1 grid-cols-1 gap-3 p-4 sm:grid-cols-3 sm:p-5">
            {METRIC_CARDS.map((m) => (
              <div
                key={m.id}
                className="flex flex-col items-center justify-center rounded-lg border border-dashed border-border/80 bg-black/20 p-4 text-center"
              >
                <div className="font-mono text-[9px] tracking-[0.26em] text-fg-dim">{m.label}</div>
                <div className="mt-2 font-display text-3xl font-bold text-fg-dim/50">—</div>
                <div className="mt-2 rounded border border-border/60 bg-white/[0.02] px-2 py-1 font-mono text-[9px] text-fg-dim/80">
                  {m.formula}
                </div>
                <p className="mt-2 text-[11px] leading-relaxed text-fg-dim">{m.desc}</p>
              </div>
            ))}
          </div>
          <div className="border-t border-border/60 px-4 py-3 text-[11.5px] leading-relaxed text-fg-dim sm:px-5">
            These metrics appear once the Python backend is connected and the classifier has been evaluated on a held-out
            labelled dataset. Until then this console deliberately reports them as unavailable rather than estimating.
          </div>
        </PgCard>

        <PgCard className="flex flex-col">
          <CardHeader
            title="Confusion Matrix"
            subtitle="Binary: phishing vs legitimate"
            icon={Grid3X3}
            right={<MetaPill tone="down">UNAVAILABLE</MetaPill>}
          />
          <ConfusionMatrix />
          <div className="border-t border-border/60 px-4 py-3 text-[11.5px] leading-relaxed text-fg-dim sm:px-5">
            The matrix will populate from real evaluation runs (TP / FP / FN / TN). The demo rule engine produces verdicts
            on unlabelled input, so no ground truth exists to compute these values.
          </div>
        </PgCard>
      </div>
    </div>
  );
}
