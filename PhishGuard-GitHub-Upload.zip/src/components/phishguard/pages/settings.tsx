"use client";

import { useCallback, useState } from "react";
import {
  ClipboardCheck,
  Database,
  Eye,
  Gauge,
  Link2,
  Palette,
  RotateCcw,
  Save,
  SlidersHorizontal,
  Trash2,
  UserRound,
} from "lucide-react";
import {
  CardHeader,
  DemoBadge,
  MetaPill,
  PageHeader,
  PgCard,
} from "@/components/phishguard/primitives";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { useEventStore, useScanStore, useUiStore } from "@/lib/phishguard/store";
import { api } from "@/lib/phishguard/api";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

function SectionCard({
  title,
  subtitle,
  icon: Icon,
  children,
}: {
  title: string;
  subtitle: string;
  icon: typeof UserRound;
  children: React.ReactNode;
}) {
  return (
    <PgCard>
      <CardHeader title={title} subtitle={subtitle} icon={Icon} />
      <div className="space-y-5 p-4 sm:p-5">{children}</div>
    </PgCard>
  );
}

function SettingRow({
  label,
  description,
  children,
}: {
  label: string;
  description: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex flex-col gap-2.5 border-b border-border/40 pb-4 last:border-0 last:pb-0 sm:flex-row sm:items-center sm:justify-between">
      <div className="min-w-0">
        <div className="text-[13px] font-medium text-fg">{label}</div>
        <p className="mt-0.5 text-[11.5px] leading-relaxed text-fg-dim">{description}</p>
      </div>
      <div className="shrink-0">{children}</div>
    </div>
  );
}

function Segmented<T extends string>({
  value,
  options,
  onChange,
  ariaLabel,
}: {
  value: T;
  options: { id: T; label: string }[];
  onChange: (v: T) => void;
  ariaLabel: string;
}) {
  return (
    <div role="radiogroup" aria-label={ariaLabel} className="inline-flex rounded-md border border-border p-0.5">
      {options.map((o) => (
        <button
          key={o.id}
          type="button"
          role="radio"
          aria-checked={value === o.id}
          onClick={() => onChange(o.id)}
          className={cn(
            "rounded px-3 py-1.5 font-mono text-[10px] tracking-[0.12em] transition-colors",
            value === o.id ? "bg-neon/15 text-neon" : "text-fg-dim hover:text-fg"
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function SettingsPage() {
  const settings = useUiStore((s) => s.settings);
  const updateSettings = useUiStore((s) => s.updateSettings);
  const loadScans = useScanStore((s) => s.loadScans);
  const loadEvents = useEventStore((s) => s.loadEvents);
  const { toast } = useToast();

  const [backendDraft, setBackendDraft] = useState(settings.backendUrlOverride);
  const [clearing, setClearing] = useState(false);

  const saveBackend = useCallback(() => {
    updateSettings({ backendUrlOverride: backendDraft.trim() });
    toast({
      title: "Backend URL saved",
      description: backendDraft.trim()
        ? `Live adapter will target ${backendDraft.trim()} — run a health check in API Management.`
        : "Override cleared — the mock adapter will be used.",
    });
  }, [backendDraft, updateSettings, toast]);

  const clearData = useCallback(async () => {
    setClearing(true);
    try {
      await api.clearHistory();
      await Promise.all([loadScans(), loadEvents()]);
      toast({ title: "Demo data reset", description: "Scan history and events were reseeded from the demo dataset." });
    } catch (err) {
      toast({ title: "Reset failed", description: err instanceof Error ? err.message : "Unknown error", variant: "destructive" });
    } finally {
      setClearing(false);
    }
  }, [loadScans, loadEvents, toast]);

  return (
    <div className="space-y-6">
      <PageHeader
        page="settings"
        title="Console Settings"
        description="Local operator preferences for this demo console. Everything persists in your browser — nothing is transmitted to a server."
        right={<DemoBadge />}
      />

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
        <SectionCard title="Operator Profile" subtitle="Displayed in the console header" icon={UserRound}>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="op-name" className="font-mono text-[9.5px] tracking-[0.2em] text-fg-dim">
                OPERATOR NAME
              </Label>
              <Input
                id="op-name"
                value={settings.operatorName}
                onChange={(e) => updateSettings({ operatorName: e.target.value })}
                className="border-border bg-black/35 font-mono text-[12.5px]"
                placeholder="demo.analyst"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="op-org" className="font-mono text-[9.5px] tracking-[0.2em] text-fg-dim">
                ORGANISATION
              </Label>
              <Input
                id="op-org"
                value={settings.organisation}
                onChange={(e) => updateSettings({ organisation: e.target.value })}
                className="border-border bg-black/35 font-mono text-[12.5px]"
                placeholder="DemoSOC"
              />
            </div>
          </div>
        </SectionCard>

        <SectionCard title="Scanner Preferences" subtitle="Applied to every demo scan" icon={SlidersHorizontal}>
          <SettingRow
            label="Auto-read clipboard"
            description="Focus the URL field automatically when arriving from other pages."
          >
            <Switch
              checked={settings.autoClipboard}
              onCheckedChange={(v) => updateSettings({ autoClipboard: v })}
              aria-label="Toggle auto clipboard"
            />
          </SettingRow>
          <SettingRow
            label="Detection sensitivity"
            description="STRICT raises weights for HTTP and high-abuse TLDs in the demo ruleset."
          >
            <Segmented
              ariaLabel="Detection sensitivity"
              value={settings.sensitivity}
              options={[
                { id: "STANDARD", label: "STANDARD" },
                { id: "STRICT", label: "STRICT" },
              ]}
              onChange={(v) => updateSettings({ sensitivity: v })}
            />
          </SettingRow>
          <SettingRow label="Persist scan history" description="Store scans in browser localStorage between sessions.">
            <Switch
              checked={settings.persistHistory}
              onCheckedChange={(v) => updateSettings({ persistHistory: v })}
              aria-label="Toggle history persistence"
            />
          </SettingRow>
        </SectionCard>

        <SectionCard title="Appearance" subtitle="Motion and ambient effects" icon={Palette}>
          <SettingRow
            label="Console animations"
            description="Scan lines, count-ups and radar sweeps. Automatically disabled when your OS prefers reduced motion."
          >
            <Switch
              checked={settings.motionEnabled}
              onCheckedChange={(v) => updateSettings({ motionEnabled: v })}
              aria-label="Toggle animations"
            />
          </SettingRow>
          <SettingRow label="Background grid" description="Subtle SOC grid texture behind the console.">
            <Switch
              checked={settings.showGrid}
              onCheckedChange={(v) => updateSettings({ showGrid: v })}
              aria-label="Toggle background grid"
            />
          </SettingRow>
          <SettingRow label="Accent colour" description="Primary accent used across active states and charts.">
            <Segmented
              ariaLabel="Accent colour"
              value={settings.accent}
              options={[
                { id: "NEON", label: "NEON GREEN" },
                { id: "CYBER", label: "ELECTRIC CYAN" },
              ]}
              onChange={(v) => updateSettings({ accent: v })}
            />
          </SettingRow>
        </SectionCard>

        <SectionCard title="Backend Integration" subtitle="Point the UI at your FastAPI service" icon={Link2}>
          <div className="space-y-1.5">
            <Label htmlFor="backend-url" className="font-mono text-[9.5px] tracking-[0.2em] text-fg-dim">
              BACKEND URL (RUNTIME OVERRIDE)
            </Label>
            <Input
              id="backend-url"
              value={backendDraft}
              onChange={(e) => setBackendDraft(e.target.value)}
              placeholder="https://phishguard-api.example.com"
              className="border-border bg-black/35 font-mono text-[12.5px]"
              spellCheck={false}
            />
            <p className="text-[11px] leading-relaxed text-fg-dim">
              Leave empty to use the mock adapter. The build-time default comes from{" "}
              <span className="font-mono text-[#5CE4F7]">NEXT_PUBLIC_PHISHGUARD_API_URL</span>.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2.5">
            <Button onClick={saveBackend} size="sm" className="bg-neon font-mono text-[11px] tracking-[0.14em] text-[#04130A] hover:bg-neon/85">
              <Save className="mr-1.5 h-3.5 w-3.5" />
              SAVE URL
            </Button>
            <Button
              onClick={() => {
                setBackendDraft("");
                updateSettings({ backendUrlOverride: "" });
                toast({ title: "Override cleared", description: "The mock adapter will be used." });
              }}
              size="sm"
              variant="outline"
              className="border-border font-mono text-[11px] tracking-[0.14em] text-fg-dim hover:text-fg"
            >
              <RotateCcw className="mr-1.5 h-3.5 w-3.5" />
              RESET TO MOCK
            </Button>
            <MetaPill tone="demo" className="ml-auto">
              <Eye className="h-3 w-3" /> CURRENT: {settings.backendUrlOverride ? "LIVE" : "MOCK"}
            </MetaPill>
          </div>
        </SectionCard>

        <SectionCard title="Data Management" subtitle="Local demo store controls" icon={Database} >
          <SettingRow
            label="Reset demo dataset"
            description="Clears local scan history and reseeds the deterministic demo dataset (scans + events)."
          >
            <Button
              onClick={clearData}
              disabled={clearing}
              size="sm"
              variant="outline"
              className="border-danger/50 bg-danger/10 font-mono text-[11px] tracking-[0.14em] text-[#FF5E74] hover:bg-danger/20 hover:text-[#FF5E74]"
            >
              <Trash2 className="mr-1.5 h-3.5 w-3.5" />
              {clearing ? "RESETTING…" : "CLEAR & RESEED"}
            </Button>
          </SettingRow>
          <SettingRow
            label="Clipboard quick-paste"
            description="Show the PASTE action prominently in the scanner console."
          >
            <MetaPill tone={settings.autoClipboard ? "ok" : "neutral"}>
              <ClipboardCheck className="h-3 w-3" />
              {settings.autoClipboard ? "ENABLED" : "MANUAL"}
            </MetaPill>
          </SettingRow>
        </SectionCard>

        <SectionCard title="About This Console" subtitle="Project context" icon={Gauge}>
          <div className="space-y-3 text-[12.5px] leading-relaxed text-fg-dim">
            <p>
              <strong className="text-fg">PHISHGUARD</strong> — Intelligent Phishing Detection & Monitoring System.
              This build is the <strong className="text-fg">frontend + demo layer</strong> of a BCA final-year project:
              a Security Operations Centre console with a working heuristic scanner, mock API adapter and a prepared
              FastAPI integration contract.
            </p>
            <ul className="list-inside list-disc space-y-1.5 pl-1">
              <li>Detection engine: local demo rulepack (no ML, no external calls)</li>
              <li>Data: deterministic demo datasets, labelled everywhere as DEMO DATA</li>
              <li>Next step: connect the Python FastAPI backend via API Management</li>
            </ul>
          </div>
        </SectionCard>
      </div>
    </div>
  );
}
