"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  ArrowUpRight,
  Ban,
  CircleCheck,
  RefreshCw,
  ScanEye,
  ShieldAlert,
  ShieldHalf,
  Siren,
  Sparkles,
  SquareTerminal,
} from "lucide-react";
import {
  CardHeader,
  DemoBadge,
  FadeIn,
  LoadingState,
  MetaPill,
  PageHeader,
  PgCard,
  SeverityBadge,
  StatCard,
  StatusDot,
  ErrorState,
  type HealthTone,
} from "@/components/phishguard/primitives";
import { RiskDonut, ThreatActivityChart } from "@/components/phishguard/charts";
import { TerminalFeed, ThreatRadar, type TerminalLine } from "@/components/phishguard/visuals";
import { api } from "@/lib/phishguard/api";
import type { ApiHealthReport, DashboardAnalytics, DashboardSummary } from "@/lib/phishguard/types";
import { useEventStore } from "@/lib/phishguard/store";
import { relativeTime } from "@/lib/phishguard/format";
import type { PageId } from "@/lib/phishguard/types";

export function OverviewPage({ navigate }: { navigate: (p: PageId) => void }) {
  const [summary, setSummary] = useState<DashboardSummary | null>(null);
  const [analytics, setAnalytics] = useState<DashboardAnalytics | null>(null);
  const [health, setHealth] = useState<ApiHealthReport | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { events, status: eventStatus, loadEvents } = useEventStore();

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [s, a, h] = await Promise.all([
        api.getDashboardSummary(),
        api.getDashboardAnalytics(),
        api.getHealth(),
      ]);
      setSummary(s);
      setAnalytics(a);
      setHealth(h);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load dashboard data.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    if (eventStatus === "idle") loadEvents();
  }, [load, eventStatus, loadEvents]);

  /* Terminal feed derived from the latest events */
  const terminalLines: TerminalLine[] = useMemo(() => {
    if (eventStatus === "loading") {
      return [{ text: "$ tail -f /var/log/phishguard/events.log", tone: "neon" }];
    }
    const colors: Record<string, TerminalLine["tone"]> = {
      CRITICAL: "danger",
      HIGH: "amber",
      MEDIUM: "amber",
      LOW: "cyber",
      INFO: "dim",
    };
    return [
      { text: "$ tail -f /var/log/phishguard/events.log", tone: "neon" },
      ...events.slice(0, 16).map((e) => {
        const t = new Date(e.timestamp);
        const hh = String(t.getHours()).padStart(2, "0");
        const mm = String(t.getMinutes()).padStart(2, "0");
        const ss = String(t.getSeconds()).padStart(2, "0");
        return {
          text: `[${hh}:${mm}:${ss}] ${e.severity.padEnd(8)} ${e.category.padEnd(20)} ${e.description}`,
          tone: colors[e.severity],
        };
      }),
      ...(eventStatus === "ready" && events.length === 0
        ? [{ text: "no events recorded yet — run a scan from the Live Scanner", tone: "dim" as const }]
        : []),
    ];
  }, [events, eventStatus]);

  const engineTone = (status: string): HealthTone =>
    status === "CONNECTED" ? "ok" : status === "DEMO" ? "demo" : status === "ERROR" ? "down" : "warn";

  if (loading && !summary) {
    return (
      <div className="space-y-6">
        <PageHeader
          page="overview"
          title="SOC Command Centre"
          description="Loading demo telemetry from the local mock adapter…"
        />
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <PgCard key={i}>
              <LoadingState rows={2} label={`LOADING METRIC ${i + 1}`} />
            </PgCard>
          ))}
        </div>
        <PgCard>
          <LoadingState rows={5} label="FETCHING ACTIVITY SERIES" />
        </PgCard>
      </div>
    );
  }

  if (error && !summary) {
    return (
      <div className="space-y-6">
        <PageHeader page="overview" title="SOC Command Centre" description="Demo telemetry could not be loaded." />
        <PgCard>
          <ErrorState message={error} onRetry={load} />
        </PgCard>
      </div>
    );
  }

  const recentEvents = events.slice(0, 7);

  return (
    <div className="space-y-6">
      <PageHeader
        page="overview"
        title="SOC Command Centre"
        description="Consolidated phishing detection telemetry across the demo environment. Engine verdicts are produced by the local heuristic demo engine."
        right={
          <>
            <DemoBadge />
            <button
              type="button"
              onClick={load}
              className="inline-flex items-center gap-2 rounded-md border border-neon/40 bg-neon/10 px-3.5 py-2 font-mono text-[11px] tracking-[0.16em] text-neon transition-all hover:bg-neon/20 hover:shadow-[0_0_16px_rgba(57,255,20,0.25)]"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${loading ? "animate-spin" : ""}`} strokeWidth={2.2} />
              REFRESH
            </button>
          </>
        }
      />

      {/* KPI row */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          index={0}
          label="Total URLs Scanned"
          value={summary?.totalScanned ?? 0}
          icon={ScanEye}
          tone="cyber"
          hint={`${summary?.scansLast24h ?? 0} ${(summary?.scansLast24h ?? 0) === 1 ? "scan" : "scans"} in the last 24h`}
        />
        <StatCard
          index={1}
          label="Phishing Threats Detected"
          value={summary?.phishingDetected ?? 0}
          icon={Siren}
          tone="danger"
          hint={`${summary?.detectionRate ?? 0}% of scans flagged high-risk`}
        />
        <StatCard
          index={2}
          label="Low-Risk URLs"
          value={summary?.lowRisk ?? 0}
          icon={CircleCheck}
          tone="neon"
          hint="No strong phishing indicators"
        />
        <StatCard
          index={3}
          label="High-Risk URLs"
          value={summary?.highRisk ?? 0}
          icon={Ban}
          tone="amber"
          hint={`${summary?.mediumRisk ?? 0} additional medium-risk verdicts`}
        />
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
        <FadeIn className="xl:col-span-2">
          <PgCard className="h-full">
            <CardHeader
              title="Threat Activity — Last 24 Hours"
              subtitle="Scans executed vs. high-risk verdicts per hour"
              icon={Sparkles}
              right={<MetaPill tone="warn">DEMO DATA</MetaPill>}
            />
            <div className="p-3 sm:p-4">
              {analytics ? <ThreatActivityChart data={analytics.activity24h} /> : <LoadingState rows={4} />}
            </div>
          </PgCard>
        </FadeIn>

        <FadeIn delay={0.08}>
          <PgCard className="h-full">
            <CardHeader
              title="Risk Distribution"
              subtitle="Classification spread across all scans"
              icon={ShieldHalf}
              right={<MetaPill tone="warn">DEMO DATA</MetaPill>}
            />
            <div className="p-3 sm:p-4">
              {analytics ? (
                <RiskDonut data={analytics.riskDistribution} centerLabel="TOTAL SCANS" />
              ) : (
                <LoadingState rows={4} />
              )}
            </div>
          </PgCard>
        </FadeIn>
      </div>

      {/* Events + engine health + radar */}
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
        <FadeIn className="xl:col-span-2">
          <PgCard className="flex h-full flex-col">
            <CardHeader
              title="Recent Security Events"
              subtitle="Newest detections and system activity"
              icon={ShieldAlert}
              right={
                <button
                  type="button"
                  onClick={() => navigate("events")}
                  className="inline-flex items-center gap-1.5 rounded-md border border-border px-2.5 py-1.5 font-mono text-[10px] tracking-[0.14em] text-fg-dim transition-colors hover:border-neon/40 hover:text-neon"
                >
                  VIEW ALL <ArrowUpRight className="h-3 w-3" />
                </button>
              }
            />
            {eventStatus === "loading" ? (
              <LoadingState rows={5} label="LOADING EVENT STREAM" />
            ) : recentEvents.length === 0 ? (
              <div className="p-5 text-center font-mono text-[11px] text-fg-dim">No events recorded yet.</div>
            ) : (
              <ul className="divide-y divide-border/60">
                {recentEvents.map((e) => (
                  <li key={e.id} className="flex items-start gap-3 px-4 py-3 transition-colors hover:bg-white/[0.02] sm:px-5">
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <SeverityBadge severity={e.severity} />
                        <span className="font-mono text-[10px] tracking-[0.14em] text-fg-dim">{e.category}</span>
                        <span className="font-mono text-[10px] text-fg-dim/70">· {relativeTime(e.timestamp)}</span>
                      </div>
                      <p className="mt-1.5 truncate text-[13px] text-fg/90">{e.description}</p>
                    </div>
                    <span className="mt-0.5 hidden shrink-0 font-mono text-[10px] text-fg-dim/70 sm:block">{e.id}</span>
                  </li>
                ))}
              </ul>
            )}
          </PgCard>
        </FadeIn>

        <FadeIn delay={0.08}>
          <PgCard className="flex h-full flex-col">
            <CardHeader title="Detection Engine Health" subtitle="Live component status" icon={ShieldHalf} />
            <div className="flex-1 space-y-3 p-4 sm:p-5">
              {(health?.services ?? []).map((s) => (
                <div key={s.id} className="rounded-lg border border-border/70 bg-black/20 p-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[13px] font-medium text-fg">{s.name}</span>
                    <StatusDot tone={engineTone(s.status)} label={s.status === "DEMO" ? "DEMO" : s.status === "UNAVAILABLE" ? "OFFLINE" : s.status} pulse={s.status === "DEMO"} />
                  </div>
                  <p className="mt-1.5 text-[11.5px] leading-relaxed text-fg-dim">{s.detail}</p>
                  <div className="mt-2 flex items-center gap-3 font-mono text-[9.5px] tracking-[0.12em] text-fg-dim/70">
                    <span>{s.version}</span>
                    {s.latencyMs != null && <span>· {s.latencyMs}ms</span>}
                  </div>
                </div>
              ))}
            </div>
            <div className="flex items-center justify-center border-t border-border/60 py-4">
              <ThreatRadar size={190} />
            </div>
          </PgCard>
        </FadeIn>
      </div>

      {/* Terminal feed */}
      <FadeIn delay={0.05}>
        <PgCard>
          <CardHeader
            title="Activity Feed"
            subtitle="Terminal stream — security event log (demo)"
            icon={SquareTerminal}
            right={<MetaPill tone="demo">STDOUT · /var/log/phishguard</MetaPill>}
          />
          <TerminalFeed lines={terminalLines} height={250} />
        </PgCard>
      </FadeIn>
    </div>
  );
}
