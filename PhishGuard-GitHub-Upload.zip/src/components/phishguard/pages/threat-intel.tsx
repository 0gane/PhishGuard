"use client";

import { useCallback, useState } from "react";
import {
  BadgeCheck,
  Ban,
  Database,
  Globe2,
  Radar,
  Search,
  ServerCrash,
  ShieldQuestion,
  TriangleAlert,
} from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import {
  CardHeader,
  DemoBadge,
  EmptyState,
  LoadingState,
  MetaPill,
  PageHeader,
  PgCard,
} from "@/components/phishguard/primitives";
import { formatDateTime, relativeTime, truncateMiddle } from "@/lib/phishguard/format";
import { InvalidUrlError, normalizeUrl } from "@/lib/phishguard/scanner-engine";
import { api, getProviderCatalog } from "@/lib/phishguard/api";
import type { ProviderMatch, ThreatIntelResult } from "@/lib/phishguard/types";
import { cn } from "@/lib/utils";

const REPUTATION_STYLE: Record<ThreatIntelResult["reputation"], { color: string; bg: string; border: string; icon: typeof Ban }> = {
  MALICIOUS: { color: "text-[#FF5E74]", bg: "bg-[#FF304F]/10", border: "border-[#FF304F]/45", icon: Ban },
  SUSPICIOUS: { color: "text-[#FFC24E]", bg: "bg-[#FFB020]/10", border: "border-[#FFB020]/45", icon: TriangleAlert },
  CLEAN: { color: "text-neon", bg: "bg-neon/10", border: "border-neon/40", icon: BadgeCheck },
  UNKNOWN: { color: "text-fg-dim", bg: "bg-white/[0.03]", border: "border-border", icon: ShieldQuestion },
};

const PROVIDER_STATUS_TONE: Record<string, string> = {
  DEMO: "border-[#00E5FF]/35 bg-[#00E5FF]/10 text-[#5CE4F7]",
  CONNECTED: "border-neon/40 bg-neon/10 text-neon",
  ERROR: "border-danger/45 bg-danger/10 text-[#FF5E74]",
  UNAVAILABLE: "border-border bg-white/[0.03] text-fg-dim",
};

function MatchRow({ match }: { match: ProviderMatch }) {
  const verdict =
    match.status === "ERROR" || match.status === "UNAVAILABLE"
      ? { label: "NOT AVAILABLE", cls: "border-border bg-white/[0.03] text-fg-dim" }
      : match.matched
        ? { label: "MATCH", cls: "border-[#FF304F]/45 bg-[#FF304F]/10 text-[#FF5E74]" }
        : { label: "NO MATCH", cls: "border-neon/35 bg-neon/10 text-neon" };

  return (
    <li className="px-4 py-3.5 sm:px-5">
      <div className="flex flex-wrap items-center gap-x-3 gap-y-2">
        <span className="text-[13px] font-medium text-fg">{match.providerName}</span>
        <span className={cn("rounded border px-1.5 py-px font-mono text-[8.5px] tracking-[0.14em]", PROVIDER_STATUS_TONE[match.status])}>
          {match.status}
        </span>
        <span className={cn("ml-auto rounded border px-2 py-0.5 font-mono text-[9.5px] font-semibold tracking-[0.14em]", verdict.cls)}>
          {verdict.label}
        </span>
      </div>
      <p className="mt-1.5 text-[12.5px] leading-relaxed text-fg-dim">{match.detail}</p>
      <div className="mt-2 flex flex-wrap items-center gap-3 font-mono text-[9.5px] tracking-[0.1em] text-fg-dim/70">
        {match.category && <span>CATEGORY: {match.category.toUpperCase()}</span>}
        {match.confidence != null && <span>CONFIDENCE: {match.confidence}%</span>}
      </div>
    </li>
  );
}

export function ThreatIntelPage() {
  const [query, setQuery] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ThreatIntelResult | null>(null);
  const providers = getProviderCatalog();

  const runLookup = useCallback(async () => {
    setError(null);
    if (!query.trim()) {
      setError("Enter a domain or URL to look up.");
      return;
    }
    try {
      const normalized = normalizeUrl(query);
      const host = new URL(normalized).hostname;
      setLoading(true);
      setResult(null);
      const res = await api.lookupThreatIntel(host);
      setResult(res);
    } catch (err) {
      setError(
        err instanceof InvalidUrlError
          ? err.message
          : err instanceof Error
            ? `Lookup failed — ${err.message}`
            : "Lookup failed."
      );
    } finally {
      setLoading(false);
    }
  }, [query]);

  const style = result ? REPUTATION_STYLE[result.reputation] : null;
  const ReputationIcon = style?.icon ?? ShieldQuestion;

  return (
    <div className="space-y-6">
      <PageHeader
        page="threat-intel"
        title="Threat Intelligence"
        description="Cross-reference a target against the demo intelligence layer. Real provider lookups activate once the FastAPI backend and server-side keys are configured."
        right={<DemoBadge />}
      />

      {/* Lookup console */}
      <PgCard>
        <CardHeader title="Domain / URL Lookup" subtitle="Deterministic demo dataset — same query, same answer" icon={Search} />
        <div className="p-4 sm:p-6">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              runLookup();
            }}
            className="flex flex-col gap-3 sm:flex-row"
          >
            <label htmlFor="intel-query" className="sr-only">
              Domain or URL
            </label>
            <div className="flex min-w-0 flex-1 items-center gap-2.5 rounded-lg border border-cyber/30 bg-black/40 px-4 py-3 transition-all focus-within:border-cyber/70 focus-within:shadow-[0_0_20px_rgba(0,229,255,0.14)]">
              <Globe2 className="h-4 w-4 shrink-0 text-[#00E5FF]" />
              <input
                id="intel-query"
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  setError(null);
                }}
                placeholder="e.g. paypal-verify-account.tk  ·  wikipedia.org"
                spellCheck={false}
                autoComplete="off"
                className="min-w-0 flex-1 bg-transparent font-mono text-[13px] text-fg placeholder:text-fg-dim/50 focus:outline-none"
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className={cn(
                "inline-flex h-[46px] items-center justify-center gap-2 rounded-lg px-6 font-mono text-[12px] font-bold tracking-[0.2em] transition-all",
                loading
                  ? "cursor-wait border border-cyber/40 bg-cyber/10 text-[#5CE4F7]"
                  : "border border-cyber/60 bg-cyber/15 text-[#5CE4F7] hover:bg-cyber/25 hover:shadow-[0_0_24px_rgba(0,229,255,0.3)]"
              )}
            >
              <Radar className={cn("h-4 w-4", loading && "animate-spin")} />
              RUN LOOKUP
            </button>
          </form>
          {error && (
            <p role="alert" className="mt-3 flex items-center gap-2 font-mono text-[11.5px] text-[#FF5E74]">
              <TriangleAlert className="h-3.5 w-3.5" /> {error}
            </p>
          )}
        </div>
      </PgCard>

      {/* Result */}
      <AnimatePresence mode="wait">
        {loading && (
          <motion.div key="loading" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <PgCard>
              <LoadingState label="QUERYING DEMO INTELLIGENCE LAYER" rows={4} />
            </PgCard>
          </motion.div>
        )}

        {!loading && result && (
          <motion.div
            key={result.query + result.checkedAt}
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="space-y-4"
          >
            {/* Verdict banner */}
            <div className={cn("flex flex-col gap-4 rounded-xl border p-5 sm:flex-row sm:items-center", style!.bg, style!.border)}>
              <span className={cn("flex h-14 w-14 shrink-0 items-center justify-center rounded-xl border", style!.border)}>
                <ReputationIcon className={cn("h-7 w-7", style!.color)} strokeWidth={1.9} />
              </span>
              <div className="min-w-0 flex-1">
                <div className={cn("font-display text-xl font-bold tracking-wide", style!.color)}>
                  {result.reputation}
                </div>
                <div className="mt-1 truncate font-mono text-[12px] text-fg-dim">
                  {result.normalizedTarget} · {result.category}
                </div>
                <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 font-mono text-[9.5px] tracking-[0.14em] text-fg-dim/70">
                  <span>QUERY: {truncateMiddle(result.query, 48)}</span>
                  <span>LAST CHECKED: {formatDateTime(result.checkedAt)}</span>
                </div>
              </div>
              <div className="w-full sm:w-44">
                <div className="mb-1.5 flex justify-between font-mono text-[9px] tracking-[0.2em] text-fg-dim">
                  <span>CONFIDENCE</span>
                  <span style={{ color: style!.color }}>{result.confidence}%</span>
                </div>
                <div className="h-1.5 overflow-hidden rounded-full bg-white/[0.06]">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${result.confidence}%` }}
                    transition={{ duration: 0.8, ease: "easeOut" }}
                    className="h-full rounded-full"
                    style={{ background: style!.color, boxShadow: `0 0 10px ${style!.color}66` }}
                  />
                </div>
              </div>
            </div>

            {/* Provider matches */}
            <PgCard>
              <CardHeader
                title="Provider Cross-Match"
                subtitle="5 providers queried — 2 unavailable in demo mode"
                icon={Database}
                right={<MetaPill tone="warn">SIMULATED RESPONSES</MetaPill>}
              />
              <ul className="divide-y divide-border/50">
                {result.matches.map((m) => (
                  <MatchRow key={m.providerId} match={m} />
                ))}
              </ul>
            </PgCard>
          </motion.div>
        )}

        {!loading && !result && (
          <PgCard>
            <EmptyState
              icon={Radar}
              title="No lookup performed yet"
              message="Enter a domain or URL above to cross-check it against the demo intelligence providers."
            />
          </PgCard>
        )}
      </AnimatePresence>

      {/* Provider catalogue */}
      <PgCard>
        <CardHeader
          title="Intelligence Provider Status"
          subtitle="Demo catalogue — honest states, no simulated 'connected' claims"
          icon={ServerCrash}
          right={<MetaPill tone="demo">2/5 OPERATIONAL (DEMO)</MetaPill>}
        />
        <div className="grid grid-cols-1 gap-4 p-4 sm:grid-cols-2 sm:p-5 xl:grid-cols-3">
          {providers.map((p) => (
            <div
              key={p.id}
              className={cn(
                "rounded-lg border p-4",
                p.status === "ERROR"
                  ? "border-danger/35 bg-danger/[0.05]"
                  : p.status === "UNAVAILABLE"
                    ? "border-border/70 bg-white/[0.015] opacity-80"
                    : "border-border/80 bg-black/20"
              )}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="truncate text-[13px] font-medium text-fg">{p.name}</div>
                  <div className="mt-0.5 font-mono text-[9.5px] tracking-[0.16em] text-fg-dim">{p.kind.toUpperCase()}</div>
                </div>
                <span className={cn("shrink-0 rounded border px-1.5 py-0.5 font-mono text-[8.5px] font-semibold tracking-[0.14em]", PROVIDER_STATUS_TONE[p.status])}>
                  {p.status}
                </span>
              </div>
              <p className="mt-2.5 min-h-[36px] text-[11.5px] leading-relaxed text-fg-dim">{p.note}</p>
              <div className="mt-3 border-t border-border/50 pt-2.5 font-mono text-[9px] tracking-[0.12em] text-fg-dim/70">
                LAST CHECKED: {p.lastChecked ? relativeTime(p.lastChecked) : "— (demo provider)"}
              </div>
            </div>
          ))}
        </div>
      </PgCard>
    </div>
  );
}
