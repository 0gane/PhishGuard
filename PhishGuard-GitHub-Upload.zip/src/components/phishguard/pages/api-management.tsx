"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Braces,
  CheckCircle2,
  KeyRound,
  Link2,
  PlugZap,
  RefreshCw,
  ServerCog,
  ShieldCheck,
  Timer,
  XCircle,
} from "lucide-react";
import {
  CardHeader,
  DemoBadge,
  LoadingState,
  MetaPill,
  PageHeader,
  PgCard,
  StatusDot,
  type HealthTone,
} from "@/components/phishguard/primitives";
import { api, currentApiSource, resolveBackendUrl } from "@/lib/phishguard/api";
import type { ApiHealthReport } from "@/lib/phishguard/types";
import { formatDateTime } from "@/lib/phishguard/format";
import { cn } from "@/lib/utils";

const PLANNED_ENDPOINTS = [
  { method: "POST", path: "/api/v1/scans", purpose: "Run a scan against the detection backend" },
  { method: "GET", path: "/api/v1/scans", purpose: "List recorded scans (paginated)" },
  { method: "GET", path: "/api/v1/scans/{id}", purpose: "Fetch a single scan verdict" },
  { method: "GET", path: "/api/v1/dashboard/summary", purpose: "Aggregate KPI feed for the overview page" },
  { method: "GET", path: "/api/v1/dashboard/analytics", purpose: "Chart series for analytics views" },
  { method: "GET", path: "/api/v1/health", purpose: "Service + dependency health probe" },
];

const METHOD_TONE: Record<string, string> = {
  POST: "border-neon/40 bg-neon/10 text-neon",
  GET: "border-cyber/40 bg-cyber/10 text-[#5CE4F7]",
  DELETE: "border-danger/40 bg-danger/10 text-[#FF5E74]",
};

/** Secrets are managed server-side — the browser only ever sees masked placeholders. */
const SERVER_SIDE_SECRETS = [
  { key: "OPENPHISH_API_KEY", used: "Threat feed ingestion (FastAPI worker)" },
  { key: "URLHAUS_API_KEY", used: "URLhaus feed ingestion (FastAPI worker)" },
  { key: "VT_API_KEY", used: "VirusTotal v3 lookups (FastAPI worker)" },
];

export function ApiManagementPage() {
  const [health, setHealth] = useState<ApiHealthReport | null>(null);
  const [loading, setLoading] = useState(true);
  const [checking, setChecking] = useState(false);
  const [probeError, setProbeError] = useState<string | null>(null);
  const backendUrl = resolveBackendUrl();
  const apiSource = currentApiSource();

  const load = useCallback(async () => {
    setLoading(true);
    try {
      setHealth(await api.getHealth());
      setProbeError(null);
    } catch (err) {
      setProbeError(err instanceof Error ? err.message : "Health check failed.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const runProbe = useCallback(async () => {
    setChecking(true);
    setProbeError(null);
    try {
      const report = await api.getHealth();
      setHealth(report);
      if (report.backendConfigured && !report.reachable) {
        setProbeError(report.errorMessage ?? "Backend is not reachable.");
      }
    } catch (err) {
      setProbeError(err instanceof Error ? err.message : "Probe failed.");
    } finally {
      setChecking(false);
    }
  }, []);

  const serviceTone = (status: string): HealthTone =>
    status === "CONNECTED" ? "ok" : status === "DEMO" ? "demo" : status === "ERROR" ? "down" : "down";

  if (loading && !health) {
    return (
      <div className="space-y-6">
        <PageHeader page="api" title="API Management" description="Loading service status…" />
        <PgCard>
          <LoadingState rows={5} label="PROBING SERVICES" />
        </PgCard>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader
        page="api"
        title="API Management"
        description="Backend connectivity, engine status and the integration contract for the planned FastAPI backend. Secrets are never exposed to the client."
        right={<DemoBadge />}
      />

      {/* Backend connection panel */}
      <PgCard scanline={checking}>
        <CardHeader
          title="Backend Connection"
          subtitle="FastAPI service discovery & health probe"
          icon={PlugZap}
          right={
            <MetaPill tone={apiSource === "LIVE" ? "ok" : "demo"}>
              ADAPTER: {apiSource}
            </MetaPill>
          }
        />
        <div className="grid grid-cols-1 gap-4 p-4 sm:p-5 lg:grid-cols-3">
          <div className="rounded-lg border border-border/80 bg-black/25 p-4 lg:col-span-2">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="min-w-0">
                <div className="font-mono text-[9px] tracking-[0.26em] text-fg-dim">TARGET URL</div>
                <div className="mt-1.5 truncate font-mono text-[12.5px] text-fg">
                  {backendUrl ?? "— not configured (mock adapter active) —"}
                </div>
              </div>
              <StatusDot
                tone={health?.backendConfigured ? (health.reachable ? "ok" : "down") : "demo"}
                label={health?.backendConfigured ? (health.reachable ? "REACHABLE" : "UNREACHABLE") : "MOCK MODE"}
                pulse={health?.reachable}
              />
            </div>
            <div className="mt-4 grid grid-cols-2 gap-3 font-mono text-[10.5px] sm:grid-cols-4">
              {[
                ["HTTP STATUS", health?.httpStatus ? String(health.httpStatus) : "—"],
                ["LATENCY", health?.latencyMs != null ? `${health.latencyMs} ms` : "—"],
                ["LAST CHECK", health ? formatDateTime(health.checkedAt) : "—"],
                ["TIMEOUT", "10 s"],
              ].map(([k, v]) => (
                <div key={k} className="rounded-md border border-border/60 bg-white/[0.02] px-2.5 py-2">
                  <div className="text-[8.5px] tracking-[0.2em] text-fg-dim">{k}</div>
                  <div className="mt-1 truncate text-fg">{v}</div>
                </div>
              ))}
            </div>
            <div className="mt-4 rounded-md border border-border/60 bg-black/30 px-3 py-2.5 font-mono text-[10.5px] leading-relaxed text-fg-dim">
              <span className="text-fg-dim/60"># .env.local</span>
              <br />
              NEXT_PUBLIC_PHISHGUARD_API_URL=<span className="text-neon">https://your-fastapi-host</span>
              <br />
              <span className="text-fg-dim/60"># Configure in Settings to override at runtime.</span>
            </div>
          </div>

          <div className="flex flex-col justify-between gap-3 rounded-lg border border-border/80 bg-black/25 p-4">
            <div>
              <div className="font-mono text-[9px] tracking-[0.26em] text-fg-dim">HEALTH CHECK</div>
              <p className="mt-2 text-[12px] leading-relaxed text-fg-dim">
                Sends <span className="font-mono text-[#5CE4F7]">GET /api/v1/health</span> to the configured backend.
                In mock mode this reports the local demo services honestly — no fake success states.
              </p>
              {probeError && (
                <p role="alert" className="mt-3 flex items-start gap-2 rounded-md border border-danger/40 bg-danger/10 p-2.5 font-mono text-[10.5px] leading-relaxed text-[#FF5E74]">
                  <XCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                  {probeError}
                </p>
              )}
              {health?.backendConfigured && health.reachable && (
                <p className="mt-3 flex items-center gap-2 rounded-md border border-neon/40 bg-neon/10 p-2.5 font-mono text-[10.5px] text-neon">
                  <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />
                  Backend responded OK
                </p>
              )}
            </div>
            <button
              type="button"
              onClick={runProbe}
              disabled={checking}
              className={cn(
                "inline-flex h-10 items-center justify-center gap-2 rounded-lg font-mono text-[11px] font-bold tracking-[0.18em] transition-all",
                checking
                  ? "cursor-wait border border-cyber/40 bg-cyber/10 text-[#5CE4F7]"
                  : "border border-neon/50 bg-neon/15 text-neon hover:bg-neon/25 hover:shadow-[0_0_18px_rgba(57,255,20,0.3)]"
              )}
            >
              <RefreshCw className={cn("h-3.5 w-3.5", checking && "animate-spin")} />
              {checking ? "PROBING…" : "RUN HEALTH CHECK"}
            </button>
          </div>
        </div>
      </PgCard>

      {/* Service status grid */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {(health?.services ?? []).map((s) => (
          <PgCard key={s.id} className="p-4 sm:p-5">
            <div className="flex items-start justify-between gap-2">
              <span className="text-[13.5px] font-semibold text-fg">{s.name}</span>
              <StatusDot
                tone={serviceTone(s.status)}
                label={s.status === "UNAVAILABLE" ? "OFFLINE" : s.status}
                pulse={s.status === "DEMO"}
              />
            </div>
            <div className="mt-1 font-mono text-[9px] tracking-[0.2em] text-fg-dim">{s.role.toUpperCase()}</div>
            <p className="mt-2.5 min-h-[48px] text-[11.5px] leading-relaxed text-fg-dim">{s.detail}</p>
            <div className="mt-3 flex items-center justify-between border-t border-border/50 pt-2.5 font-mono text-[9.5px] text-fg-dim/70">
              <span>{s.version}</span>
              <span className="flex items-center gap-1">
                <Timer className="h-3 w-3" />
                {s.latencyMs != null ? `${s.latencyMs}ms` : "n/a"}
              </span>
            </div>
          </PgCard>
        ))}
      </div>

      {/* Endpoint contract + secrets */}
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-5">
        <PgCard className="xl:col-span-3">
          <CardHeader title="Planned Backend Contract" subtitle="Endpoints the UI will consume once FastAPI is connected" icon={Braces} />
          <ul className="divide-y divide-border/50">
            {PLANNED_ENDPOINTS.map((e) => (
              <li key={e.path} className="flex flex-wrap items-center gap-x-3 gap-y-1.5 px-4 py-3 sm:px-5">
                <span className={cn("rounded border px-1.5 py-0.5 font-mono text-[9px] font-bold tracking-[0.14em]", METHOD_TONE[e.method])}>
                  {e.method}
                </span>
                <span className="font-mono text-[12px] text-fg">{e.path}</span>
                <span className="ml-auto text-[11.5px] text-fg-dim">{e.purpose}</span>
              </li>
            ))}
          </ul>
        </PgCard>

        <div className="space-y-4 xl:col-span-2">
          <PgCard>
            <CardHeader title="Secret Handling" subtitle="No API keys are stored or sent in the browser" icon={KeyRound} />
            <ul className="space-y-2.5 p-4 sm:p-5">
              {SERVER_SIDE_SECRETS.map((s) => (
                <li key={s.key} className="flex items-center gap-3 rounded-md border border-border/60 bg-black/25 px-3 py-2.5">
                  <ShieldCheck className="h-4 w-4 shrink-0 text-neon" />
                  <div className="min-w-0 flex-1">
                    <div className="font-mono text-[11px] text-fg">{s.key}</div>
                    <div className="truncate font-mono text-[9.5px] text-fg-dim">{s.used}</div>
                  </div>
                  <span className="font-mono text-[10px] tracking-[0.14em] text-fg-dim/70">••••••••</span>
                  <MetaPill tone="ok" className="hidden sm:inline-flex">SERVER-SIDE</MetaPill>
                </li>
              ))}
            </ul>
          </PgCard>

          <PgCard>
            <CardHeader title="Error Handling" subtitle="How the UI responds to backend failures" icon={ServerCog} />
            <div className="space-y-2 p-4 text-[12px] leading-relaxed text-fg-dim sm:p-5">
              <p><CheckCircle2 className="mr-1.5 inline h-3.5 w-3.5 text-neon" /> Timeouts abort requests after 10 s and surface a retry action.</p>
              <p><CheckCircle2 className="mr-1.5 inline h-3.5 w-3.5 text-neon" /> Connection failures render honest error states — never simulated success.</p>
              <p><CheckCircle2 className="mr-1.5 inline h-3.5 w-3.5 text-neon" /> HTTP error codes are mapped to readable messages per endpoint.</p>
              <p><CheckCircle2 className="mr-1.5 inline h-3.5 w-3.5 text-neon" /> The mock adapter keeps the UI fully functional when no backend is configured.</p>
            </div>
          </PgCard>
        </div>
      </div>

      {/* Integration note */}
      <div className="flex items-start gap-3 rounded-lg border border-cyber/30 bg-cyber/[0.05] p-4">
        <Link2 className="mt-0.5 h-4 w-4 shrink-0 text-[#5CE4F7]" />
        <p className="text-[12px] leading-relaxed text-[#9FEBF5]">
          <strong className="font-semibold">Integration path:</strong> implement the FastAPI service against the contract
          above, set <span className="font-mono">NEXT_PUBLIC_PHISHGUARD_API_URL</span> (or the runtime override in
          Settings), and the UI switches from the mock adapter to live calls automatically — no component changes
          required.
        </p>
      </div>
    </div>
  );
}
