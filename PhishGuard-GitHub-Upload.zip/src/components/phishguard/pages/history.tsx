"use client";

import { useMemo, useState } from "react";
import {
  ArrowUpDown,
  Clock3,
  Download,
  Filter,
  Search,
  ScanEye,
  X,
} from "lucide-react";
import {
  CardHeader,
  DemoBadge,
  EmptyState,
  ErrorState,
  LoadingState,
  MetaPill,
  PageHeader,
  PgCard,
  RiskBadge,
} from "@/components/phishguard/primitives";
import { RiskGauge } from "@/components/phishguard/visuals";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { formatDateTime, downloadCsv, relativeTime, truncateMiddle } from "@/lib/phishguard/format";
import { useScanStore } from "@/lib/phishguard/store";
import type { RiskLevel, ScanResult } from "@/lib/phishguard/types";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

type RiskFilter = "ALL" | RiskLevel;
type SortKey = "newest" | "oldest" | "score-desc" | "score-asc";

const RISK_FILTERS: { id: RiskFilter; label: string }[] = [
  { id: "ALL", label: "ALL" },
  { id: "HIGH_RISK", label: "HIGH" },
  { id: "MEDIUM_RISK", label: "MEDIUM" },
  { id: "LOW_RISK", label: "LOW" },
];

const SOURCE_TONE: Record<string, string> = {
  MANUAL: "border-neon/35 bg-neon/10 text-neon",
  API: "border-[#00E5FF]/35 bg-[#00E5FF]/10 text-[#5CE4F7]",
  SCHEDULED: "border-[#84968A]/40 bg-white/[0.03] text-fg-dim",
};

export function HistoryPage({ onScanAgain }: { onScanAgain: (url: string) => void }) {
  const { scans, status, error, loadScans } = useScanStore();
  const [query, setQuery] = useState("");
  const [riskFilter, setRiskFilter] = useState<RiskFilter>("ALL");
  const [sourceFilter, setSourceFilter] = useState<"ALL" | ScanResult["source"]>("ALL");
  const [sort, setSort] = useState<SortKey>("newest");
  const [selected, setSelected] = useState<ScanResult | null>(null);
  const { toast } = useToast();

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    let rows = scans;
    if (q) {
      rows = rows.filter(
        (s) => s.url.toLowerCase().includes(q) || s.host.toLowerCase().includes(q) || s.id.toLowerCase().includes(q)
      );
    }
    if (riskFilter !== "ALL") rows = rows.filter((s) => s.classification === riskFilter);
    if (sourceFilter !== "ALL") rows = rows.filter((s) => s.source === sourceFilter);
    switch (sort) {
      case "newest":
        rows = [...rows].sort((a, b) => (a.scannedAt < b.scannedAt ? 1 : -1));
        break;
      case "oldest":
        rows = [...rows].sort((a, b) => (a.scannedAt > b.scannedAt ? 1 : -1));
        break;
      case "score-desc":
        rows = [...rows].sort((a, b) => b.riskScore - a.riskScore);
        break;
      case "score-asc":
        rows = [...rows].sort((a, b) => a.riskScore - b.riskScore);
        break;
    }
    return rows;
  }, [scans, query, riskFilter, sourceFilter, sort]);

  const exportCsv = () => {
    if (filtered.length === 0) {
      toast({ title: "Nothing to export", description: "No rows match the current filters." });
      return;
    }
    const rows: (string | number | null)[][] = [
      ["Scan ID", "URL", "Host", "Scanned At", "Risk Score", "Classification", "Source", "Engine"],
      ...filtered.map((s) => [s.id, s.url, s.host, s.scannedAt, s.riskScore, s.classification, s.source, s.engine]),
    ];
    downloadCsv(`phishguard-scan-history-${new Date().toISOString().slice(0, 10)}.csv`, rows);
    toast({ title: "CSV exported", description: `${filtered.length} scan records written to CSV.` });
  };

  const sortLabel: Record<SortKey, string> = {
    newest: "NEWEST FIRST",
    oldest: "OLDEST FIRST",
    "score-desc": "SCORE ↓",
    "score-asc": "SCORE ↑",
  };

  return (
    <div className="space-y-6">
      <PageHeader
        page="history"
        title="Scan History"
        description="Every scan recorded by this console instance. Records persist locally in your browser (demo store)."
        right={
          <>
            <DemoBadge />
            <Button
              onClick={exportCsv}
              variant="outline"
              size="sm"
              className="border-neon/40 bg-neon/10 font-mono text-[11px] tracking-[0.14em] text-neon hover:bg-neon/20 hover:text-neon"
            >
              <Download className="mr-1.5 h-3.5 w-3.5" />
              EXPORT CSV
            </Button>
          </>
        }
      />

      {/* Controls */}
      <PgCard>
        <div className="flex flex-col gap-3 p-4 lg:flex-row lg:items-center lg:gap-4">
          <div className="flex min-w-0 flex-1 items-center gap-2.5 rounded-lg border border-border bg-black/35 px-3.5 py-2.5 transition-colors focus-within:border-neon/50">
            <Search className="h-4 w-4 shrink-0 text-fg-dim" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by URL, domain or scan ID…"
              className="h-auto border-0 bg-transparent p-0 font-mono text-[12.5px] shadow-none focus-visible:ring-0 focus-visible:ring-offset-0"
              aria-label="Search scan history"
            />
            {query && (
              <button type="button" onClick={() => setQuery("")} aria-label="Clear search" className="text-fg-dim hover:text-fg">
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <span className="flex items-center gap-1.5 font-mono text-[9.5px] tracking-[0.2em] text-fg-dim">
              <Filter className="h-3 w-3" /> RISK
            </span>
            {RISK_FILTERS.map((f) => (
              <button
                key={f.id}
                type="button"
                onClick={() => setRiskFilter(f.id)}
                className={cn(
                  "rounded-md border px-2.5 py-1.5 font-mono text-[10px] tracking-[0.12em] transition-colors",
                  riskFilter === f.id
                    ? "border-neon/60 bg-neon/15 text-neon"
                    : "border-border text-fg-dim hover:bg-white/[0.04] hover:text-fg"
                )}
              >
                {f.label}
              </button>
            ))}
            <select
              value={sourceFilter}
              onChange={(e) => setSourceFilter(e.target.value as typeof sourceFilter)}
              aria-label="Filter by scan source"
              className="rounded-md border border-border bg-panel px-2.5 py-1.5 font-mono text-[10px] tracking-[0.1em] text-fg-dim focus:outline-none"
            >
              <option value="ALL">SOURCE: ALL</option>
              <option value="MANUAL">MANUAL</option>
              <option value="API">API</option>
              <option value="SCHEDULED">SCHEDULED</option>
            </select>
            <button
              type="button"
              onClick={() => {
                const order: SortKey[] = ["newest", "oldest", "score-desc", "score-asc"];
                const next = order[(order.indexOf(sort) + 1) % order.length];
                setSort(next);
              }}
              className="inline-flex items-center gap-1.5 rounded-md border border-border px-2.5 py-1.5 font-mono text-[10px] tracking-[0.1em] text-fg-dim transition-colors hover:border-cyber/40 hover:text-[#5CE4F7]"
              aria-label="Change sort order"
            >
              <ArrowUpDown className="h-3 w-3" />
              {sortLabel[sort]}
            </button>
          </div>
        </div>
      </PgCard>

      {/* Table */}
      <PgCard>
        <CardHeader
          title="Scan Records"
          subtitle={`${filtered.length} of ${scans.length} records shown`}
          icon={ScanEye}
          right={
            <MetaPill tone={status === "error" ? "down" : "demo"}>
              {status === "error" ? "STORE ERROR" : "LOCAL STORE"}
            </MetaPill>
          }
        />
        {status === "loading" ? (
          <LoadingState rows={6} label="LOADING SCAN HISTORY" />
        ) : status === "error" ? (
          <ErrorState message={error ?? "Failed to load scan history."} onRetry={loadScans} />
        ) : filtered.length === 0 ? (
          <EmptyState
            icon={Clock3}
            title={scans.length === 0 ? "No scans yet" : "No matching records"}
            message={
              scans.length === 0
                ? "Run your first analysis from the Live Scanner page."
                : "Adjust the search term or filters to see more results."
            }
          />
        ) : (
          <div className="max-h-[600px] overflow-auto">
            <table className="w-full min-w-[820px] border-collapse text-left">
              <thead className="sticky top-0 z-10 bg-[#0B130E]">
                <tr className="border-b border-border/80">
                  {["URL / DOMAIN", "SCAN ID", "TIMESTAMP", "SCORE", "CLASSIFICATION", "SOURCE"].map((h) => (
                    <th key={h} scope="col" className="px-4 py-3 font-mono text-[9px] font-medium tracking-[0.24em] text-fg-dim">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((s) => (
                  <tr
                    key={s.id}
                    tabIndex={0}
                    onClick={() => setSelected(s)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" || e.key === " ") {
                        e.preventDefault();
                        setSelected(s);
                      }
                    }}
                    className="cursor-pointer border-b border-border/40 transition-colors hover:bg-neon/[0.04] focus:bg-neon/[0.06] focus:outline-none"
                    aria-label={`View details for scan ${s.id}`}
                  >
                    <td className="max-w-[340px] px-4 py-3">
                      <div className="truncate font-mono text-[12px] text-fg/90" title={s.url}>
                        {truncateMiddle(s.url, 58)}
                      </div>
                      <div className="mt-0.5 truncate font-mono text-[9.5px] text-fg-dim">{s.host}</div>
                    </td>
                    <td className="px-4 py-3 font-mono text-[10.5px] text-fg-dim">{s.id}</td>
                    <td className="whitespace-nowrap px-4 py-3 font-mono text-[10.5px] text-fg-dim">
                      {formatDateTime(s.scannedAt)}
                      <div className="text-[9px] text-fg-dim/60">{relativeTime(s.scannedAt)}</div>
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={cn(
                          "font-display text-[15px] font-bold",
                          s.classification === "HIGH_RISK"
                            ? "text-[#FF5E74]"
                            : s.classification === "MEDIUM_RISK"
                              ? "text-[#FFC24E]"
                              : "text-neon"
                        )}
                      >
                        {s.riskScore}
                      </span>
                      <span className="ml-1 font-mono text-[9px] text-fg-dim">/100</span>
                    </td>
                    <td className="px-4 py-3">
                      <RiskBadge level={s.classification} />
                    </td>
                    <td className="px-4 py-3">
                      <span className={cn("rounded border px-1.5 py-0.5 font-mono text-[9px] tracking-[0.14em]", SOURCE_TONE[s.source])}>
                        {s.source}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </PgCard>

      {/* Details sheet */}
      <Sheet open={!!selected} onOpenChange={(open) => !open && setSelected(null)}>
        <SheetContent
          side="right"
          className="w-full overflow-y-auto border-border bg-[#0A120C] p-0 sm:max-w-[560px]"
        >
          {selected && (
            <div className="space-y-5 p-5">
              <SheetHeader className="space-y-1 p-0 text-left">
                <SheetTitle className="font-display text-lg tracking-wide text-fg">Scan Details</SheetTitle>
                <SheetDescription className="font-mono text-[10.5px] text-fg-dim">
                  {selected.id} · {formatDateTime(selected.scannedAt)} · SOURCE: {selected.source}
                </SheetDescription>
              </SheetHeader>

              <div className="overflow-x-auto rounded-lg border border-border bg-black/35 px-3.5 py-3 font-mono text-[12px] text-fg/90">
                {selected.url}
              </div>

              <div className="flex justify-center">
                <RiskGauge score={selected.riskScore} classification={selected.classification} size={190} />
              </div>

              <div className={cn("rounded-lg border p-3.5", selected.classification === "HIGH_RISK" ? "border-danger/40 bg-danger/[0.07]" : selected.classification === "MEDIUM_RISK" ? "border-[#FFB020]/40 bg-[#FFB020]/[0.06]" : "border-neon/40 bg-neon/[0.06]")}>
                <div className="font-mono text-[9px] tracking-[0.3em] text-fg-dim">RECOMMENDED ACTION</div>
                <p className="mt-1.5 text-[13px] leading-relaxed text-fg">{selected.recommendedAction}</p>
              </div>

              <div>
                <div className="mb-2 font-mono text-[9.5px] tracking-[0.24em] text-fg-dim">URL STRUCTURE</div>
                <dl className="grid grid-cols-2 gap-2 font-mono text-[10.5px]">
                  {[
                    ["HOST", selected.structure.host],
                    ["PROTOCOL", selected.structure.protocol],
                    ["TLS", selected.structure.secure ? "YES" : "NO"],
                    ["TLD", selected.structure.tld ? `.${selected.structure.tld}` : "—"],
                    ["PORT", selected.structure.port ?? "—"],
                    ["LENGTH", `${selected.structure.length} chars`],
                  ].map(([k, v]) => (
                    <div key={k} className="rounded-md border border-border/60 bg-white/[0.02] px-2.5 py-2">
                      <dt className="text-[8.5px] tracking-[0.2em] text-fg-dim">{k}</dt>
                      <dd className="mt-0.5 truncate text-fg" title={v}>{v}</dd>
                    </div>
                  ))}
                </dl>
              </div>

              <div>
                <div className="mb-2 font-mono text-[9.5px] tracking-[0.24em] text-fg-dim">
                  DETECTION REASONS ({selected.reasons.length})
                </div>
                <ul className="space-y-2">
                  {selected.reasons.map((r) => (
                    <li key={r.code} className="rounded-md border border-border/60 bg-white/[0.02] p-3">
                      <div className="flex items-center gap-2">
                        <span className={cn("font-mono text-[10px] font-bold", r.weight > 0 ? "text-[#FF5E74]" : "text-neon")}>
                          {r.weight > 0 ? `+${r.weight}` : r.weight}
                        </span>
                        <span className="text-[12.5px] font-medium text-fg">{r.label}</span>
                      </div>
                      <p className="mt-1 text-[11.5px] leading-relaxed text-fg-dim">{r.detail}</p>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="flex flex-wrap gap-2.5 border-t border-border/60 pt-4">
                <Button
                  size="sm"
                  onClick={() => {
                    setSelected(null);
                    onScanAgain(selected.url);
                  }}
                  className="bg-neon font-mono text-[11px] tracking-[0.14em] text-[#04130A] hover:bg-neon/85"
                >
                  <ScanEye className="mr-1.5 h-3.5 w-3.5" />
                  RE-SCAN THIS URL
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setSelected(null)}
                  className="border-border font-mono text-[11px] tracking-[0.14em] text-fg-dim hover:text-fg"
                >
                  CLOSE
                </Button>
              </div>
            </div>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}
