"use client";

import { ShieldAlert } from "lucide-react";

export function Footer() {
  return (
    <footer className="mt-auto border-t border-border/70 bg-ink-2/60">
      <div className="flex flex-col items-center justify-between gap-2 px-4 py-4 text-center sm:flex-row sm:px-6 sm:text-left">
        <div className="font-mono text-[10px] tracking-[0.16em] text-fg-dim/80">
          PHISHGUARD v1.0.0-demo · DETECT. ANALYSE. DEFEND.
        </div>
        <div className="flex items-center gap-2 font-mono text-[10px] tracking-[0.1em] text-[#FFC24E]">
          <ShieldAlert className="h-3.5 w-3.5" strokeWidth={2} />
          <span>
            ALL DATA ON THIS CONSOLE IS <strong className="font-semibold">DEMO DATA</strong> — NOT CONNECTED TO LIVE
            THREAT INTELLIGENCE OR A PRODUCTION DETECTION MODEL.
          </span>
        </div>
      </div>
      <div className="h-[env(safe-area-inset-bottom)]" />
    </footer>
  );
}
