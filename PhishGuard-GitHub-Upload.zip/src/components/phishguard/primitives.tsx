"use client";

import {
  Activity,
  AlertTriangle,
  CheckCircle2,
  Eye,
  Fingerprint,
  Gauge,
  History,
  LayoutDashboard,
  Network,
  Radar,
  ScanLine,
  ServerCog,
  Settings2,
  ShieldAlert,
  ShieldCheck,
  TerminalSquare,
  WifiOff,
  type LucideIcon,
} from "lucide-react";
import { motion, useReducedMotion } from "framer-motion";
import type { EventSeverity, RiskLevel } from "@/lib/phishguard/types";
import { RISK_META, SEVERITY_META } from "@/lib/phishguard/format";
import { useCountUp } from "@/hooks/phishguard/use-phishguard";
import { cn } from "@/lib/utils";

/* ── Icons registry (single source for sidebar + headers) ───────────────── */

export const PAGE_ICONS: Record<string, LucideIcon> = {
  overview: LayoutDashboard,
  scanner: ScanLine,
  "threat-intel": Radar,
  history: History,
  analytics: Gauge,
  events: Activity,
  api: ServerCog,
  settings: Settings2,
};

export const SEVERITY_ICONS: Record<EventSeverity, LucideIcon> = {
  CRITICAL: ShieldAlert,
  HIGH: AlertTriangle,
  MEDIUM: Eye,
  LOW: Fingerprint,
  INFO: TerminalSquare,
};

/* ── Cards ──────────────────────────────────────────────────────────────── */

export function PgCard({
  children,
  className,
  scanline = false,
}: {
  children: React.ReactNode;
  className?: string;
  scanline?: boolean;
}) {
  return (
    <div className={cn("pg-card overflow-hidden", className)}>
      {scanline && (
        <div className="pointer-events-none absolute inset-x-0 top-0 z-10">
          <div className="animate-scanline h-[2px] w-full bg-gradient-to-r from-transparent via-neon/60 to-transparent" />
        </div>
      )}
      {children}
    </div>
  );
}

export function CardHeader({
  title,
  subtitle,
  icon: Icon,
  right,
  className,
}: {
  title: string;
  subtitle?: string;
  icon?: LucideIcon;
  right?: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("flex items-start justify-between gap-3 border-b border-border/70 px-4 py-3 sm:px-5", className)}>
      <div className="flex min-w-0 items-center gap-2.5">
        {Icon && (
          <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md border border-neon/25 bg-neon/10">
            <Icon className="h-3.5 w-3.5 text-neon" strokeWidth={2} />
          </span>
        )}
        <div className="min-w-0">
          <h3 className="font-display text-[13px] font-semibold uppercase tracking-[0.14em] text-fg">
            {title}
          </h3>
          {subtitle && <p className="mt-0.5 truncate text-xs text-fg-dim">{subtitle}</p>}
        </div>
      </div>
      {right && <div className="shrink-0">{right}</div>}
    </div>
  );
}

/* ── Status / meta indicators ───────────────────────────────────────────── */

export type HealthTone = "ok" | "demo" | "warn" | "down" | "neutral";

const TONE_COLORS: Record<HealthTone, { text: string; ring: string }> = {
  ok: { text: "text-[#7CFF5E]", ring: "bg-[#39FF14]" },
  demo: { text: "text-[#5CE4F7]", ring: "bg-[#00E5FF]" },
  warn: { text: "text-[#FFC24E]", ring: "bg-[#FFB020]" },
  down: { text: "text-[#FF5E74]", ring: "bg-[#FF304F]" },
  neutral: { text: "text-fg-dim", ring: "bg-[#84968A]" },
};

export function StatusDot({
  tone = "ok",
  label,
  pulse = true,
  className,
}: {
  tone?: HealthTone;
  label?: string;
  pulse?: boolean;
  className?: string;
}) {
  const c = TONE_COLORS[tone];
  return (
    <span className={cn("inline-flex items-center gap-2", className)}>
      <span className="relative flex h-2 w-2">
        {pulse && <span className={cn("animate-ping-dot absolute inline-flex h-full w-full rounded-full opacity-60", c.ring)} />}
        <span className={cn("relative inline-flex h-2 w-2 rounded-full", c.ring)} />
      </span>
      {label && <span className={cn("font-mono text-[10.5px] tracking-[0.12em]", c.text)}>{label}</span>}
    </span>
  );
}

export function MetaPill({
  children,
  tone = "neutral",
  className,
}: {
  children: React.ReactNode;
  tone?: HealthTone;
  className?: string;
}) {
  const tones: Record<HealthTone, string> = {
    ok: "border-[#39FF14]/35 bg-[#39FF14]/10 text-[#8CFF6F]",
    demo: "border-[#00E5FF]/35 bg-[#00E5FF]/10 text-[#5CE4F7]",
    warn: "border-[#FFB020]/40 bg-[#FFB020]/10 text-[#FFC24E]",
    down: "border-[#FF304F]/45 bg-[#FF304F]/10 text-[#FF5E74]",
    neutral: "border-border bg-white/[0.03] text-fg-dim",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 font-mono text-[10px] font-medium tracking-[0.14em]",
        tones[tone],
        className
      )}
    >
      {children}
    </span>
  );
}

function FlaskGlyph() {
  return (
    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M10 2v7.5L4.5 19a2 2 0 0 0 1.7 3h11.6a2 2 0 0 0 1.7-3L14 9.5V2" />
      <path d="M8.5 2h7" />
    </svg>
  );
}

export function DemoBadge({ className }: { className?: string }) {
  return (
    <MetaPill tone="warn" className={className} aria-label="Demo data notice">
      <FlaskGlyph />
      DEMO DATA
    </MetaPill>
  );
}

export function RiskBadge({ level, score }: { level: RiskLevel; score?: number }) {
  const meta = RISK_META[level];
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 whitespace-nowrap rounded-md border px-2 py-0.5 font-mono text-[10.5px] font-semibold tracking-[0.1em]",
        meta.bg,
        meta.border,
        meta.color
      )}
    >
      <span className="h-1.5 w-1.5 rounded-full" style={{ background: meta.dot }} />
      {meta.label}
      {score !== undefined && <span className="opacity-80">· {score}</span>}
    </span>
  );
}

export function SeverityBadge({ severity }: { severity: EventSeverity }) {
  const meta = SEVERITY_META[severity];
  const Icon = SEVERITY_ICONS[severity];
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 whitespace-nowrap rounded-md border px-2 py-0.5 font-mono text-[10px] font-semibold tracking-[0.1em]",
        meta.bg,
        meta.border,
        meta.color,
        severity === "CRITICAL" && "animate-flicker"
      )}
    >
      <Icon className="h-3 w-3" strokeWidth={2.2} />
      {severity}
    </span>
  );
}

/* ── Page scaffolding ───────────────────────────────────────────────────── */

export function PageHeader({
  page,
  title,
  description,
  right,
}: {
  page: string;
  title: string;
  description: string;
  right?: React.ReactNode;
}) {
  const Icon = PAGE_ICONS[page] ?? ShieldCheck;
  return (
    <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div className="min-w-0">
        <div className="flex items-center gap-2 font-mono text-[10.5px] tracking-[0.3em] text-fg-dim">
          <Icon className="h-3.5 w-3.5 text-neon" strokeWidth={2} />
          PHISHGUARD / {page.toUpperCase().replace("-", " ")}
        </div>
        <h1 className="mt-2 font-display text-2xl font-bold tracking-tight text-fg sm:text-[28px]">
          {title}
        </h1>
        <p className="mt-1 max-w-2xl text-[13px] leading-relaxed text-fg-dim">{description}</p>
      </div>
      {right && <div className="flex shrink-0 flex-wrap items-center gap-2">{right}</div>}
    </div>
  );
}

/* ── States ─────────────────────────────────────────────────────────────── */

export function LoadingState({
  label = "FETCHING DATA",
  rows = 3,
  className,
}: {
  label?: string;
  rows?: number;
  className?: string;
}) {
  return (
    <div className={cn("p-4 sm:p-5", className)} role="status" aria-live="polite">
      <div className="flex items-center gap-2 font-mono text-[10.5px] tracking-[0.24em] text-[#00E5FF]">
        <Network className="h-3.5 w-3.5 animate-pulse" />
        {label}
        <span className="animate-caret text-neon">▊</span>
      </div>
      <div className="mt-4 space-y-2.5">
        {Array.from({ length: rows }).map((_, i) => (
          <div key={i} className="pg-skeleton h-9 rounded-md" style={{ opacity: 1 - i * 0.18 }} />
        ))}
      </div>
    </div>
  );
}

export function ErrorState({
  title = "CONNECTION ERROR",
  message,
  onRetry,
  className,
}: {
  title?: string;
  message: string;
  onRetry?: () => void;
  className?: string;
}) {
  return (
    <div className={cn("flex flex-col items-center justify-center gap-3 p-8 text-center", className)} role="alert">
      <span className="flex h-11 w-11 items-center justify-center rounded-full border border-danger/40 bg-danger/10">
        <WifiOff className="h-5 w-5 text-danger" strokeWidth={2} />
      </span>
      <div>
        <div className="font-mono text-[11px] font-semibold tracking-[0.24em] text-[#FF5E74]">{title}</div>
        <p className="mx-auto mt-1.5 max-w-md text-[13px] text-fg-dim">{message}</p>
      </div>
      {onRetry && (
        <button
          onClick={onRetry}
          className="rounded-md border border-neon/40 bg-neon/10 px-3.5 py-1.5 font-mono text-[11px] tracking-[0.18em] text-neon transition-colors hover:bg-neon/20"
        >
          RETRY
        </button>
      )}
    </div>
  );
}

export function EmptyState({
  icon: Icon = Radar,
  title,
  message,
  action,
  className,
}: {
  icon?: LucideIcon;
  title: string;
  message: string;
  action?: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("flex flex-col items-center justify-center gap-3 px-6 py-12 text-center", className)}>
      <span className="flex h-12 w-12 items-center justify-center rounded-full border border-border bg-white/[0.02]">
        <Icon className="h-5 w-5 text-fg-dim" strokeWidth={1.8} />
      </span>
      <div>
        <div className="font-display text-[13px] font-semibold uppercase tracking-[0.18em] text-fg">{title}</div>
        <p className="mx-auto mt-1 max-w-sm text-[13px] text-fg-dim">{message}</p>
      </div>
      {action}
    </div>
  );
}

/* ── Motion helpers ─────────────────────────────────────────────────────── */

export function FadeIn({
  children,
  delay = 0,
  className,
}: {
  children: React.ReactNode;
  delay?: number;
  className?: string;
}) {
  const reduce = useReducedMotion();
  const active = !reduce;
  return (
    <motion.div
      initial={active ? { opacity: 0, y: 10 } : false}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay, ease: [0.21, 0.6, 0.35, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

export function StatCard({
  label,
  value,
  suffix,
  icon: Icon,
  tone = "neutral",
  hint,
  index = 0,
}: {
  label: string;
  value: number;
  suffix?: string;
  icon: LucideIcon;
  tone?: "neutral" | "neon" | "cyber" | "amber" | "danger";
  hint?: string;
  index?: number;
}) {
  const toneMap: Record<string, { text: string; iconBg: string; iconText: string; bar: string }> = {
    neutral: { text: "text-fg", iconBg: "bg-white/[0.04] border-border", iconText: "text-fg-dim", bar: "from-fg-dim/40" },
    neon: { text: "text-neon", iconBg: "bg-neon/10 border-neon/30", iconText: "text-neon", bar: "from-neon/70" },
    cyber: { text: "text-[#00E5FF]", iconBg: "bg-[#00E5FF]/10 border-[#00E5FF]/30", iconText: "text-[#00E5FF]", bar: "from-[#00E5FF]/70" },
    amber: { text: "text-[#FFB020]", iconBg: "bg-[#FFB020]/10 border-[#FFB020]/30", iconText: "text-[#FFB020]", bar: "from-[#FFB020]/70" },
    danger: { text: "text-[#FF304F]", iconBg: "bg-[#FF304F]/10 border-[#FF304F]/30", iconText: "text-[#FF304F]", bar: "from-[#FF304F]/70" },
  };
  const t = toneMap[tone];
  return (
    <FadeIn delay={index * 0.06}>
      <PgCard className="group relative h-full p-4 transition-transform duration-200 hover:-translate-y-0.5 sm:p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="font-mono text-[10px] uppercase tracking-[0.22em] text-fg-dim">{label}</div>
            <div className={cn("mt-2 font-display text-[30px] font-bold leading-none tracking-tight sm:text-[34px]", t.text)}>
              <CountUp value={value} />
              {suffix && <span className="ml-1 text-base font-semibold opacity-70">{suffix}</span>}
            </div>
            {hint && <div className="mt-2 truncate text-[11.5px] text-fg-dim">{hint}</div>}
          </div>
          <span className={cn("flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border", t.iconBg)}>
            <Icon className={cn("h-4 w-4", t.iconText)} strokeWidth={2} />
          </span>
        </div>
        <div className="mt-4 h-[3px] w-full overflow-hidden rounded-full bg-white/[0.05]">
          <div className={cn("h-full w-2/3 rounded-full bg-gradient-to-r to-transparent", t.bar)} />
        </div>
      </PgCard>
    </FadeIn>
  );
}

export function CountUp({ value, duration = 900 }: { value: number; duration?: number }) {
  const v = useCountUp(value, duration);
  return <>{v.toLocaleString("en-US")}</>;
}

export function CheckItem({ text, tone = "ok" }: { text: string; tone?: "ok" | "info" }) {
  return (
    <li className="flex items-start gap-2.5 text-[13px] leading-relaxed text-fg-dim">
      <CheckCircle2 className={cn("mt-0.5 h-4 w-4 shrink-0", tone === "ok" ? "text-neon" : "text-[#00E5FF]")} strokeWidth={2} />
      <span>{text}</span>
    </li>
  );
}
