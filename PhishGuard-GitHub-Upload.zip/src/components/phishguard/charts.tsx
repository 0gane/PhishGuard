"use client";

import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ComposedChart,
  Legend,
  Line,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { DashboardAnalytics, TimeSeriesPoint } from "@/lib/phishguard/types";

/* ── Shared styling tokens ──────────────────────────────────────────────── */

const AXIS = {
  tick: { fill: "#84968A", fontSize: 10, fontFamily: "var(--font-jetbrains-mono), monospace" },
  axisLine: { stroke: "#1B2B20" },
  tickLine: false as const,
};

const GRID = { stroke: "rgba(232,245,236,0.06)", strokeDasharray: "3 6" };

function SocTooltip({ active, payload, label, unit }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-lg border border-neon/25 bg-[#0A120C]/95 px-3 py-2 shadow-[0_0_24px_rgba(57,255,20,0.12)] backdrop-blur">
      <div className="font-mono text-[10px] tracking-[0.2em] text-fg-dim">{label}</div>
      {payload.map((entry: any, i: number) => (
        <div key={i} className="mt-1 flex items-center gap-2 font-mono text-[11px]">
          <span className="h-2 w-2 rounded-full" style={{ background: entry.color || entry.fill }} />
          <span className="text-fg-dim">{entry.name}</span>
          <span className="ml-auto font-semibold text-fg">
            {entry.value}
            {unit ?? ""}
          </span>
        </div>
      ))}
    </div>
  );
}

/* ── 24h threat activity (scans vs threats) ─────────────────────────────── */

export function ThreatActivityChart({ data, height = 260 }: { data: TimeSeriesPoint[]; height?: number }) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <AreaChart data={data} margin={{ top: 12, right: 12, bottom: 0, left: -14 }}>
        <defs>
          <linearGradient id="grad-scans" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#39FF14" stopOpacity={0.32} />
            <stop offset="100%" stopColor="#39FF14" stopOpacity={0.02} />
          </linearGradient>
          <linearGradient id="grad-threats" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#FF304F" stopOpacity={0.4} />
            <stop offset="100%" stopColor="#FF304F" stopOpacity={0.03} />
          </linearGradient>
        </defs>
        <CartesianGrid {...GRID} vertical={false} />
        <XAxis dataKey="label" {...AXIS} interval={3} />
        <YAxis {...AXIS} allowDecimals={false} />
        <Tooltip content={<SocTooltip />} cursor={{ stroke: "rgba(57,255,20,0.25)" }} />
        <Area
          type="monotone"
          dataKey="scans"
          name="Scans"
          stroke="#39FF14"
          strokeWidth={1.8}
          fill="url(#grad-scans)"
          animationDuration={900}
        />
        <Area
          type="monotone"
          dataKey="threats"
          name="Threats"
          stroke="#FF304F"
          strokeWidth={1.6}
          fill="url(#grad-threats)"
          animationDuration={1100}
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}

/* ── Risk distribution donut ────────────────────────────────────────────── */

export function RiskDonut({
  data,
  height = 240,
  centerLabel,
  centerValue,
}: {
  data: { name: string; value: number; color: string }[];
  height?: number;
  centerLabel?: string;
  centerValue?: string;
}) {
  const total = data.reduce((acc, d) => acc + d.value, 0);
  return (
    <div className="relative" style={{ height }}>
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Tooltip content={<SocTooltip />} />
          <Pie
            data={data}
            dataKey="value"
            nameKey="name"
            innerRadius="66%"
            outerRadius="88%"
            paddingAngle={3}
            strokeWidth={0}
            animationDuration={900}
          >
            {data.map((d) => (
              <Cell key={d.name} fill={d.color} fillOpacity={0.85} stroke={d.color} strokeOpacity={0.4} />
            ))}
          </Pie>
          <Legend
            verticalAlign="bottom"
            height={28}
            formatter={(value) => (
              <span className="font-mono text-[10.5px] tracking-[0.08em] text-fg-dim">{value}</span>
            )}
            iconType="circle"
            iconSize={7}
          />
        </PieChart>
      </ResponsiveContainer>
      <div className="pointer-events-none absolute inset-x-0 top-[38%] -translate-y-1/2 text-center">
        <div className="font-display text-2xl font-bold text-fg">{centerValue ?? total.toLocaleString()}</div>
        <div className="mt-0.5 font-mono text-[9px] tracking-[0.28em] text-fg-dim">
          {(centerLabel ?? "TOTAL SCANS").toUpperCase()}
        </div>
      </div>
    </div>
  );
}

/* ── Phishing vs legitimate ─────────────────────────────────────────────── */

export function PhishingLegitChart({
  data,
  height = 260,
}: {
  data: DashboardAnalytics["phishingVsLegit"];
  height?: number;
}) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={data} margin={{ top: 12, right: 12, bottom: 0, left: -14 }} barGap={3}>
        <CartesianGrid {...GRID} vertical={false} />
        <XAxis dataKey="day" {...AXIS} interval={1} />
        <YAxis {...AXIS} allowDecimals={false} />
        <Tooltip content={<SocTooltip />} cursor={{ fill: "rgba(57,255,20,0.05)" }} />
        <Bar dataKey="phishing" name="Phishing" fill="#FF304F" fillOpacity={0.85} radius={[3, 3, 0, 0]} animationDuration={800} />
        <Bar dataKey="legitimate" name="Legitimate" fill="#39FF14" fillOpacity={0.75} radius={[3, 3, 0, 0]} animationDuration={1000} />
      </BarChart>
    </ResponsiveContainer>
  );
}

/* ── Scan activity (bars + flagged line) ────────────────────────────────── */

export function ScanActivityChart({
  data,
  height = 260,
}: {
  data: DashboardAnalytics["scanActivity"];
  height?: number;
}) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <ComposedChart data={data} margin={{ top: 12, right: 12, bottom: 0, left: -14 }}>
        <defs>
          <linearGradient id="grad-bar-scans" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#00E5FF" stopOpacity={0.9} />
            <stop offset="100%" stopColor="#00E5FF" stopOpacity={0.25} />
          </linearGradient>
        </defs>
        <CartesianGrid {...GRID} vertical={false} />
        <XAxis dataKey="day" {...AXIS} interval={1} />
        <YAxis {...AXIS} allowDecimals={false} />
        <Tooltip content={<SocTooltip />} cursor={{ fill: "rgba(0,229,255,0.05)" }} />
        <Bar dataKey="scans" name="Scans" fill="url(#grad-bar-scans)" radius={[3, 3, 0, 0]} animationDuration={800} />
        <Line
          type="monotone"
          dataKey="flagged"
          name="Flagged"
          stroke="#FFB020"
          strokeWidth={1.8}
          dot={{ r: 2.2, fill: "#FFB020", strokeWidth: 0 }}
          activeDot={{ r: 4 }}
          animationDuration={1100}
        />
      </ComposedChart>
    </ResponsiveContainer>
  );
}
