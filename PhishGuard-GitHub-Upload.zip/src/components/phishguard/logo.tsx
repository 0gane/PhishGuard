"use client";

import { cn } from "@/lib/utils";

/**
 * PHISHGUARD brand mark — original design.
 * A futuristic shield fused with a digital scanning eye: the shield represents
 * defence, the iris ring + scan slit represents continuous phishing detection.
 * Rendered as inline SVG so it stays crisp at any size and can inherit theme colours.
 */

export function PhishGuardMark({
  size = 40,
  className,
  animated = true,
}: {
  size?: number;
  className?: string;
  animated?: boolean;
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      role="img"
      aria-label="PhishGuard logo"
      className={className}
    >
      <defs>
        <linearGradient id="pg-shield-stroke" x1="8" y1="4" x2="56" y2="60" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#39FF14" />
          <stop offset="0.55" stopColor="#7CEB7C" />
          <stop offset="1" stopColor="#00E5FF" />
        </linearGradient>
        <linearGradient id="pg-shield-fill" x1="32" y1="6" x2="32" y2="58" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#12291C" />
          <stop offset="1" stopColor="#0A1610" />
        </linearGradient>
        <radialGradient id="pg-iris" cx="0.5" cy="0.5" r="0.5">
          <stop offset="0" stopColor="#E8F5EC" />
          <stop offset="0.35" stopColor="#39FF14" />
          <stop offset="1" stopColor="#0E3B22" />
        </radialGradient>
      </defs>

      {/* Shield body */}
      <path
        d="M32 5 L54 13 V31 C54 44.5 45.5 53.5 32 59 C18.5 53.5 10 44.5 10 31 V13 Z"
        fill="url(#pg-shield-fill)"
        stroke="url(#pg-shield-stroke)"
        strokeWidth="2.4"
        strokeLinejoin="round"
      />
      {/* Inner shield hairline */}
      <path
        d="M32 10.5 L48.5 16.5 V30.5 C48.5 41 42 48.3 32 53 C22 48.3 15.5 41 15.5 30.5 V16.5 Z"
        fill="none"
        stroke="#39FF14"
        strokeOpacity="0.22"
        strokeWidth="1"
      />

      {/* Digital eye — almond outline */}
      <path
        d="M14 32 C20 22.5 26.5 19.5 32 19.5 C37.5 19.5 44 22.5 50 32 C44 41.5 37.5 44.5 32 44.5 C26.5 44.5 20 41.5 14 32 Z"
        fill="none"
        stroke="#00E5FF"
        strokeOpacity="0.75"
        strokeWidth="1.6"
      />

      {/* Iris */}
      <circle cx="32" cy="32" r="8.5" fill="#050807" stroke="#39FF14" strokeWidth="1.6" />
      <circle cx="32" cy="32" r="4.6" fill="url(#pg-iris)" />
      <circle cx="30.2" cy="30.1" r="1.35" fill="#E8F5EC" opacity="0.9" />

      {/* Iris tick marks (targeting reticle) */}
      <g stroke="#39FF14" strokeOpacity="0.65" strokeWidth="1">
        <line x1="32" y1="20.5" x2="32" y2="24.2" />
        <line x1="32" y1="39.8" x2="32" y2="43.5" />
        <line x1="20.5" y1="32" x2="24.2" y2="32" />
        <line x1="39.8" y1="32" x2="43.5" y2="32" />
      </g>

      {/* Scan slit across the eye */}
      <g clipPath="url(#pg-eye-clip)">
        <rect x="12" y="20" width="40" height="2.4" rx="1.2" fill="#39FF14" opacity="0.9">
          {animated && (
            <animate
              attributeName="y"
              values="20;42;20"
              dur="3.2s"
              repeatCount="indefinite"
              calcMode="spline"
              keyTimes="0;0.5;1"
              keySplines="0.4 0 0.6 1;0.4 0 0.6 1"
            />
          )}
        </rect>
      </g>
      <clipPath id="pg-eye-clip">
        <path d="M14 32 C20 22.5 26.5 19.5 32 19.5 C37.5 19.5 44 22.5 50 32 C44 41.5 37.5 44.5 32 44.5 C26.5 44.5 20 41.5 14 32 Z" />
      </clipPath>

      {/* Circuit nodes */}
      <g fill="#00E5FF">
        <circle cx="17.5" cy="17.5" r="1.4" />
        <circle cx="46.5" cy="17.5" r="1.4" />
        <circle cx="32" cy="52.5" r="1.4" />
      </g>
    </svg>
  );
}

export function PhishGuardLogo({
  size = 38,
  compact = false,
  className,
}: {
  size?: number;
  compact?: boolean;
  className?: string;
}) {
  if (compact) {
    return (
      <div className={cn("flex items-center justify-center", className)}>
        <PhishGuardMark size={size} />
      </div>
    );
  }
  return (
    <div className={cn("flex items-center gap-3", className)}>
      <PhishGuardMark size={size} />
      <div className="leading-none select-none">
        <div className="font-display font-bold tracking-[0.08em] text-[17px] text-fg">
          PHISH<span className="text-neon text-glow-neon">GUARD</span>
        </div>
        <div className="mt-1.5 font-mono text-[8.5px] tracking-[0.34em] text-fg-dim">
          DETECT. ANALYSE. DEFEND.
        </div>
      </div>
    </div>
  );
}
