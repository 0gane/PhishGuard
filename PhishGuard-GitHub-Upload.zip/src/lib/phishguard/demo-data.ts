/**
 * PHISHGUARD — deterministic DEMO datasets.
 *
 * ⚠️  Everything in this file is generated, clearly-labelled DEMO DATA used to
 * demonstrate the UI before the real FastAPI backend + ML engine + live threat
 * intelligence feeds are connected. Nothing here represents live security data.
 */

import type {
  DashboardAnalytics,
  EngineHealth,
  RiskSlice,
  ScanResult,
  SecurityEvent,
  ThreatIntelResult,
  ThreatProvider,
  TimeSeriesPoint,
} from "./types";
import { mulberry32, hashString } from "./format";
import { parseUrlStructure } from "./scanner-engine";

export const SEED_VERSION = "v2";

/* ── Seed URL pool (pre-classified for a realistic distribution) ───────── */

interface SeedEntry {
  url: string;
  bucket: "HIGH" | "MEDIUM" | "LOW";
}

const SEED_URLS: SeedEntry[] = [
  // HIGH — credential phishing / malware style
  { url: "http://paypal-verify-account.tk/webscr?cmd=_login-run", bucket: "HIGH" },
  { url: "http://192.168.44.7:8081/secure/update-billing.html", bucket: "HIGH" },
  { url: "https://appleid-support.xyz/confirm-identity?session=9F2A", bucket: "HIGH" },
  { url: "http://netflix-billing-update.top/payment/declined/retry", bucket: "HIGH" },
  { url: "https://sso-secure-alerts.ml/login?redirect=https://portal.bank.example", bucket: "HIGH" },
  { url: "http://binance-wallet-restore.cf/seed-verify/upload", bucket: "HIGH" },
  { url: "https://facebook-security-check.gq/recover/account?id=88421", bucket: "HIGH" },
  { url: "http://secure-hsbc-alerts.tk/verify/card-holder/form.php", bucket: "HIGH" },
  { url: "https://drive-file-share.top/document/09AF2/download.exe", bucket: "HIGH" },
  { url: "http://amazon-guard-verify.ml/ap/signin?openid=return", bucket: "HIGH" },
  { url: "http://198.51.100.23/mail/auth/office365/login.html#reload", bucket: "HIGH" },
  { url: "https://dhl-parcel-fee.buzz/pay-customs/delivery-82104", bucket: "HIGH" },
  // MEDIUM — suspicious but not conclusively phishing
  { url: "http://promo-campaign-giveaway.net/offer?id=8812&src=mail", bucket: "MEDIUM" },
  { url: "https://bit.ly/3xKz9pL", bucket: "MEDIUM" },
  { url: "https://secure-login.portal-user5821.com/auth", bucket: "MEDIUM" },
  { url: "http://cloud-doc-share.top/file/09A2/view", bucket: "MEDIUM" },
  { url: "https://account-verify-alert.xyz/session/renew", bucket: "MEDIUM" },
  { url: "https://xn--paypa-1ve.com/login", bucket: "MEDIUM" },
  { url: "http://redirect.portal-cdn.net/?next=https://intranet.example.com", bucket: "MEDIUM" },
  { url: "https://cutt.ly/8wZq21", bucket: "MEDIUM" },
  { url: "https://webmail-sso.wellsfargo-secure.top/auth/token", bucket: "MEDIUM" },
  { url: "http://203.0.113.9/panel/login.php", bucket: "MEDIUM" },
  { url: "https://invoice-payment-reminder.buzz/inv-77120", bucket: "MEDIUM" },
  // LOW — legitimate / benign
  { url: "https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS", bucket: "LOW" },
  { url: "https://github.com/zalando/pgquarrel/pull/412", bucket: "LOW" },
  { url: "https://www.wikipedia.org/wiki/Phishing", bucket: "LOW" },
  { url: "https://stackoverflow.com/questions/tagged/nextjs", bucket: "LOW" },
  { url: "https://www.python.org/downloads/release/python-3120/", bucket: "LOW" },
  { url: "https://news.ycombinator.com/item?id=40112233", bucket: "LOW" },
  { url: "https://arxiv.org/abs/2401.04088", bucket: "LOW" },
  { url: "https://www.figma.com/file/9xK2/board-v2", bucket: "LOW" },
  { url: "https://status.cloudflare.com/incidents/history", bucket: "LOW" },
  { url: "https://openai.com/research/publications", bucket: "LOW" },
  { url: "https://mail.protection.outlook.com/EOP/Overview", bucket: "LOW" },
  { url: "https://www.university-site.edu/admissions/dates", bucket: "LOW" },
  { url: "https://docs.python.org/3/library/asyncio.html", bucket: "LOW" },
  { url: "https://www.linkedin.com/jobs/view/3901224", bucket: "LOW" },
];

function hostOf(url: string): string {
  try {
    return parseUrlStructure(url).host;
  } catch {
    return url;
  }
}

/** Derive a full ScanResult from a seed entry using the demo rule engine, deterministically. */
function buildSeedScan(entry: SeedEntry, rng: () => number, index: number, now: number): ScanResult {
  const structure = parseUrlStructure(entry.url);
  const daysAgo = Math.floor(rng() * 28); // 0..27
  const hour = Math.floor(rng() * 24);
  const minute = Math.floor(rng() * 60);
  const second = Math.floor(rng() * 60);
  const ts = new Date(now - daysAgo * 86400_000 - hour * 3600_000 - minute * 60_000 - second * 1000);
  const sourceRoll = rng();
  const source = sourceRoll < 0.68 ? "MANUAL" : sourceRoll < 0.88 ? "API" : "SCHEDULED";
  const seq = String(index + 1).padStart(4, "0");
  const year = new Date(now).getFullYear();

  // Score is derived from the same rule weights used at runtime — approximate via bucket bands.
  const bands: Record<SeedEntry["bucket"], [number, number]> = {
    HIGH: [72, 96],
    MEDIUM: [34, 66],
    LOW: [2, 27],
  };
  const [lo, hi] = bands[entry.bucket];
  const score = lo + Math.floor(rng() * (hi - lo + 1));

  const reasonsByBucket: Record<SeedEntry["bucket"], ScanResult["reasons"]> = {
    HIGH: [
      { code: "BRAND_IMPERSONATION", label: "Brand keyword outside official domain", detail: "Reference to a protected brand on an unrelated domain is a classic impersonation signal.", weight: 22, severity: "HIGH" },
      { code: "SUSPICIOUS_TLD", label: "High-abuse TLD", detail: "This top-level domain has a disproportionately high phishing-to-legitimate ratio.", weight: 14, severity: "MEDIUM" },
      { code: "NO_TLS", label: "Unencrypted connection (HTTP)", detail: "Credentials submitted over HTTP can be intercepted in transit.", weight: 22, severity: "HIGH" },
    ],
    MEDIUM: [
      { code: "SUBDOMAIN_CHAIN", label: "Multi-level subdomain chain", detail: "Deep subdomain nesting displays trusted words left of the real domain.", weight: 12, severity: "MEDIUM" },
      { code: "LURE_KEYWORDS", label: "Urgency/credential keywords", detail: "Phishing kits push urgency to force fast clicks.", weight: 10, severity: "MEDIUM" },
      { code: "URL_SHORTENER", label: "Link shortener detected", detail: "Shortened URLs conceal the final destination.", weight: 16, severity: "MEDIUM" },
    ],
    LOW: [
      { code: "TLS_PRESENT", label: "Valid TLS transport (HTTPS)", detail: "Traffic is encrypted — a positive hygiene signal.", weight: -3, severity: "INFO" },
      { code: "ALLOWLIST_MATCH", label: "Domain on built-in allowlist", detail: "Host matches a well-known legitimate domain.", weight: -12, severity: "INFO" },
    ],
  };

  const classification = entry.bucket === "HIGH" ? "HIGH_RISK" : entry.bucket === "MEDIUM" ? "MEDIUM_RISK" : "LOW_RISK";

  return {
    id: `PG-SCAN-${year}${seq}`,
    url: entry.url,
    host: hostOf(entry.url),
    scannedAt: ts.toISOString(),
    riskScore: score,
    classification,
    reasons: reasonsByBucket[entry.bucket],
    structure,
    recommendedAction:
      classification === "HIGH_RISK"
        ? "BLOCK — Do not open this link. Report it to your security team and delete the message containing it."
        : classification === "MEDIUM_RISK"
          ? "CAUTION — Verify the sender independently before opening. Do not enter credentials on this page."
          : "PROCEED — No strong phishing indicators found. Continue to apply standard browsing hygiene.",
    engine: "PG-HEURISTIC-RULES v1.2.0-demo",
    durationMs: 180 + Math.floor(rng() * 480),
    source,
  };
}

export function buildSeedScans(): ScanResult[] {
  const rng = mulberry32(0x3f15e5);
  const now = Date.now();
  const scans: ScanResult[] = [];
  for (let i = 0; i < 160; i++) {
    // Weighted bucket selection: ~18% HIGH, ~22% MEDIUM, ~60% LOW
    const roll = rng();
    const bucket = roll < 0.18 ? "HIGH" : roll < 0.4 ? "MEDIUM" : "LOW";
    const pool = SEED_URLS.filter((s) => s.bucket === bucket);
    const entry = pool[Math.floor(rng() * pool.length)];
    scans.push(buildSeedScan(entry, rng, i, now));
  }
  // Sort newest first
  scans.sort((a, b) => (a.scannedAt < b.scannedAt ? 1 : -1));
  return scans;
}

/* ── Security events ────────────────────────────────────────────────────── */

const SYSTEM_EVENT_TEMPLATES: Omit<SecurityEvent, "id" | "timestamp">[] = [
  { severity: "INFO", category: "ENGINE_RELOAD", source: "pg-rule-engine", description: "Demo rule pack v1.2.0 loaded — 34 rules active (demo ruleset)." },
  { severity: "INFO", category: "FEED_SYNC", source: "pg-threat-graph", description: "Threat graph demo snapshot refreshed — 12,480 sample indicators (synthetic)." },
  { severity: "LOW", category: "INTEGRITY_CHECK", source: "pg-api-gateway", description: "Mock API adapter integrity check passed — signature seed v1 verified." },
  { severity: "MEDIUM", category: "RATE_LIMIT", source: "pg-api-gateway", description: "Demo API rate limiter engaged for client 10.20.0.14 — burst threshold 60 req/min." },
  { severity: "INFO", category: "SESSION_START", source: "pg-console", description: "SOC console session opened — demo operator profile loaded." },
  { severity: "LOW", category: "CONFIG_CHANGE", source: "pg-console", description: "Scanner sensitivity set to STRICT by demo operator (local preference only)." },
  { severity: "INFO", category: "BACKUP", source: "pg-store", description: "Local demo store snapshot written — scan history persisted to browser storage." },
  { severity: "HIGH", category: "AUTH_FAILURE", source: "pg-console", description: "3 failed console unlock attempts from demo tenant — account lockout not armed (demo)." },
  { severity: "INFO", category: "HEALTH_PROBE", source: "pg-api-gateway", description: "Backend health probe skipped — NEXT_PUBLIC_PHISHGUARD_API_URL not configured (demo mode)." },
  { severity: "MEDIUM", category: "PROVIDER_ERROR", source: "openphish-feed", description: "Feed fetch failed after 3 retries — demo environment has no network egress." },
];

export function buildSeedEvents(scans: ScanResult[]): SecurityEvent[] {
  const rng = mulberry32(0xbeef);
  const events: SecurityEvent[] = [];
  let seq = 1;
  const now = Date.now();

  // Derive detection events from flagged scans
  for (const scan of scans) {
    if (scan.classification === "HIGH_RISK" && rng() < 0.85) {
      events.push({
        id: `EVT-90${String(seq++).padStart(3, "0")}`,
        timestamp: scan.scannedAt,
        severity: "CRITICAL",
        category: "PHISHING_DETECTED",
        source: "pg-rule-engine",
        description: `High-risk URL classified ${scan.riskScore}/100 — ${scan.host} (scan ${scan.id})`,
        scanId: scan.id,
      });
    } else if (scan.classification === "MEDIUM_RISK" && rng() < 0.5) {
      events.push({
        id: `EVT-90${String(seq++).padStart(3, "0")}`,
        timestamp: scan.scannedAt,
        severity: "HIGH",
        category: "SUSPICIOUS_URL",
        source: "pg-rule-engine",
        description: `Medium-risk URL flagged at ${scan.riskScore}/100 — ${scan.host} (scan ${scan.id})`,
        scanId: scan.id,
      });
    }
  }

  // Sprinkle system events across the same 28-day window, biased to recent hours
  for (const tpl of SYSTEM_EVENT_TEMPLATES) {
    const copies = tpl.severity === "INFO" ? 3 : 2;
    for (let c = 0; c < copies; c++) {
      const hoursAgo = Math.floor(rng() * (rng() < 0.6 ? 20 : 28 * 24));
      events.push({
        ...tpl,
        id: `EVT-90${String(seq++).padStart(3, "0")}`,
        timestamp: new Date(now - hoursAgo * 3600_000 - Math.floor(rng() * 3600_000)).toISOString(),
      });
    }
  }

  events.sort((a, b) => (a.timestamp < b.timestamp ? 1 : -1));
  return events;
}

/* ── Threat intelligence providers (demo catalogue) ────────────────────── */

export const PROVIDER_CATALOG: ThreatProvider[] = [
  {
    id: "pg-rules",
    name: "PG Heuristic Rule Engine",
    kind: "Local ruleset",
    status: "DEMO",
    note: "Demo ruleset v1.2.0 — 34 local rules, no network calls.",
    lastChecked: null,
  },
  {
    id: "pg-threat-graph",
    name: "PG Threat Graph",
    kind: "Internal demo graph",
    status: "DEMO",
    note: "Synthetic indicator set (12,480 entries) for demonstration.",
    lastChecked: null,
  },
  {
    id: "openphish",
    name: "OpenPhish Community Feed",
    kind: "External feed",
    status: "ERROR",
    note: "Fetch failed — demo environment has no network egress. Will retry when backend is connected.",
    lastChecked: null,
  },
  {
    id: "urlhaus",
    name: "URLhaus (abuse.ch)",
    kind: "External feed",
    status: "UNAVAILABLE",
    note: "Not configured — API credentials must be stored server-side in the FastAPI backend.",
    lastChecked: null,
  },
  {
    id: "virustotal",
    name: "VirusTotal v3",
    kind: "External API",
    status: "DEMO",
    note: "Simulated responses from the demo dataset. Real key handling is server-side only.",
    lastChecked: null,
  },
];

/* ── Threat intelligence lookup (simulated, deterministic) ─────────────── */

const KNOWN_BAD_PATTERNS: { pattern: string; category: string; confidence: number }[] = [
  { pattern: "paypal", category: "Credential Phishing — Financial", confidence: 96 },
  { pattern: "appleid", category: "Credential Phishing — Identity", confidence: 94 },
  { pattern: "netflix", category: "Credential Phishing — Media", confidence: 92 },
  { pattern: "binance", category: "Crypto Wallet Drainer", confidence: 97 },
  { pattern: "hsbc", category: "Credential Phishing — Banking", confidence: 95 },
  { pattern: "dhl", category: "Smishing / Delivery Fraud", confidence: 90 },
  { pattern: "amazon", category: "Credential Phishing — Retail", confidence: 91 },
  { pattern: "wellsfargo", category: "Credential Phishing — Banking", confidence: 95 },
  { pattern: "facebook", category: "Account Recovery Phishing", confidence: 89 },
];

const SUSPICIOUS_PATTERNS: { pattern: string; category: string }[] = [
  { pattern: "verify", category: "Suspicious — Verification Lure" },
  { pattern: "secure", category: "Suspicious — Trust-Infused Naming" },
  { pattern: "login", category: "Suspicious — Credential Capture Pattern" },
  { pattern: "invoice", category: "Suspicious — Invoice Fraud Pattern" },
  { pattern: "sso", category: "Suspicious — SSO Impersonation Pattern" },
];

export function simulateThreatLookup(rawQuery: string): ThreatIntelResult {
  const q = rawQuery.trim().toLowerCase();
  let normalized = q.replace(/^[a-z]+:\/\//, "").split("/")[0].split("?")[0];
  if (!normalized.includes(".")) normalized = `${normalized}.unknown`;

  const h = hashString(normalized);
  const rng = mulberry32(h);

  const bad = KNOWN_BAD_PATTERNS.find((p) => normalized.includes(p.pattern));
  const suspicious = SUSPICIOUS_PATTERNS.find((p) => normalized.includes(p.pattern));

  let reputation: ThreatIntelResult["reputation"] = "UNKNOWN";
  let category = "No classification available";
  let confidence = 0;

  if (bad) {
    reputation = "MALICIOUS";
    category = bad.category;
    confidence = bad.confidence;
  } else if (suspicious && rng() < 0.72) {
    reputation = "SUSPICIOUS";
    category = suspicious.category;
    confidence = 58 + Math.floor(rng() * 20);
  } else {
    const cleanRoll = rng();
    if (cleanRoll < 0.8) {
      reputation = "CLEAN";
      category = "No adverse indicators in demo dataset";
      confidence = 70 + Math.floor(rng() * 25);
    } else {
      reputation = "SUSPICIOUS";
      category = "Suspicious — newly observed host (demo heuristic)";
      confidence = 52 + Math.floor(rng() * 14);
    }
  }

  const matches: ThreatIntelResult["matches"] = [
    {
      providerId: "pg-rules",
      providerName: "PG Heuristic Rule Engine",
      status: "DEMO",
      matched: reputation !== "CLEAN",
      category: reputation !== "CLEAN" ? category : null,
      confidence: reputation !== "CLEAN" ? confidence : null,
      detail: reputation !== "CLEAN" ? `Local demo ruleset matched “${normalized}”.` : "Local demo ruleset: no adverse matches.",
    },
    {
      providerId: "pg-threat-graph",
      providerName: "PG Threat Graph",
      status: "DEMO",
      matched: bad ? true : reputation === "SUSPICIOUS" ? rng() < 0.5 : false,
      category: bad ? category : reputation === "SUSPICIOUS" ? category : null,
      confidence: bad ? confidence - 2 : reputation === "SUSPICIOUS" ? confidence - 8 : null,
      detail: bad ? "Indicator present in synthetic demo graph (first seen 14d ago)." : "No synthetic indicator match.",
    },
    {
      providerId: "openphish",
      providerName: "OpenPhish Community Feed",
      status: "ERROR",
      matched: null,
      category: null,
      confidence: null,
      detail: "Feed fetch failed — no network egress in demo environment.",
    },
    {
      providerId: "urlhaus",
      providerName: "URLhaus (abuse.ch)",
      status: "UNAVAILABLE",
      matched: null,
      category: null,
      confidence: null,
      detail: "Provider not configured — connect via backend to enable.",
    },
    {
      providerId: "virustotal",
      providerName: "VirusTotal v3",
      status: "DEMO",
      matched: bad ? true : reputation === "MALICIOUS" ? true : false,
      category: bad ? category : null,
      confidence: bad ? confidence : null,
      detail: bad ? "Simulated: 18/92 engines flagged (demo response)." : "Simulated: 0/92 engines flagged (demo response).",
    },
  ];

  return {
    query: rawQuery.trim(),
    normalizedTarget: normalized,
    checkedAt: new Date().toISOString(),
    reputation,
    category,
    confidence,
    matches,
  };
}

/* ── Analytics builders (derived from the scan set — no invented accuracy) ─ */

export function buildAnalytics(scans: ScanResult[]): DashboardAnalytics {
  const now = Date.now();

  // 24h activity: derive from scans in window + smooth demo fill
  const rng = mulberry32(hashString(String(scans.length)) );
  const activity24h: TimeSeriesPoint[] = [];
  for (let h = 23; h >= 0; h--) {
    const start = now - h * 3600_000;
    const label = `${String(new Date(start).getUTCHours()).padStart(2, "0")}:00`;
    const inWindow = scans.filter((s) => {
      const t = new Date(s.scannedAt).getTime();
      return t >= start - 3600_000 && t < start;
    });
    const threats = inWindow.filter((s) => s.classification === "HIGH_RISK").length;
    const base = 3 + Math.floor(rng() * 6);
    const hourlyThreatBase = Math.floor(rng() * 3);
    activity24h.push({
      time: new Date(start).toISOString(),
      label,
      scans: Math.max(inWindow.length, base),
      threats: Math.max(threats, hourlyThreatBase),
    });
  }

  // Risk distribution
  const count = (c: ScanResult["classification"]) => scans.filter((s) => s.classification === c).length;
  const riskDistribution: RiskSlice[] = [
    { name: "Low risk", value: count("LOW_RISK"), color: "#39FF14" },
    { name: "Medium risk", value: count("MEDIUM_RISK"), color: "#FFB020" },
    { name: "High risk", value: count("HIGH_RISK"), color: "#FF304F" },
  ];

  // 14-day phishing vs legitimate
  const days: string[] = [];
  for (let d = 13; d >= 0; d--) {
    const date = new Date(now - d * 86400_000);
    days.push(date.toISOString().slice(0, 10));
  }
  const phishingVsLegit = days.map((day) => {
    const inDay = scans.filter((s) => s.scannedAt.slice(0, 10) === day);
    return {
      day: day.slice(5),
      phishing: inDay.filter((s) => s.classification === "HIGH_RISK").length,
      legitimate: inDay.filter((s) => s.classification === "LOW_RISK").length,
    };
  });

  // 14-day scan activity
  const scanActivity = days.map((day) => {
    const inDay = scans.filter((s) => s.scannedAt.slice(0, 10) === day);
    return {
      day: day.slice(5),
      scans: inDay.length,
      flagged: inDay.filter((s) => s.classification !== "LOW_RISK").length,
    };
  });

  return {
    activity24h,
    riskDistribution,
    phishingVsLegit,
    scanActivity,
    generatedAt: new Date().toISOString(),
  };
}

/* ── Engine / service health (honest demo states — never fake "live") ──── */

export function buildEngineHealth(): EngineHealth[] {
  return [
    {
      id: "rule-engine",
      name: "Rule Engine",
      role: "Local URL analysis",
      status: "DEMO",
      detail: "Demo heuristic ruleset active in-browser. Real ruleset ships with the FastAPI backend.",
      latencyMs: 12,
      version: "v1.2.0-demo",
    },
    {
      id: "ml-engine",
      name: "ML Classifier",
      role: "Model inference",
      status: "UNAVAILABLE",
      detail: "Not connected — model inference requires the Python backend (planned: FastAPI + ONNX runtime).",
      latencyMs: null,
      version: "—",
    },
    {
      id: "threat-intel",
      name: "Threat Intel Providers",
      role: "Reputation lookups",
      status: "DEMO",
      detail: "Simulated provider responses (demo dataset). External feeds require server-side API keys.",
      latencyMs: null,
      version: "demo-dataset",
    },
    {
      id: "backend-api",
      name: "Backend API (FastAPI)",
      role: "Persistence + orchestration",
      status: "UNAVAILABLE",
      detail: "NEXT_PUBLIC_PHISHGUARD_API_URL not configured — frontend is running on the mock adapter.",
      latencyMs: null,
      version: "—",
    },
  ];
}
