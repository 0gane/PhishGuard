/**
 * PHISHGUARD — DEMO heuristic scan engine.
 *
 * ⚠️  DEMO ENGINE: This is a transparent, local rule-based URL analyser that runs
 * entirely in the browser. It is NOT a machine-learning model and it does NOT call
 * any external threat-intelligence API. It exists so the product UX can be fully
 * demonstrated before the real Python (FastAPI) detection backend is connected.
 *
 * The rules below are genuine, deterministic URL-structure heuristics commonly used
 * in anti-phishing literature (IP hosts, punycode, suspicious TLDs, brand keywords,
 * excess subdomains, URL shorteners, credential injection, etc.) — the verdict is
 * computed, not random, and the same URL always yields the same result.
 */

import type {
  DetectionReason,
  RiskLevel,
  ScanResult,
  UrlStructure,
} from "./types";
import { generateId, hashString } from "./format";

const SUSPICIOUS_TLDS = new Set([
  "tk", "ml", "ga", "cf", "gq", "xyz", "top", "buzz", "zip", "mov", "rest", "cam", "quest",
]);

const URL_SHORTENERS = new Set([
  "bit.ly", "tinyurl.com", "t.co", "goo.gl", "is.gd", "cutt.ly", "rb.gy", "shorturl.at", "rebrand.ly", "tiny.cc",
]);

const KNOWN_GOOD = new Set([
  "google.com", "www.google.com", "gmail.com", "youtube.com", "wikipedia.org",
  "github.com", "gitlab.com", "stackoverflow.com", "developer.mozilla.org",
  "mozilla.org", "python.org", "microsoft.com", "apple.com", "amazon.com",
  "linkedin.com", "unimelb.edu.au", "arxiv.org", "openai.com", "anthropic.com",
  "cloudflare.com", "akamai.com", "notion.so", "figma.com", "atlassian.com",
]);

const BRAND_KEYWORDS = [
  "paypal", "apple", "appleid", "netflix", "amazon", "binance", "coinbase",
  "facebook", "instagram", "whatsapp", "google", "microsoft", "office365",
  "outlook", "bank", "hsbc", "barclays", "chase", "wellsfargo", "dhl", "fedex",
  "steam", "roblox", "whmcs", "cpanel", "metamask", "ledger", "university",
];

const LURE_KEYWORDS = [
  "verify", "verification", "secure", "security", "alert", "warning", "suspended",
  "locked", "unusual", "confirm", "update", "billing", "invoice", "payment",
  "refund", "recovery", "restore", "signin", "login", "account", "support",
  "helpdesk", "unlock", "limited", "kyc", "webscr", "authenticate",
];

const REDIRECT_PARAMS = ["url", "redirect", "redirect_uri", "next", "continue", "dest", "goto", "return"];

export class InvalidUrlError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "InvalidUrlError";
  }
}

/** Validate + normalise a user-supplied URL. Throws InvalidUrlError on bad input. */
export function normalizeUrl(raw: string): string {
  const trimmed = raw.trim();
  if (!trimmed) throw new InvalidUrlError("URL is required.");
  if (trimmed.length > 2048) throw new InvalidUrlError("URL exceeds the maximum length of 2048 characters.");
  if (/\s/.test(trimmed)) throw new InvalidUrlError("URL must not contain whitespace.");
  const candidate = /^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//.test(trimmed) ? trimmed : `http://${trimmed}`;
  let parsed: URL;
  try {
    parsed = new URL(candidate);
  } catch {
    throw new InvalidUrlError("Invalid URL format. Example: https://example.com/login");
  }
  if (!parsed.hostname || !parsed.hostname.includes(".")) {
    if (!/^\d{1,3}(\.\d{1,3}){3}$/.test(parsed.hostname)) {
      throw new InvalidUrlError("Hostname must be a valid domain or IP address.");
    }
  }
  return parsed.href;
}

function shannonEntropy(value: string): number {
  if (!value.length) return 0;
  const freq = new Map<string, number>();
  for (const ch of value) freq.set(ch, (freq.get(ch) ?? 0) + 1);
  let entropy = 0;
  for (const count of freq.values()) {
    const p = count / value.length;
    entropy -= p * Math.log2(p);
  }
  return entropy;
}

const IPV4 = /^\d{1,3}(\.\d{1,3}){3}$/;

export function parseUrlStructure(url: string): UrlStructure {
  const u = new URL(url);
  const host = u.hostname.toLowerCase();
  const isIp = IPV4.test(host) || host.startsWith("[");
  let subdomain: string | null = null;
  let domain: string | null = null;
  let tld: string | null = null;

  if (!isIp) {
    const labels = host.split(".");
    if (labels.length >= 2) {
      tld = labels[labels.length - 1];
      domain = labels[labels.length - 2];
      if (labels.length > 2) subdomain = labels.slice(0, -2).join(".");
    } else {
      domain = host;
    }
  }

  const pathSegments = u.pathname.split("/").filter(Boolean);

  return {
    protocol: u.protocol.replace(":", "") || "http",
    secure: u.protocol === "https:",
    host,
    isIp,
    subdomain,
    domain,
    tld,
    port: u.port || (u.protocol === "https:" ? "443" : u.protocol === "http:" ? "80" : null),
    path: u.pathname === "/" ? null : u.pathname,
    query: u.search ? u.search.slice(1) : null,
    fragment: u.hash ? u.hash.slice(1) : null,
    length: url.length,
    pathDepth: pathSegments.length,
  };
}

function reason(r: DetectionReason): DetectionReason {
  return r;
}

export interface HeuristicOptions {
  sensitivity?: "STANDARD" | "STRICT";
}

/**
 * Run the DEMO heuristic analysis. Deterministic: the same URL always produces
 * the same verdict. Returns a full ScanResult.
 */
export function runHeuristicScan(
  rawUrl: string,
  source: ScanResult["source"] = "MANUAL",
  options: HeuristicOptions = {}
): ScanResult {
  const url = normalizeUrl(rawUrl);
  const started = performance.now();
  const structure = parseUrlStructure(url);
  const reasons: DetectionReason[] = [];
  const strict = options.sensitivity === "STRICT";
  const host = structure.host;

  let score = 4; // base residual risk

  // ── Rule: IP-literal host ────────────────────────────────────────────
  if (structure.isIp) {
    score += 30;
    reasons.push(reason({
      code: "HOST_IP_LITERAL",
      label: "IP address used as hostname",
      detail: "Legitimate brands almost never serve logins from raw IP addresses. Common in credential-harvesting kits.",
      weight: 30,
      severity: "HIGH",
    }));
  }

  // ── Rule: no TLS ─────────────────────────────────────────────────────
  if (!structure.secure) {
    score += strict ? 28 : 22;
    reasons.push(reason({
      code: "NO_TLS",
      label: "Unencrypted connection (HTTP)",
      detail: "Credentials submitted over HTTP can be intercepted in transit. Reputable login pages enforce HTTPS.",
      weight: strict ? 28 : 22,
      severity: "HIGH",
    }));
  }

  // ── Rule: punycode / homoglyph ───────────────────────────────────────
  if (host.includes("xn--")) {
    score += 26;
    reasons.push(reason({
      code: "PUNYCODE_HOST",
      label: "Punycode (IDN) hostname",
      detail: "xn-- encoding can visually impersonate ASCII brands (homoglyph attacks).",
      weight: 26,
      severity: "HIGH",
    }));
  }

  // ── Rule: '@' userinfo in URL ────────────────────────────────────────
  if (url.includes("@")) {
    score += 20;
    reasons.push(reason({
      code: "USERINFO_AT",
      label: "'@' symbol inside URL",
      detail: "Browsers render everything before '@' — attackers hide the real host after it.",
      weight: 20,
      severity: "HIGH",
    }));
  }

  // ── Rule: suspicious TLD ─────────────────────────────────────────────
  if (structure.tld && SUSPICIOUS_TLDS.has(structure.tld)) {
    score += strict ? 18 : 14;
    reasons.push(reason({
      code: "SUSPICIOUS_TLD",
      label: `High-abuse TLD ".${structure.tld}"`,
      detail: "This top-level domain has a disproportionately high phishing-to-legitimate ratio.",
      weight: strict ? 18 : 14,
      severity: "MEDIUM",
    }));
  }

  // ── Rule: shortener ──────────────────────────────────────────────────
  if (URL_SHORTENERS.has(host)) {
    score += 16;
    reasons.push(reason({
      code: "URL_SHORTENER",
      label: "Link shortener detected",
      detail: "Shortened URLs conceal the final destination and are heavily abused in phishing lures.",
      weight: 16,
      severity: "MEDIUM",
    }));
  }

  // ── Rule: brand keyword outside official domain ──────────────────────
  const hostAndPath = `${host}${structure.path ?? ""}`.toLowerCase();
  const brandHits = BRAND_KEYWORDS.filter((b) => hostAndPath.includes(b));
  const officialBrand = brandHits.find((b) =>
    structure.domain === b || (structure.domain ?? "").startsWith(`${b}-`) === false && structure.domain === b
  );
  if (brandHits.length > 0 && !KNOWN_GOOD.has(host) && !officialBrand) {
    const w = Math.min(10 + brandHits.length * 6, 26);
    score += w;
    reasons.push(reason({
      code: "BRAND_IMPERSONATION",
      label: `Brand keyword "${brandHits[0]}" outside official domain`,
      detail: `Reference to "${brandHits[0]}" on an unrelated domain is a classic impersonation signal.`,
      weight: w,
      severity: "HIGH",
    }));
  }

  // ── Rule: lure/urgency keywords ──────────────────────────────────────
  const lureHits = LURE_KEYWORDS.filter((k) => hostAndPath.includes(k));
  if (lureHits.length > 0) {
    const w = Math.min(lureHits.length * 7, 18);
    score += w;
    reasons.push(reason({
      code: "LURE_KEYWORDS",
      label: `${lureHits.length} urgency/credential keyword${lureHits.length > 1 ? "s" : ""}`,
      detail: `Matched: ${lureHits.slice(0, 4).join(", ")}. Phishing kits push urgency to force fast clicks.`,
      weight: w,
      severity: "MEDIUM",
    }));
  }

  // ── Rule: open-redirect parameters ───────────────────────────────────
  if (structure.query) {
    const params = new URLSearchParams(structure.query);
    const redirectParam = [...params.keys()].find((k) => REDIRECT_PARAMS.includes(k.toLowerCase()));
    if (redirectParam && params.get(redirectParam)) {
      score += 12;
      reasons.push(reason({
        code: "OPEN_REDIRECT_PARAM",
        label: `Open-redirect parameter "?${redirectParam}="`,
        detail: "A nested destination URL can bounce victims through a trusted domain to a malicious one.",
        weight: 12,
        severity: "MEDIUM",
      }));
    }
  }

  // ── Rule: excessive subdomains ───────────────────────────────────────
  const subLabels = structure.subdomain ? structure.subdomain.split(".") : [];
  if (subLabels.length >= 2) {
    const w = Math.min(subLabels.length * 5, 15);
    score += w;
    reasons.push(reason({
      code: "SUBDOMAIN_CHAIN",
      label: `${subLabels.length}-level subdomain chain`,
      detail: `"${structure.subdomain}" — deep subdomain nesting is used to display trusted words left of the real domain.`,
      weight: w,
      severity: "MEDIUM",
    }));
  }

  // ── Rule: excess hyphens in registered domain ────────────────────────
  if ((structure.domain?.split("-").length ?? 1) >= 3) {
    score += 9;
    reasons.push(reason({
      code: "HYPHEN_STUFFING",
      label: "Hyphen-stuffed domain name",
      detail: "Multiple hyphens often imitate multi-word brand names (e.g. secure-login-portal).",
      weight: 9,
      severity: "LOW",
    }));
  }

  // ── Rule: non-standard port ──────────────────────────────────────────
  if (structure.port && !["80", "443"].includes(structure.port)) {
    score += 10;
    reasons.push(reason({
      code: "NONSTANDARD_PORT",
      label: `Non-standard port :${structure.port}`,
      detail: "Content served on unusual ports is atypical for consumer services.",
      weight: 10,
      severity: "LOW",
    }));
  }

  // ── Rule: very long URL ──────────────────────────────────────────────
  if (structure.length > 100) {
    score += 6;
    reasons.push(reason({
      code: "URL_LENGTH",
      label: `Unusually long URL (${structure.length} chars)`,
      detail: "Padding characters and long random paths obscure the real destination.",
      weight: 6,
      severity: "LOW",
    }));
  }

  // ── Rule: high entropy host ──────────────────────────────────────────
  if (!structure.isIp && structure.domain && shannonEntropy(structure.domain) > 3.6) {
    score += 8;
    reasons.push(reason({
      code: "HIGH_ENTROPY_HOST",
      label: "High-entropy domain label",
      detail: `Entropy of "${structure.domain}" suggests algorithmically generated (DGA) naming.`,
      weight: 8,
      severity: "LOW",
    }));
  }

  // ── Rule: executable / archive payload ───────────────────────────────
  if (/\.(exe|scr|apk|bat|cmd|msi|zip|rar|7z|iso|img)(\?|$)/i.test(url)) {
    score += 24;
    reasons.push(reason({
      code: "EXECUTABLE_PAYLOAD",
      label: "Executable/archive payload link",
      detail: "Direct downloads of executables or disk images are a strong malware-delivery indicator.",
      weight: 24,
      severity: "CRITICAL",
    }));
  }

  // ── Mitigation: known-good allowlist ─────────────────────────────────
  if (KNOWN_GOOD.has(host) || (structure.domain && structure.tld && KNOWN_GOOD.has(`${structure.domain}.${structure.tld}`))) {
    score -= 12;
    reasons.push(reason({
      code: "ALLOWLIST_MATCH",
      label: "Domain on built-in allowlist",
      detail: "Host matches a well-known legitimate domain. Reduces base score.",
      weight: -12,
      severity: "INFO",
    }));
  }

  // ── Mitigation: valid TLS on neutral host ────────────────────────────
  if (structure.secure && reasons.every((r) => r.severity !== "HIGH")) {
    score -= 3;
    reasons.push(reason({
      code: "TLS_PRESENT",
      label: "Valid TLS transport (HTTPS)",
      detail: "Traffic is encrypted. Not a trust guarantee, but a positive hygiene signal.",
      weight: -3,
      severity: "INFO",
    }));
  }

  const finalScore = Math.max(0, Math.min(100, Math.round(score)));
  const classification: RiskLevel =
    finalScore >= 70 ? "HIGH_RISK" : finalScore >= 30 ? "MEDIUM_RISK" : "LOW_RISK";

  const recommendedAction =
    classification === "HIGH_RISK"
      ? "BLOCK — Do not open this link. Report it to your security team and delete the message containing it."
      : classification === "MEDIUM_RISK"
        ? "CAUTION — Verify the sender independently before opening. Do not enter credentials on this page."
        : "PROCEED — No strong phishing indicators found. Continue to apply standard browsing hygiene.";

  // Deterministic pseudo-duration from URL hash (demo realism, 220–680ms band)
  const durationMs = 220 + (hashString(url) % 460);

  return {
    id: generateId("PG-SCAN"),
    url,
    host,
    scannedAt: new Date().toISOString(),
    riskScore: finalScore,
    classification,
    reasons: reasons.sort((a, b) => Math.abs(b.weight) - Math.abs(a.weight)),
    structure,
    recommendedAction,
    engine: "PG-HEURISTIC-RULES v1.2.0-demo",
    durationMs,
    source,
  };
}
