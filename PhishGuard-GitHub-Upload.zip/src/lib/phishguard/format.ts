import type { RiskLevel, EventSeverity } from "./types";

/** Deterministic PRNG (mulberry32) — used to generate stable DEMO datasets. */
export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Hash any string to a 32-bit int (for deterministic per-domain results). */
export function hashString(input: string): number {
  let h = 2166136261;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export function formatNumber(n: number): string {
  return new Intl.NumberFormat("en-US").format(n);
}

export function formatDateTime(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  const pad = (x: number) => String(x).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(
    d.getHours()
  )}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

export function formatClock(d: Date): string {
  const pad = (x: number) => String(x).padStart(2, "0");
  return `${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())} UTC`;
}

export function relativeTime(iso: string): string {
  const then = new Date(iso).getTime();
  if (Number.isNaN(then)) return "—";
  const diff = Date.now() - then;
  const abs = Math.abs(diff);
  const mins = Math.round(abs / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.round(hours / 24);
  if (days < 30) return `${days}d ago`;
  return `${Math.round(days / 30)}mo ago`;
}

export function truncateMiddle(value: string, max = 52): string {
  if (value.length <= max) return value;
  const head = Math.ceil((max - 3) / 2);
  const tail = Math.floor((max - 3) / 2);
  return `${value.slice(0, head)}…${value.slice(value.length - tail)}`;
}

export const RISK_META: Record<
  RiskLevel,
  { label: string; short: string; color: string; bg: string; border: string; dot: string }
> = {
  LOW_RISK: {
    label: "LOW RISK",
    short: "LOW",
    color: "text-[#4ADE80]",
    bg: "bg-[#16A34A]/10",
    border: "border-[#16A34A]/35",
    dot: "#4ADE80",
  },
  MEDIUM_RISK: {
    label: "MEDIUM RISK",
    short: "MED",
    color: "text-[#FFB020]",
    bg: "bg-[#FFB020]/10",
    border: "border-[#FFB020]/35",
    dot: "#FFB020",
  },
  HIGH_RISK: {
    label: "HIGH RISK",
    short: "HIGH",
    color: "text-[#FF304F]",
    bg: "bg-[#FF304F]/10",
    border: "border-[#FF304F]/40",
    dot: "#FF304F",
  },
};

export const SEVERITY_META: Record<
  EventSeverity,
  { color: string; bg: string; border: string }
> = {
  CRITICAL: {
    color: "text-[#FF304F]",
    bg: "bg-[#FF304F]/10",
    border: "border-[#FF304F]/40",
  },
  HIGH: { color: "text-[#FF7A45]", bg: "bg-[#FF7A45]/10", border: "border-[#FF7A45]/40" },
  MEDIUM: { color: "text-[#FFB020]", bg: "bg-[#FFB020]/10", border: "border-[#FFB020]/35" },
  LOW: { color: "text-[#00E5FF]", bg: "bg-[#00E5FF]/10", border: "border-[#00E5FF]/35" },
  INFO: { color: "text-[#84968A]", bg: "bg-[#84968A]/10", border: "border-[#84968A]/30" },
};

/** Escape a value for CSV output. */
function csvCell(value: string | number | null | undefined): string {
  const s = value == null ? "" : String(value);
  if (/[",\n\r]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

export function buildCsv(rows: (string | number | null | undefined)[][]): string {
  return rows.map((r) => r.map(csvCell).join(",")).join("\r\n");
}

/** Trigger a browser download of CSV content. */
export function downloadCsv(filename: string, rows: (string | number | null | undefined)[][]) {
  const csv = buildCsv(rows);
  const blob = new Blob([`\uFEFF${csv}`], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export function generateId(prefix: string): string {
  const t = Date.now().toString(36).toUpperCase();
  const r = Math.floor(Math.random() * 46656)
    .toString(36)
    .toUpperCase()
    .padStart(3, "0");
  return `${prefix}-${t}${r}`;
}
