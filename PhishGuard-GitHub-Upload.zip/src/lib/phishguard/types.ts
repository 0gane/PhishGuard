/**
 * PHISHGUARD — shared domain types.
 * These types mirror the planned FastAPI backend contract (see lib/phishguard/api.ts)
 * so the frontend can switch from the mock adapter to the real Python backend
 * without touching UI code.
 */

export type PageId =
  | "overview"
  | "scanner"
  | "threat-intel"
  | "history"
  | "analytics"
  | "events"
  | "api"
  | "settings";

export type RiskLevel = "LOW_RISK" | "MEDIUM_RISK" | "HIGH_RISK";

export type EventSeverity = "CRITICAL" | "HIGH" | "MEDIUM" | "LOW" | "INFO";

export type ScanSource = "MANUAL" | "API" | "SCHEDULED";

export type ProviderStatus = "DEMO" | "CONNECTED" | "ERROR" | "UNAVAILABLE";

export interface UrlStructure {
  protocol: string;
  secure: boolean;
  host: string;
  isIp: boolean;
  subdomain: string | null;
  domain: string | null;
  tld: string | null;
  port: string | null;
  path: string | null;
  query: string | null;
  fragment: string | null;
  length: number;
  pathDepth: number;
}

export interface DetectionReason {
  code: string;
  label: string;
  detail: string;
  weight: number; // signed contribution to the risk score
  severity: EventSeverity;
}

export interface ScanResult {
  id: string;
  url: string;
  host: string;
  scannedAt: string; // ISO timestamp
  riskScore: number; // 0–100
  classification: RiskLevel;
  reasons: DetectionReason[];
  structure: UrlStructure;
  recommendedAction: string;
  engine: string;
  durationMs: number;
  source: ScanSource;
}

export interface SecurityEvent {
  id: string;
  timestamp: string;
  severity: EventSeverity;
  category: string;
  source: string;
  description: string;
  scanId?: string;
}

export interface ThreatProvider {
  id: string;
  name: string;
  kind: string;
  status: ProviderStatus;
  note: string;
  lastChecked: string | null;
}

export interface ProviderMatch {
  providerId: string;
  providerName: string;
  status: ProviderStatus;
  matched: boolean | null; // null → provider unavailable
  category: string | null;
  confidence: number | null;
  detail: string;
}

export interface ThreatIntelResult {
  query: string;
  normalizedTarget: string;
  checkedAt: string;
  reputation: "MALICIOUS" | "SUSPICIOUS" | "CLEAN" | "UNKNOWN";
  category: string;
  confidence: number;
  matches: ProviderMatch[];
}

export interface DashboardSummary {
  totalScanned: number;
  phishingDetected: number;
  lowRisk: number;
  mediumRisk: number;
  highRisk: number;
  detectionRate: number; // 0–100
  scansLast24h: number;
  lastScanAt: string | null;
  generatedAt: string;
}

export interface TimeSeriesPoint {
  time: string;
  label: string;
  scans: number;
  threats: number;
}

export interface RiskSlice {
  name: string;
  value: number;
  color: string;
}

export interface DashboardAnalytics {
  activity24h: TimeSeriesPoint[];
  riskDistribution: RiskSlice[];
  phishingVsLegit: { day: string; phishing: number; legitimate: number }[];
  scanActivity: { day: string; scans: number; flagged: number }[];
  generatedAt: string;
}

export interface EngineHealth {
  id: string;
  name: string;
  role: string;
  status: ProviderStatus;
  detail: string;
  latencyMs: number | null;
  version: string;
}

export interface ApiHealthReport {
  backendConfigured: boolean;
  backendUrl: string | null;
  reachable: boolean;
  httpStatus: number | null;
  latencyMs: number | null;
  checkedAt: string;
  errorMessage: string | null;
  services: EngineHealth[];
}

export interface AppSettings {
  operatorName: string;
  organisation: string;
  autoClipboard: boolean;
  sensitivity: "STANDARD" | "STRICT";
  motionEnabled: boolean;
  showGrid: boolean;
  accent: "NEON" | "CYBER";
  backendUrlOverride: string;
  requestTimeoutMs: number;
  persistHistory: boolean;
}
