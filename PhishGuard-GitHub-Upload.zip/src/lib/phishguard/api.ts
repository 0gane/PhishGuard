/**
 * PHISHGUARD — central API service layer.
 *
 * ARCHITECTURE
 * ────────────
 * • `liveApi`    → talks to the planned Python FastAPI backend.
 *                  Base URL comes from NEXT_PUBLIC_PHISHGUARD_API_URL (env) and can be
 *                  overridden at runtime from Settings (stored in localStorage).
 * • `mockApi`    → fully functional in-browser adapter (localStorage persistence,
 *                  simulated latency, deterministic demo datasets) so the whole UI
 *                  works before the backend exists.
 * • `api`        → the singleton the app imports. It automatically uses the live
 *                  adapter when a backend URL is configured, otherwise the mock.
 *
 * PLANNED BACKEND CONTRACT (FastAPI)
 * ──────────────────────────────────
 *   POST /api/v1/scans              → run a scan
 *   GET  /api/v1/scans              → list scans
 *   GET  /api/v1/scans/{id}         → fetch a single scan
 *   GET  /api/v1/dashboard/summary  → aggregate KPIs
 *   GET  /api/v1/dashboard/analytics→ chart series
 *   GET  /api/v1/health             → service health
 *
 * ⚠️ API keys are NEVER handled in the browser. When real providers are enabled,
 *    they are stored server-side by the FastAPI backend.
 */

import type {
  ApiHealthReport,
  DashboardAnalytics,
  DashboardSummary,
  ScanResult,
  SecurityEvent,
  ThreatIntelResult,
} from "./types";
import {
  PROVIDER_CATALOG,
  SEED_VERSION,
  buildAnalytics,
  buildEngineHealth,
  buildSeedEvents,
  buildSeedScans,
  simulateThreatLookup,
} from "./demo-data";
import { runHeuristicScan } from "./scanner-engine";

const ENV_BASE = (process.env.NEXT_PUBLIC_PHISHGUARD_API_URL ?? "").trim();
const OVERRIDE_KEY = "phishguard.backendUrlOverride.v1";

export const STORAGE_KEYS = {
  mock: `phishguard.mock.${SEED_VERSION}`,
  scans: `phishguard.scans.${SEED_VERSION}`,
};

export function resolveBackendUrl(): string | null {
  if (typeof window !== "undefined") {
    try {
      const override = window.localStorage.getItem(OVERRIDE_KEY);
      if (override && override.trim()) return override.trim().replace(/\/+$/, "");
    } catch {
      /* storage unavailable — fall through to env */
    }
  }
  return ENV_BASE ? ENV_BASE.replace(/\/+$/, "") : null;
}

export function setBackendUrlOverride(url: string) {
  try {
    if (url.trim()) window.localStorage.setItem(OVERRIDE_KEY, url.trim());
    else window.localStorage.removeItem(OVERRIDE_KEY);
  } catch {
    /* ignore */
  }
}

export class ApiError extends Error {
  status?: number;
  cause?: string;
  constructor(message: string, opts: { status?: number; cause?: string } = {}) {
    super(message);
    this.name = "ApiError";
    this.status = opts.status;
    this.cause = opts.cause;
  }
}

export type ApiSource = "LIVE" | "MOCK";
export function currentApiSource(): ApiSource {
  return resolveBackendUrl() ? "LIVE" : "MOCK";
}

const sleep = (ms: number) => new Promise((res) => setTimeout(res, ms));
const latency = (min: number, max: number) => min + Math.floor(Math.random() * (max - min));

/* ── Shared contract ────────────────────────────────────────────────────── */

export interface PhishGuardApi {
  source: ApiSource;
  getHealth(): Promise<ApiHealthReport>;
  createScan(url: string, source?: ScanResult["source"]): Promise<ScanResult>;
  listScans(): Promise<ScanResult[]>;
  getScan(id: string): Promise<ScanResult | null>;
  getDashboardSummary(): Promise<DashboardSummary>;
  getDashboardAnalytics(): Promise<DashboardAnalytics>;
  getEvents(): Promise<SecurityEvent[]>;
  lookupThreatIntel(query: string): Promise<ThreatIntelResult>;
  clearHistory(): Promise<void>;
}

/* ── Live adapter (FastAPI) ─────────────────────────────────────────────── */

async function liveRequest<T>(path: string, init?: RequestInit): Promise<T> {
  const base = resolveBackendUrl();
  if (!base) throw new ApiError("Backend URL is not configured.", { cause: "NO_CONFIG" });
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 10_000);
  try {
    const res = await fetch(`${base}${path}`, {
      ...init,
      signal: controller.signal,
      headers: { "Content-Type": "application/json", ...(init?.headers ?? {}) },
    });
    if (!res.ok) {
      throw new ApiError(`Backend responded with HTTP ${res.status}`, { status: res.status });
    }
    return (await res.json()) as T;
  } catch (err) {
    if (err instanceof ApiError) throw err;
    if (err instanceof DOMException && err.name === "AbortError") {
      throw new ApiError("Request timed out after 10s — is the backend running?", { cause: "TIMEOUT" });
    }
    const msg = err instanceof Error ? err.message : "Network failure";
    throw new ApiError(`Could not reach the backend — ${msg}`, { cause: "NETWORK" });
  } finally {
    clearTimeout(timer);
  }
}

export const liveApi: PhishGuardApi = {
  source: "LIVE",

  async getHealth() {
    const started = performance.now();
    const base = resolveBackendUrl();
    try {
      await liveRequest<Record<string, unknown>>("/api/v1/health");
      return {
        backendConfigured: true,
        backendUrl: base,
        reachable: true,
        httpStatus: 200,
        latencyMs: Math.round(performance.now() - started),
        checkedAt: new Date().toISOString(),
        errorMessage: null,
        services: buildEngineHealth(),
      };
    } catch (err) {
      const apiErr = err instanceof ApiError ? err : new ApiError("Unknown failure");
      return {
        backendConfigured: true,
        backendUrl: base,
        reachable: false,
        httpStatus: apiErr.status ?? null,
        latencyMs: Math.round(performance.now() - started),
        checkedAt: new Date().toISOString(),
        errorMessage: apiErr.message,
        services: buildEngineHealth(),
      };
    }
  },

  async createScan(url, source = "API") {
    return liveRequest<ScanResult>("/api/v1/scans", {
      method: "POST",
      body: JSON.stringify({ url, source }),
    });
  },

  async listScans() {
    return liveRequest<ScanResult[]>("/api/v1/scans");
  },

  async getScan(id) {
    try {
      return await liveRequest<ScanResult>(`/api/v1/scans/${encodeURIComponent(id)}`);
    } catch (err) {
      if (err instanceof ApiError && err.status === 404) return null;
      throw err;
    }
  },

  async getDashboardSummary() {
    return liveRequest<DashboardSummary>("/api/v1/dashboard/summary");
  },

  async getDashboardAnalytics() {
    return liveRequest<DashboardAnalytics>("/api/v1/dashboard/analytics");
  },

  async getEvents() {
    // Events endpoint is planned for the backend; until then live mode reports empty.
    return [];
  },

  async lookupThreatIntel(query) {
    return liveRequest<ThreatIntelResult>(
      `/api/v1/intel/lookup?q=${encodeURIComponent(query)}`
    );
  },

  async clearHistory() {
    await liveRequest<{ ok: boolean }>("/api/v1/scans", { method: "DELETE" });
  },
};

/* ── Mock adapter (browser-local, demo) ─────────────────────────────────── */

interface MockStore {
  scans: ScanResult[];
  seededAt: string;
}

function readMock(): MockStore {
  if (typeof window === "undefined") {
    return { scans: buildSeedScans(), seededAt: new Date().toISOString() };
  }
  try {
    const raw = window.localStorage.getItem(STORAGE_KEYS.mock);
    if (raw) {
      const parsed = JSON.parse(raw) as MockStore;
      if (Array.isArray(parsed.scans) && parsed.scans.length > 0) return parsed;
    }
  } catch {
    /* corrupted store → reseed */
  }
  const fresh: MockStore = { scans: buildSeedScans(), seededAt: new Date().toISOString() };
  writeMock(fresh);
  return fresh;
}

function writeMock(store: MockStore) {
  try {
    window.localStorage.setItem(STORAGE_KEYS.mock, JSON.stringify(store));
  } catch {
    /* quota exceeded — keep memory-only */
  }
}

export const mockApi: PhishGuardApi = {
  source: "MOCK",

  async getHealth() {
    await sleep(latency(280, 620));
    return {
      backendConfigured: false,
      backendUrl: null,
      reachable: false,
      httpStatus: null,
      latencyMs: null,
      checkedAt: new Date().toISOString(),
      errorMessage: null,
      services: buildEngineHealth(),
    };
  },

  async createScan(url, source = "MANUAL") {
    await sleep(latency(340, 760));
    const result = runHeuristicScan(url, source);
    const store = readMock();
    store.scans = [result, ...store.scans];
    writeMock(store);
    return result;
  },

  async listScans() {
    await sleep(latency(220, 520));
    return [...readMock().scans];
  },

  async getScan(id) {
    await sleep(latency(180, 380));
    return readMock().scans.find((s) => s.id === id) ?? null;
  },

  async getDashboardSummary() {
    await sleep(latency(200, 460));
    const scans = readMock().scans;
    const count = (c: ScanResult["classification"]) =>
      scans.filter((s) => s.classification === c).length;
    const dayAgo = Date.now() - 86_400_000;
    return {
      totalScanned: scans.length,
      phishingDetected: count("HIGH_RISK"),
      lowRisk: count("LOW_RISK"),
      mediumRisk: count("MEDIUM_RISK"),
      highRisk: count("HIGH_RISK"),
      detectionRate: scans.length
        ? Math.round((count("HIGH_RISK") / scans.length) * 1000) / 10
        : 0,
      scansLast24h: scans.filter((s) => new Date(s.scannedAt).getTime() >= dayAgo).length,
      lastScanAt: scans[0]?.scannedAt ?? null,
      generatedAt: new Date().toISOString(),
    };
  },

  async getDashboardAnalytics() {
    await sleep(latency(240, 520));
    return buildAnalytics(readMock().scans);
  },

  async getEvents() {
    await sleep(latency(220, 480));
    return buildSeedEvents(readMock().scans);
  },

  async lookupThreatIntel(query) {
    await sleep(latency(420, 900));
    return simulateThreatLookup(query);
  },

  async clearHistory() {
    await sleep(latency(200, 400));
    const fresh: MockStore = { scans: buildSeedScans(), seededAt: new Date().toISOString() };
    writeMock(fresh);
  },
};

/* ── Resolving singleton ────────────────────────────────────────────────── */

export const api: PhishGuardApi = new Proxy({} as PhishGuardApi, {
  get(_target, prop: keyof PhishGuardApi) {
    const adapter = currentApiSource() === "LIVE" ? liveApi : mockApi;
    const value = adapter[prop];
    return typeof value === "function" ? (value as (...args: unknown[]) => unknown).bind(adapter) : value;
  },
});

/** Provider catalogue is shared for both adapters (demo catalogue in mock mode). */
export function getProviderCatalog(): typeof PROVIDER_CATALOG {
  return PROVIDER_CATALOG;
}
