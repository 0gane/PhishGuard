"use client";

/**
 * PHISHGUARD — client state (zustand).
 * • useUiStore      — navigation, sidebar, persisted settings.
 * • useScanStore    — scan history loaded from the API layer (mock or live).
 * • useEventStore   — security event feed.
 */

import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type { PageId, ScanResult, SecurityEvent } from "./types";
import { api, setBackendUrlOverride } from "./api";

/* ── UI store ────────────────────────────────────────────────────────────── */

interface UiState {
  page: PageId;
  sidebarCollapsed: boolean;
  mobileNavOpen: boolean;
  pendingScanUrl: string | null;
  settings: {
    operatorName: string;
    organisation: string;
    autoClipboard: boolean;
    sensitivity: "STANDARD" | "STRICT";
    motionEnabled: boolean;
    showGrid: boolean;
    accent: "NEON" | "CYBER";
    backendUrlOverride: string;
    requestTimeoutMs: number;
    persistHistory: boolean;
  };
  setPage: (page: PageId) => void;
  toggleSidebar: () => void;
  setMobileNavOpen: (open: boolean) => void;
  setPendingScanUrl: (url: string | null) => void;
  updateSettings: (patch: Partial<UiState["settings"]>) => void;
}

export const useUiStore = create<UiState>()(
  persist(
    (set) => ({
      page: "overview",
      sidebarCollapsed: false,
      mobileNavOpen: false,
      pendingScanUrl: null,
      settings: {
        operatorName: "demo.analyst",
        organisation: "DemoSOC / BCA Project",
        autoClipboard: true,
        sensitivity: "STANDARD",
        motionEnabled: true,
        showGrid: true,
        accent: "NEON",
        backendUrlOverride: "",
        requestTimeoutMs: 10000,
        persistHistory: true,
      },
      setPage: (page) => set({ page, mobileNavOpen: false }),
      toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),
      setMobileNavOpen: (open) => set({ mobileNavOpen: open }),
      setPendingScanUrl: (url) => set({ pendingScanUrl: url }),
      updateSettings: (patch) =>
        set((s) => {
          if (patch.backendUrlOverride !== undefined) {
            setBackendUrlOverride(patch.backendUrlOverride);
          }
          return { settings: { ...s.settings, ...patch } };
        }),
    }),
    {
      name: "phishguard.ui.v1",
      storage: createJSONStorage(() => localStorage),
      partialize: (s) => ({ settings: s.settings, sidebarCollapsed: s.sidebarCollapsed }),
      /* Rehydrate manually after mount (see app shell) so SSR HTML always matches. */
      skipHydration: true,
    }
  )
);

/* ── Scan store ──────────────────────────────────────────────────────────── */

type LoadStatus = "idle" | "loading" | "ready" | "error";

interface ScanState {
  scans: ScanResult[];
  status: LoadStatus;
  error: string | null;
  loadScans: () => Promise<void>;
  addScan: (scan: ScanResult) => void;
}

export const useScanStore = create<ScanState>((set) => ({
  scans: [],
  status: "idle",
  error: null,
  loadScans: async () => {
    if (useScanStore.getState().status === "loading") return;
    set({ status: "loading", error: null });
    try {
      const scans = await api.listScans();
      set({ scans, status: "ready" });
    } catch (err) {
      set({
        status: "error",
        error: err instanceof Error ? err.message : "Failed to load scan history.",
      });
    }
  },
  addScan: (scan) => set((s) => ({ scans: [scan, ...s.scans] })),
}));

/* ── Event store ─────────────────────────────────────────────────────────── */

interface EventState {
  events: SecurityEvent[];
  status: LoadStatus;
  error: string | null;
  loadEvents: () => Promise<void>;
}

export const useEventStore = create<EventState>((set) => ({
  events: [],
  status: "idle",
  error: null,
  loadEvents: async () => {
    if (useEventStore.getState().status === "loading") return;
    set({ status: "loading", error: null });
    try {
      const events = await api.getEvents();
      set({ events, status: "ready" });
    } catch (err) {
      set({
        status: "error",
        error: err instanceof Error ? err.message : "Failed to load security events.",
      });
    }
  },
}));
