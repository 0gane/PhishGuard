"use client";

import { useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Sidebar } from "@/components/phishguard/sidebar";
import { Topbar } from "@/components/phishguard/topbar";
import { Footer } from "@/components/phishguard/footer";
import { OverviewPage } from "@/components/phishguard/pages/overview";
import { ScannerPage } from "@/components/phishguard/pages/scanner";
import { ThreatIntelPage } from "@/components/phishguard/pages/threat-intel";
import { HistoryPage } from "@/components/phishguard/pages/history";
import { AnalyticsPage } from "@/components/phishguard/pages/analytics";
import { EventsPage } from "@/components/phishguard/pages/events";
import { ApiManagementPage } from "@/components/phishguard/pages/api-management";
import { SettingsPage } from "@/components/phishguard/pages/settings";
import { useEventStore, useScanStore, useUiStore } from "@/lib/phishguard/store";
import { useHashRoute } from "@/hooks/phishguard/use-phishguard";
import type { PageId } from "@/lib/phishguard/types";

/** Stash the URL and jump to the scanner. */
function rescanFromHistory(url: string) {
  useUiStore.getState().setPendingScanUrl(url);
  window.location.hash = "/scanner";
  window.scrollTo({ top: 0, behavior: "auto" });
}

function renderPage(page: PageId, navigate: (p: PageId) => void) {
  switch (page) {
    case "scanner":
      return <ScannerPage />;
    case "threat-intel":
      return <ThreatIntelPage />;
    case "history":
      return <HistoryPage onScanAgain={rescanFromHistory} />;
    case "analytics":
      return <AnalyticsPage />;
    case "events":
      return <EventsPage />;
    case "api":
      return <ApiManagementPage />;
    case "settings":
      return <SettingsPage />;
    case "overview":
    default:
      return <OverviewPage navigate={navigate} />;
  }
}

export default function PhishGuardConsole() {
  const { page, navigate } = useHashRoute();
  const loadScans = useScanStore((s) => s.loadScans);
  const loadEvents = useEventStore((s) => s.loadEvents);
  const settings = useUiStore((s) => s.settings);
  const setMobileNavOpen = useUiStore((s) => s.setMobileNavOpen);

  /* Bootstrap demo datasets from the API layer (mock adapter or live backend). */
  useEffect(() => {
    loadScans();
    loadEvents();
  }, [loadScans, loadEvents]);

  /* Rehydrate persisted settings after hydration to avoid SSR mismatches. */
  useEffect(() => {
    void useUiStore.persist.rehydrate();
  }, []);

  /* Apply appearance settings to the document root. */
  useEffect(() => {
    document.documentElement.dataset.motion = settings.motionEnabled ? "on" : "off";
    const accent = settings.accent === "CYBER" ? "#00E5FF" : "#39FF14";
    document.documentElement.style.setProperty("--primary", accent);
  }, [settings.motionEnabled, settings.accent]);

  /* Close the mobile drawer whenever navigation changes. */
  useEffect(() => {
    setMobileNavOpen(false);
  }, [page, setMobileNavOpen]);

  return (
    <div className="relative flex min-h-screen bg-ink text-fg">
      {/* Ambient background layers */}
      {settings.showGrid && (
        <>
          <div className="pg-grid-bg pointer-events-none fixed inset-0 -z-10" aria-hidden="true" />
          <div className="pg-radial-glow pointer-events-none fixed inset-0 -z-10" aria-hidden="true" />
        </>
      )}

      <Sidebar page={page} onNavigate={navigate} />

      <div className="flex min-h-screen min-w-0 flex-1 flex-col">
        <Topbar page={page} />

        <main className="flex-1 px-4 pb-10 pt-6 sm:px-6 lg:px-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={page}
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.26, ease: [0.21, 0.6, 0.35, 1] }}
              className="mx-auto w-full max-w-[1500px]"
            >
              {renderPage(page, navigate)}
            </motion.div>
          </AnimatePresence>
        </main>

        <Footer />
      </div>
    </div>
  );
}
