import type { Metadata, Viewport } from "next";
import { Space_Grotesk, Inter, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const spaceGrotesk = Space_Grotesk({
  variable: "--font-space-grotesk",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
});

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
});

const jetbrainsMono = JetBrains_Mono({
  variable: "--font-jetbrains-mono",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
});

export const metadata: Metadata = {
  title: "PHISHGUARD — Intelligent Phishing Detection & Monitoring",
  description:
    "PHISHGUARD is a Security Operations Centre style platform for phishing URL detection, threat intelligence and security event monitoring. Demo build: heuristic demo engine, mock API layer, FastAPI-ready.",
  keywords: [
    "PHISHGUARD",
    "phishing detection",
    "cybersecurity",
    "SOC dashboard",
    "threat intelligence",
    "SIEM",
  ],
  authors: [{ name: "PHISHGUARD" }],
  applicationName: "PHISHGUARD",
};

export const viewport: Viewport = {
  themeColor: "#050807",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body
        className={`${spaceGrotesk.variable} ${inter.variable} ${jetbrainsMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
