"use client";

import { useCallback, useEffect, useRef, useState, useSyncExternalStore } from "react";
import type { PageId } from "@/lib/phishguard/types";

/* ── Hash router (React-Router style deep links within the single / route) ── */

const VALID_PAGES: PageId[] = [
  "overview",
  "scanner",
  "threat-intel",
  "history",
  "analytics",
  "events",
  "api",
  "settings",
];

function parseHash(): PageId {
  if (typeof window === "undefined") return "overview";
  const raw = window.location.hash.replace(/^#\/?/, "").toLowerCase();
  return (VALID_PAGES as string[]).includes(raw) ? (raw as PageId) : "overview";
}

function subscribeHash(onChange: () => void) {
  window.addEventListener("hashchange", onChange);
  return () => window.removeEventListener("hashchange", onChange);
}

export function useHashRoute(): {
  page: PageId;
  navigate: (page: PageId) => void;
} {
  const page = useSyncExternalStore(
    subscribeHash,
    () => parseHash(),
    () => "overview" as PageId
  );

  const navigate = useCallback((next: PageId) => {
    window.location.hash = `/${next}`;
    window.scrollTo({ top: 0, behavior: "auto" });
  }, []);

  return { page, navigate };
}

/* ── Live UTC clock (mount-gated so SSR HTML always matches) ────────────── */

export function useClock(): Date | null {
  const [now, setNow] = useState<Date | null>(null);
  useEffect(() => {
    const id = requestAnimationFrame(() => setNow(new Date()));
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => {
      cancelAnimationFrame(id);
      clearInterval(t);
    };
  }, []);
  return now;
}

/* ── Mounted flag (true one frame after hydration) ──────────────────────── */

export function useMounted(): boolean {
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    const id = requestAnimationFrame(() => setMounted(true));
    return () => cancelAnimationFrame(id);
  }, []);
  return mounted;
}

/* ── Animated number count-up ───────────────────────────────────────────── */

export function useCountUp(target: number, durationMs = 900): number {
  const [display, setDisplay] = useState(0);
  const fromRef = useRef(0);
  const rafRef = useRef<number>(0);

  useEffect(() => {
    const reduced =
      typeof window !== "undefined" &&
      (window.matchMedia("(prefers-reduced-motion: reduce)").matches ||
        document.documentElement.getAttribute("data-motion") === "off");
    if (reduced || durationMs <= 0) {
      // Jump straight to the final value on the next frame (avoids sync setState in effect).
      const id = requestAnimationFrame(() => setDisplay(target));
      return () => cancelAnimationFrame(id);
    }
    const from = fromRef.current;
    const start = performance.now();
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / durationMs);
      const eased = 1 - Math.pow(1 - p, 3);
      const value = Math.round(from + (target - from) * eased);
      setDisplay(value);
      if (p < 1) rafRef.current = requestAnimationFrame(tick);
      else fromRef.current = target;
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, [target, durationMs]);

  return display;
}

/* ── Media query helper ─────────────────────────────────────────────────── */

export function useMediaQuery(query: string): boolean {
  const [matches, setMatches] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia(query);
    const update = () => setMatches(mq.matches);
    update();
    mq.addEventListener("change", update);
    return () => mq.removeEventListener("change", update);
  }, [query]);
  return matches;
}
